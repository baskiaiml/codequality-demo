package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.api.model.BuildStatus;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TeamCityBuildStatusMapperTest {

    @Test
    void map_runningState_returnsRunning() {
        assertEquals(BuildStatus.RUNNING, TeamCityBuildStatusMapper.map("running", null));
    }

    @Test
    void map_finishedSuccess_returnsSuccess() {
        assertEquals(BuildStatus.SUCCESS, TeamCityBuildStatusMapper.map("finished", "SUCCESS"));
    }

    @Test
    void map_finishedFailure_returnsFailure() {
        assertEquals(BuildStatus.FAILURE, TeamCityBuildStatusMapper.map("finished", "FAILURE"));
    }
}
