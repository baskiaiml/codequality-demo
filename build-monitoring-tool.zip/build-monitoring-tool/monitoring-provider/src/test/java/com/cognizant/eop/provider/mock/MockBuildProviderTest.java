package com.cognizant.eop.provider.mock;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.DefaultResourceLoader;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MockBuildProviderTest {

    private MockBuildProvider provider;

    @BeforeEach
    void setUp() {
        provider = new MockBuildProvider(
                new DefaultResourceLoader(),
                "classpath:mock-data/teamcity-data.json"
        );
    }

    @Test
    void getConfiguredJobs_returnsAllJobs() {
        List<Job> jobs = provider.getConfiguredJobs();

        assertEquals(6, jobs.size());
        assertTrue(jobs.stream().allMatch(j -> j.id() != null && j.name() != null));
    }

    @Test
    void getConfiguredJobs_allJobsAreEnabled() {
        List<Job> jobs = provider.getConfiguredJobs();

        assertTrue(jobs.stream().allMatch(Job::enabled));
    }

    @Test
    void getLatestBuild_returnsHighestBuildNumber() {
        Build latest = provider.getLatestBuild("job-fo-alpha-instream");

        assertNotNull(latest);
        assertEquals(1523, latest.buildNumber());
        assertEquals(BuildStatus.FAILURE, latest.status());
    }

    @Test
    void getLatestBuild_nonExistentJob_returnsNull() {
        Build latest = provider.getLatestBuild("non-existent-job");

        assertNull(latest);
    }

    @Test
    void getBuildHistory_returnsBuildsInDescendingOrder() {
        List<Build> history = provider.getBuildHistory("job-fo-alpha-instream");

        assertEquals(2, history.size());
        assertEquals(1523, history.get(0).buildNumber());
        assertEquals(1522, history.get(1).buildNumber());
    }

    @Test
    void getBuildLog_compilationFailure_containsErrorDetails() {
        BuildLog log = provider.getBuildLog("build-1001");

        assertNotNull(log);
        assertEquals("build-1001", log.buildId());
        assertTrue(log.content().contains("cannot find symbol"));
        assertTrue(log.content().contains("CustomerDTO"));
    }

    @Test
    void getBuildLog_nonExistentBuild_throwsException() {
        assertThrows(MockBuildProviderException.class,
                () -> provider.getBuildLog("non-existent-build"));
    }

    @Test
    void getChanges_returnsCommitsForBuild() {
        List<Commit> changes = provider.getChanges("build-1001");

        assertEquals(2, changes.size());
        assertTrue(changes.stream().anyMatch(c -> c.author().equals("jsmith")));
        assertTrue(changes.stream().anyMatch(c -> c.author().equals("mjones")));
    }

    @Test
    void getChanges_buildWithNoCommits_returnsEmptyList() {
        List<Commit> changes = provider.getChanges("build-1002");

        assertTrue(changes.isEmpty());
    }

    @Test
    void getRunningBuilds_returnsOnlyRunningBuilds() {
        List<Build> running = provider.getRunningBuilds();

        assertEquals(1, running.size());
        assertEquals(BuildStatus.RUNNING, running.get(0).status());
        assertEquals("job-fw-epsilon-instream", running.get(0).jobId());
    }

    @Test
    void getLatestBuild_queuedBuild_isHighestBuildNumber() {
        Build latest = provider.getLatestBuild("job-fw-epsilon-instream");

        assertNotNull(latest);
        assertEquals(3346, latest.buildNumber());
        assertEquals(BuildStatus.QUEUED, latest.status());
        assertNull(latest.startedAt());
        assertFalse(latest.isFinished());
    }

    @Test
    void getRunningBuilds_runningBuild_hasNoFinishTime() {
        List<Build> running = provider.getRunningBuilds();

        assertEquals(1, running.size());
        assertEquals(BuildStatus.RUNNING, running.get(0).status());
        assertNull(running.get(0).finishedAt());
        assertFalse(running.get(0).isFinished());
    }

    @Test
    void getBuildLog_junitFailure_containsTestFailureDetails() {
        BuildLog log = provider.getBuildLog("build-2001");

        assertTrue(log.content().contains("Tests run:"));
        assertTrue(log.content().contains("Failures: 2"));
        assertTrue(log.content().contains("OrderValidationServiceTest"));
    }

    @Test
    void getBuildLog_mergeConflict_containsConflictDetails() {
        BuildLog log = provider.getBuildLog("build-4001");

        assertTrue(log.content().contains("Merge conflict"));
        assertTrue(log.content().contains("SettlementProcessor.java"));
    }
}
