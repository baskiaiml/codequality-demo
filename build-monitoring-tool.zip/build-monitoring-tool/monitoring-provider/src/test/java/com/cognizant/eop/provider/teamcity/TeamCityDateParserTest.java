package com.cognizant.eop.provider.teamcity;

import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class TeamCityDateParserTest {

    @Test
    void parse_iso8601Date() {
        Instant instant = TeamCityDateParser.parse("2026-06-29T06:15:00Z");
        assertNotNull(instant);
    }

    @Test
    void parse_teamCityCompactDate() {
        Instant instant = TeamCityDateParser.parse("20260629T061500+0000");
        assertNotNull(instant);
    }
}
