package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.provider.teamcity.model.TeamCityChange;
import com.cognizant.eop.provider.teamcity.model.TeamCityUserRef;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TeamCityChangeTest {

    @Test
    void resolveUsername_prefersFlatField() {
        TeamCityChange change = new TeamCityChange("abc123", "alice", "fix", "2026-01-01T00:00:00Z", null);
        assertEquals("alice", change.resolveUsername());
    }

    @Test
    void resolveUsername_readsNestedUser() {
        TeamCityChange change = new TeamCityChange(
                "abc123", null, "fix", "2026-01-01T00:00:00Z", new TeamCityUserRef("bob"));
        assertEquals("bob", change.resolveUsername());
    }

    @Test
    void resolveUsername_returnsNullWhenMissing() {
        TeamCityChange change = new TeamCityChange("abc123", null, "fix", "2026-01-01T00:00:00Z", null);
        assertNull(change.resolveUsername());
    }
}
