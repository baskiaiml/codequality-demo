package com.cognizant.eop.provider.teamcity;

public class TeamCityBuildProviderException extends RuntimeException {

    public TeamCityBuildProviderException(String message) {
        super(message);
    }

    public TeamCityBuildProviderException(String message, Throwable cause) {
        super(message, cause);
    }
}
