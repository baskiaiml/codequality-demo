package com.cognizant.eop.provider.mock;

/**
 * Exception thrown when the MockBuildProvider encounters an error loading or accessing mock data.
 */
public class MockBuildProviderException extends RuntimeException {

    public MockBuildProviderException(String message) {
        super(message);
    }

    public MockBuildProviderException(String message, Throwable cause) {
        super(message, cause);
    }
}
