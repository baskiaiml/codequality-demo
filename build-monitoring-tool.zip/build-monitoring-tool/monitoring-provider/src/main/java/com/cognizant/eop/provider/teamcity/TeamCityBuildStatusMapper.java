package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.api.model.BuildStatus;

/**
 * Maps TeamCity build state/status strings to platform {@link BuildStatus}.
 */
public final class TeamCityBuildStatusMapper {

    private TeamCityBuildStatusMapper() {
    }

    public static BuildStatus map(String state, String status) {
        if (state != null) {
            String normalizedState = state.toLowerCase();
            if ("running".equals(normalizedState)) {
                return BuildStatus.RUNNING;
            }
            if ("queued".equals(normalizedState) || "queue".equals(normalizedState)) {
                return BuildStatus.QUEUED;
            }
            if ("deleted".equals(normalizedState)) {
                return BuildStatus.CANCELLED;
            }
        }

        if (status != null) {
            return switch (status.toUpperCase()) {
                case "SUCCESS" -> BuildStatus.SUCCESS;
                case "FAILURE", "ERROR" -> BuildStatus.FAILURE;
                case "RUNNING" -> BuildStatus.RUNNING;
                case "QUEUED" -> BuildStatus.QUEUED;
                case "CANCELED", "CANCELLED" -> BuildStatus.CANCELLED;
                default -> BuildStatus.UNKNOWN;
            };
        }

        return BuildStatus.UNKNOWN;
    }
}
