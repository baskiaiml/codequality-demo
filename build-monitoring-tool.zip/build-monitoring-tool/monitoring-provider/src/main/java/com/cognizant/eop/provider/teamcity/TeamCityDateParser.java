package com.cognizant.eop.provider.teamcity;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

/**
 * Parses TeamCity date formats returned by the REST API.
 */
public final class TeamCityDateParser {

    private static final DateTimeFormatter TEAMCITY_COMPACT = new DateTimeFormatterBuilder()
            .appendValue(ChronoField.YEAR, 4)
            .appendValue(ChronoField.MONTH_OF_YEAR, 2)
            .appendValue(ChronoField.DAY_OF_MONTH, 2)
            .appendLiteral('T')
            .appendValue(ChronoField.HOUR_OF_DAY, 2)
            .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
            .appendValue(ChronoField.SECOND_OF_MINUTE, 2)
            .optionalStart()
            .appendFraction(ChronoField.MILLI_OF_SECOND, 0, 3, true)
            .optionalEnd()
            .appendOffset("+HHMM", "Z")
            .toFormatter();

    private TeamCityDateParser() {
    }

    public static Instant parse(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return Instant.parse(value);
        } catch (Exception ignored) {
            // TeamCity compact format fallback
        }
        try {
            LocalDateTime dateTime = LocalDateTime.parse(value, TEAMCITY_COMPACT);
            return dateTime.atOffset(ZoneOffset.UTC).toInstant();
        } catch (Exception ex) {
            throw new TeamCityBuildProviderException("Unable to parse TeamCity date: " + value, ex);
        }
    }
}
