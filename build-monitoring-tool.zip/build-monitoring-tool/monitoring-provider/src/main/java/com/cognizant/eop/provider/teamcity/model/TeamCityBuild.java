package com.cognizant.eop.provider.teamcity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TeamCityBuild(
        Long id,
        Integer number,
        String status,
        String state,
        String branchName,
        String startDate,
        String finishDate,
        String webUrl,
        TeamCityBuildTypeRef buildType
) {
}
