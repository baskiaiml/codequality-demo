package com.cognizant.eop.provider.teamcity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TeamCityChange(
        String version,
        String username,
        String comment,
        String date,
        TeamCityUserRef user
) {
    public String resolveUsername() {
        if (username != null && !username.isBlank()) {
            return username;
        }
        return user != null ? user.username() : null;
    }
}
