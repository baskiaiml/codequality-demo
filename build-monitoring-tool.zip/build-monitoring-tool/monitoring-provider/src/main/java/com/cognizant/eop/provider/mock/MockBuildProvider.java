package com.cognizant.eop.provider.mock;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.provider.mock.model.MockDataSet;
import com.cognizant.eop.provider.mock.model.MockDataSet.MockBuildData;
import com.cognizant.eop.provider.mock.model.MockDataSet.MockCommitData;
import com.cognizant.eop.provider.mock.model.MockDataSet.MockJobData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * BuildProvider implementation that reads from local JSON files.
 * Used during development when the real TeamCity server is inaccessible.
 */
public class MockBuildProvider implements BuildProvider {

    private static final Logger log = LoggerFactory.getLogger(MockBuildProvider.class);

    private final Map<String, MockJobData> jobsById;
    private final Map<String, List<MockBuildData>> buildsByJobId;
    private final Map<String, MockBuildData> buildsById;
    private final Map<String, List<MockCommitData>> commitsByBuildId;
    private final ResourceLoader resourceLoader;

    public MockBuildProvider(ResourceLoader resourceLoader, String mockDataPath) {
        this.resourceLoader = resourceLoader;
        MockDataSet dataSet = loadDataSet(mockDataPath);

        this.jobsById = dataSet.jobs().stream()
                .collect(Collectors.toMap(MockJobData::id, Function.identity()));

        this.buildsByJobId = dataSet.builds().stream()
                .collect(Collectors.groupingBy(MockBuildData::jobId));

        this.buildsById = dataSet.builds().stream()
                .collect(Collectors.toMap(MockBuildData::id, Function.identity()));

        this.commitsByBuildId = dataSet.commits().stream()
                .collect(Collectors.groupingBy(MockCommitData::buildId));

        log.info("MockBuildProvider initialized with {} jobs, {} builds, {} commit groups",
                jobsById.size(), buildsById.size(), commitsByBuildId.size());
    }

    @Override
    public List<Job> getConfiguredJobs() {
        return jobsById.values().stream()
                .map(this::toJob)
                .toList();
    }

    @Override
    public Build getLatestBuild(String jobId) {
        List<MockBuildData> builds = buildsByJobId.getOrDefault(jobId, List.of());
        return builds.stream()
                .max(Comparator.comparingInt(MockBuildData::buildNumber))
                .map(this::toBuild)
                .orElse(null);
    }

    @Override
    public List<Build> getBuildHistory(String jobId) {
        return buildsByJobId.getOrDefault(jobId, List.of()).stream()
                .sorted(Comparator.comparingInt(MockBuildData::buildNumber).reversed())
                .map(this::toBuild)
                .toList();
    }

    @Override
    public BuildLog getBuildLog(String buildId) {
        MockBuildData buildData = buildsById.get(buildId);
        if (buildData == null) {
            throw new MockBuildProviderException("Build not found: " + buildId);
        }

        String logContent = loadLogFile(buildData.logFile());
        return new BuildLog(buildId, logContent);
    }

    @Override
    public List<Commit> getChanges(String buildId) {
        return commitsByBuildId.getOrDefault(buildId, List.of()).stream()
                .map(this::toCommit)
                .toList();
    }

    @Override
    public List<Build> getRunningBuilds() {
        return buildsById.values().stream()
                .filter(b -> b.status() == BuildStatus.RUNNING)
                .map(this::toBuild)
                .toList();
    }

    private MockDataSet loadDataSet(String mockDataPath) {
        try {
            Resource resource = resourceLoader.getResource(mockDataPath);
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            try (InputStream is = resource.getInputStream()) {
                return mapper.readValue(is, MockDataSet.class);
            }
        } catch (IOException e) {
            throw new MockBuildProviderException("Failed to load mock data from: " + mockDataPath, e);
        }
    }

    private String loadLogFile(String logFileName) {
        if (logFileName == null || logFileName.isBlank()) {
            return "";
        }
        try {
            Resource resource = resourceLoader.getResource("classpath:mock-data/logs/" + logFileName);
            try (InputStream is = resource.getInputStream()) {
                return new String(is.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            log.warn("Failed to load log file: {}", logFileName);
            return "Log file not available: " + logFileName;
        }
    }

    private Job toJob(MockJobData data) {
        return new Job(data.id(), data.name(), data.buildTypeId(), data.branch(), data.enabled());
    }

    private Build toBuild(MockBuildData data) {
        return new Build(
                data.id(), data.jobId(), data.buildNumber(), data.status(),
                data.branch(), data.startedAt(), data.finishedAt(),
                data.durationMs(), data.triggeredBy(), data.buildUrl()
        );
    }

    private Commit toCommit(MockCommitData data) {
        return new Commit(data.hash(), data.author(), data.message(), data.timestamp());
    }
}
