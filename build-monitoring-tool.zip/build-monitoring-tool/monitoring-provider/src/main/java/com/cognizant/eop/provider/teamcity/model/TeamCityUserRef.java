package com.cognizant.eop.provider.teamcity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TeamCityUserRef(String username) {
}
