package com.cognizant.eop.provider.mock.model;

import com.cognizant.eop.api.model.BuildStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record MockDataSet(
        List<MockJobData> jobs,
        List<MockBuildData> builds,
        List<MockCommitData> commits
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MockJobData(
            String id,
            String name,
            String buildTypeId,
            String branch,
            boolean enabled
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MockBuildData(
            String id,
            String jobId,
            int buildNumber,
            BuildStatus status,
            String branch,
            Instant startedAt,
            Instant finishedAt,
            long durationMs,
            String triggeredBy,
            String buildUrl,
            String logFile
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MockCommitData(
            String buildId,
            String hash,
            String author,
            String message,
            Instant timestamp
    ) {}
}
