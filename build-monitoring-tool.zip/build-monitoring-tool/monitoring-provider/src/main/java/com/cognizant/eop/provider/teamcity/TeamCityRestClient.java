package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.provider.teamcity.model.TeamCityBuild;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuildResponse;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuildType;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuildTypeResponse;
import com.cognizant.eop.provider.teamcity.model.TeamCityChange;
import com.cognizant.eop.provider.teamcity.model.TeamCityChangeResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

/**
 * Low-level HTTP client for TeamCity REST endpoints.
 */
public class TeamCityRestClient {

    private static final Logger log = LoggerFactory.getLogger(TeamCityRestClient.class);
    private static final String ACCEPT_TEAMCITY = "application/json, application/xml, text/plain, */*";

    private final TeamCityProperties properties;
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public TeamCityRestClient(TeamCityProperties properties) {
        this(properties, HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .build());
    }

    TeamCityRestClient(TeamCityProperties properties, HttpClient httpClient) {
        this.properties = properties;
        this.httpClient = httpClient;
        this.objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
        validateConfiguration();
    }

    public List<TeamCityBuildType> fetchBuildTypes() {
        String url = properties.restBaseUrl()
                + "/buildTypes?fields=buildType(id,name,projectName,paused)&locator=count:1000";
        TeamCityBuildTypeResponse response = get(url, TeamCityBuildTypeResponse.class);
        return response.buildType() == null ? List.of() : response.buildType();
    }

    public List<TeamCityBuild> fetchBuildsForType(String buildTypeId, int count) {
        String url = properties.restBaseUrl()
                + "/buildTypes/id:" + encode(buildTypeId)
                + "/builds/?locator=count:" + count
                + "&fields=build(id,number,status,state,branchName,startDate,finishDate,webUrl,buildType(id))";
        TeamCityBuildResponse response = get(url, TeamCityBuildResponse.class);
        return response.build() == null ? List.of() : response.build();
    }

    public List<TeamCityBuild> fetchRunningBuilds() {
        String url = properties.restBaseUrl()
                + "/builds?locator=running:true,count:200"
                + "&fields=build(id,number,status,state,branchName,startDate,finishDate,webUrl,buildType(id))";
        TeamCityBuildResponse response = get(url, TeamCityBuildResponse.class);
        return response.build() == null ? List.of() : response.build();
    }

    public List<TeamCityChange> fetchChanges(String buildId) {
        String fields = "change(version,comment,date,user(username))";
        String primaryUrl = properties.restBaseUrl()
                + "/changes?locator=build:(id:" + encode(buildId) + ")&fields=" + fields;
        Optional<TeamCityChangeResponse> primary = getOptional(primaryUrl, TeamCityChangeResponse.class);
        if (primary.isPresent()) {
            return toChanges(primary.get());
        }

        String fallbackUrl = properties.restBaseUrl()
                + "/builds/id:" + encode(buildId)
                + "/changes?fields=change(version,comment,date,user(username))";
        Optional<TeamCityChangeResponse> fallback = getOptional(fallbackUrl, TeamCityChangeResponse.class);
        if (fallback.isPresent()) {
            return toChanges(fallback.get());
        }

        log.warn("No TeamCity changes returned for build id={}", buildId);
        return List.of();
    }

    private List<TeamCityChange> toChanges(TeamCityChangeResponse response) {
        return response.change() == null ? List.of() : response.change();
    }

    public String fetchBuildLog(String buildId) {
        String url = properties.baseUrl() + "/downloadBuildLog.html?buildId=" + encode(buildId) + "&plainText=true";
        return getText(url);
    }

    private <T> T get(String url, Class<T> type) {
        HttpRequest request = authorizedRequest(url)
                .header("Accept", ACCEPT_TEAMCITY)
                .GET()
                .build();
        return execute(request, body -> objectMapper.readValue(body, type));
    }

    private <T> Optional<T> getOptional(String url, Class<T> type) {
        try {
            return Optional.of(get(url, type));
        } catch (TeamCityBuildProviderException ex) {
            if (isRecoverableClientError(ex)) {
                log.debug("TeamCity request skipped for {}: {}", url, ex.getMessage());
                return Optional.empty();
            }
            throw ex;
        }
    }

    private boolean isRecoverableClientError(TeamCityBuildProviderException ex) {
        String message = ex.getMessage();
        return message != null && (message.contains("status=404") || message.contains("status=406"));
    }

    private String getText(String url) {
        HttpRequest request = authorizedRequest(url)
                .header("Accept", "text/plain")
                .GET()
                .build();
        return execute(request, body -> body);
    }

    private HttpRequest.Builder authorizedRequest(String url) {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(60));
        applyAuth(builder);
        return builder;
    }

    private void applyAuth(HttpRequest.Builder builder) {
        if (properties.token() != null && !properties.token().isBlank()) {
            builder.header("Authorization", "Bearer " + properties.token());
            return;
        }
        if (properties.username() != null && !properties.username().isBlank()) {
            String credentials = properties.username() + ":" + (properties.password() == null ? "" : properties.password());
            String encoded = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
            builder.header("Authorization", "Basic " + encoded);
        }
    }

    private <T> T execute(HttpRequest request, ResponseParser<T> parser) {
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new TeamCityBuildProviderException(
                        "TeamCity request failed: status=" + response.statusCode() + ", url=" + request.uri());
            }
            return parser.parse(response.body());
        } catch (IOException | InterruptedException ex) {
            if (ex instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw new TeamCityBuildProviderException("TeamCity request failed: " + request.uri(), ex);
        }
    }

    private void validateConfiguration() {
        if (properties.baseUrl() == null || properties.baseUrl().isBlank()) {
            throw new TeamCityBuildProviderException("eop.provider.teamcity.base-url is required");
        }
        boolean hasToken = properties.token() != null && !properties.token().isBlank();
        boolean hasBasic = properties.username() != null && !properties.username().isBlank();
        if (!hasToken && !hasBasic) {
            throw new TeamCityBuildProviderException(
                    "TeamCity authentication required: set token or username/password");
        }
    }

    private static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    @FunctionalInterface
    private interface ResponseParser<T> {
        T parse(String body) throws IOException;
    }
}
