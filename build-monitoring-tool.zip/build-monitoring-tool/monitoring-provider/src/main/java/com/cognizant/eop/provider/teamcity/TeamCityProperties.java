package com.cognizant.eop.provider.teamcity;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * TeamCity REST API connection settings.
 *
 * @param baseUrl  TeamCity server root URL (e.g. https://teamcity.internal)
 * @param token    Bearer token (preferred when set)
 * @param username Basic-auth username (used when token is blank)
 * @param password Basic-auth password
 */
@ConfigurationProperties(prefix = "eop.provider.teamcity")
public record TeamCityProperties(
        String baseUrl,
        String token,
        String username,
        String password
) {
    public TeamCityProperties {
        if (baseUrl != null) {
            baseUrl = baseUrl.replaceAll("/+$", "");
        }
    }

    public String restBaseUrl() {
        return baseUrl + "/app/rest";
    }
}
