package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuild;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuildType;
import com.cognizant.eop.provider.teamcity.model.TeamCityChange;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuild;
import com.cognizant.eop.provider.teamcity.model.TeamCityBuildType;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;

/**
 * Production {@link BuildProvider} backed by the TeamCity REST API.
 */
public class TeamCityBuildProvider implements BuildProvider {

    private final TeamCityRestClient restClient;

    public TeamCityBuildProvider(TeamCityRestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public List<Job> getConfiguredJobs() {
        return restClient.fetchBuildTypes().stream()
                .map(this::toJob)
                .toList();
    }

    @Override
    public Build getLatestBuild(String jobId) {
        return restClient.fetchBuildsForType(jobId, 1).stream()
                .findFirst()
                .map(build -> toBuild(build, jobId))
                .orElse(null);
    }

    @Override
    public List<Build> getBuildHistory(String jobId) {
        return restClient.fetchBuildsForType(jobId, 50).stream()
                .sorted(Comparator.comparing(TeamCityBuild::number, Comparator.nullsLast(Comparator.reverseOrder())))
                .map(build -> toBuild(build, jobId))
                .toList();
    }

    @Override
    public BuildLog getBuildLog(String buildId) {
        String content = restClient.fetchBuildLog(buildId);
        return new BuildLog(buildId, content);
    }

    @Override
    public List<Commit> getChanges(String buildId) {
        return restClient.fetchChanges(buildId).stream()
                .map(this::toCommit)
                .toList();
    }

    @Override
    public List<Build> getRunningBuilds() {
        return restClient.fetchRunningBuilds().stream()
                .map(build -> {
                    String jobId = build.buildType() != null ? build.buildType().id() : "unknown";
                    return toBuild(build, jobId);
                })
                .toList();
    }

    private Job toJob(TeamCityBuildType buildType) {
        boolean enabled = buildType.paused() == null || !buildType.paused();
        String displayName = buildType.projectName() == null
                ? buildType.name()
                : buildType.projectName() + " :: " + buildType.name();
        return new Job(buildType.id(), displayName, buildType.id(), null, enabled);
    }

    private Build toBuild(TeamCityBuild build, String jobId) {
        Instant startedAt = TeamCityDateParser.parse(build.startDate());
        Instant finishedAt = TeamCityDateParser.parse(build.finishDate());
        long durationMs = 0;
        if (startedAt != null && finishedAt != null) {
            durationMs = finishedAt.toEpochMilli() - startedAt.toEpochMilli();
        }
        BuildStatus status = TeamCityBuildStatusMapper.map(build.state(), build.status());
        String buildId = build.id() == null ? String.valueOf(build.number()) : String.valueOf(build.id());
        return new Build(
                buildId,
                jobId,
                build.number() == null ? 0 : build.number(),
                status,
                build.branchName(),
                startedAt,
                finishedAt,
                durationMs,
                null,
                build.webUrl()
        );
    }

    private Commit toCommit(TeamCityChange change) {
        return new Commit(
                change.version(),
                change.resolveUsername(),
                change.comment(),
                TeamCityDateParser.parse(change.date())
        );
    }
}
