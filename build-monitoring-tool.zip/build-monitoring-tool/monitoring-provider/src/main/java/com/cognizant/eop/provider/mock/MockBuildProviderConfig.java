package com.cognizant.eop.provider.mock;

import com.cognizant.eop.api.provider.BuildProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;

/**
 * Spring configuration for the MockBuildProvider.
 * Active when {@code eop.provider.type=mock} (default in dev profile).
 */
@Configuration
@ConditionalOnProperty(name = "eop.provider.type", havingValue = "mock", matchIfMissing = true)
public class MockBuildProviderConfig {

    @Bean
    BuildProvider mockBuildProvider(
            ResourceLoader resourceLoader,
            @Value("${eop.provider.mock.data-path:classpath:mock-data/teamcity-data.json}") String mockDataPath) {
        return new MockBuildProvider(resourceLoader, mockDataPath);
    }
}
