package com.cognizant.eop.provider.teamcity;

import com.cognizant.eop.api.provider.BuildProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring configuration for the TeamCity build provider.
 * Active when {@code eop.provider.type=teamcity}.
 */
@Configuration
@ConditionalOnProperty(name = "eop.provider.type", havingValue = "teamcity")
@EnableConfigurationProperties(TeamCityProperties.class)
public class TeamCityBuildProviderConfig {

    @Bean
    TeamCityRestClient teamCityRestClient(TeamCityProperties properties) {
        return new TeamCityRestClient(properties);
    }

    @Bean
    BuildProvider teamCityBuildProvider(TeamCityRestClient teamCityRestClient) {
        return new TeamCityBuildProvider(teamCityRestClient);
    }
}
