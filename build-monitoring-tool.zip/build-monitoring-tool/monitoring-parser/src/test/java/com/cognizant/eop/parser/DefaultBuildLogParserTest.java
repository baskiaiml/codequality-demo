package com.cognizant.eop.parser;

import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.parser.extractor.FailureSnippetExtractor;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader;
import com.cognizant.eop.parser.matcher.PatternMatcher;
import com.cognizant.eop.parser.model.LogParseResult;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DefaultBuildLogParserTest {

    private static BuildLogParser parser;

    @BeforeAll
    static void setUp() {
        KnowledgeBaseLoader loader = new KnowledgeBaseLoader();
        loader.load();
        parser = new DefaultBuildLogParser(
                loader,
                new LogPreprocessor(),
                new PatternMatcher(loader),
                new FailureSnippetExtractor()
        );
    }

    @ParameterizedTest
    @CsvSource({
            "compilation-failure.log, COMPILATION_ERROR, CustomerDTO",
            "junit-failure.log, JUNIT_FAILURE, OrderValidationServiceTest",
            "merge-conflict.log, MERGE_CONFLICT, SettlementProcessor",
            "sql-failure.log, ORACLE_SQL_FAILURE, TRADE_SETTLEMENT"
    })
    void parse_mockLogs_classifiesCorrectly(String logFile, FailureCategory expectedCategory, String expectedToken)
            throws IOException {
        LogParseResult result = parser.parse(new BuildLog("test-build", loadLog(logFile)));

        assertEquals(expectedCategory, result.primaryCategory());
        assertTrue(result.confidenceScore().doubleValue() >= 50);
        assertTrue(result.logSnippet().contains(expectedToken)
                || result.rootCause().contains(expectedToken)
                || result.relevantClasses().stream().anyMatch(c -> c.contains(expectedToken))
                || result.sqlObjects().stream().anyMatch(s -> s.contains(expectedToken))
                || result.suggestedFix().contains(expectedToken));
    }

    @Test
    void parse_compilationFailure_extractsCustomerDtoClass() throws IOException {
        LogParseResult result = parser.parse(new BuildLog("build-1001", loadLog("compilation-failure.log")));

        assertEquals(FailureCategory.COMPILATION_ERROR, result.primaryCategory());
        assertTrue(result.relevantClasses().contains("CustomerDTO")
                || result.rootCause().contains("CustomerDTO")
                || result.suggestedFix().contains("CustomerDTO"));
        assertFalse(result.allMatches().isEmpty());
    }

    @Test
    void parse_emptyLog_returnsUnknown() {
        LogParseResult result = parser.parse(new BuildLog("empty", ""));

        assertEquals(FailureCategory.UNKNOWN_FAILURE, result.primaryCategory());
    }

    private String loadLog(String fileName) throws IOException {
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("mock-logs/" + fileName)) {
            if (is == null) {
                throw new IOException("Log file not found: " + fileName);
            }
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
