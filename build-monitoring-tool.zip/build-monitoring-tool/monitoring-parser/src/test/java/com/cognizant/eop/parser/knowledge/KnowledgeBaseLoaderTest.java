package com.cognizant.eop.parser.knowledge;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KnowledgeBaseLoaderTest {

    @Test
    void load_loadsAllPatternCategories() {
        KnowledgeBaseLoader loader = new KnowledgeBaseLoader();
        loader.load();

        assertFalse(loader.getEntries().isEmpty());
        assertTrue(loader.getEntries().size() >= 10);
        assertTrue(loader.getCompiledPatterns().size() >= 20);
    }
}
