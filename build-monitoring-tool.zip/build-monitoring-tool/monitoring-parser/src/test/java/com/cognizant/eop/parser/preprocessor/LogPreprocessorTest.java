package com.cognizant.eop.parser.preprocessor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LogPreprocessorTest {

    private final LogPreprocessor preprocessor = new LogPreprocessor();

    @Test
    void preprocess_stripsAnsiCodes() {
        String raw = "\u001B[31m[ERROR]\u001B[0m Compilation failed";

        LogPreprocessor.PreprocessedLog result = preprocessor.preprocess(raw);

        assertFalse(result.content().contains("\u001B"));
        assertTrue(result.content().contains("[ERROR]"));
    }

    @Test
    void preprocess_extractsErrorBlocks() {
        String raw = """
                [INFO] Starting build
                [ERROR] cannot find symbol
                [INFO] Done
                """;

        LogPreprocessor.PreprocessedLog result = preprocessor.preprocess(raw);

        assertFalse(result.errorBlocks().isEmpty());
        assertTrue(result.errorBlocks().stream().anyMatch(line -> line.contains("cannot find symbol")));
    }

    @Test
    void preprocess_deduplicatesConsecutiveLines() {
        String raw = "line1\nline1\nline2\nline2\nline2";

        LogPreprocessor.PreprocessedLog result = preprocessor.preprocess(raw);

        assertEquals(2, result.lines().size());
    }
}
