package com.cognizant.eop.parser.knowledge;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record KnowledgeBaseEntry(
        FailureCategory category,
        String displayName,
        Severity defaultSeverity,
        List<FailurePatternDefinition> patterns,
        List<RecommendationRule> recommendations
) {
    public KnowledgeBaseEntry {
        if (patterns == null) {
            patterns = List.of();
        }
        if (recommendations == null) {
            recommendations = List.of();
        }
    }
}
