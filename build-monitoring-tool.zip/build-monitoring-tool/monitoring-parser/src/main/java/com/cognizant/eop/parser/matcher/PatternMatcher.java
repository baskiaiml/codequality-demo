package com.cognizant.eop.parser.matcher;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader.CompiledPattern;
import com.cognizant.eop.parser.knowledge.TemplateRenderer;
import com.cognizant.eop.parser.model.PatternMatchResult;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor.PreprocessedLog;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;

/**
 * Matches preprocessed log lines against knowledge base regex patterns.
 */
public class PatternMatcher {

    private final KnowledgeBaseLoader knowledgeBaseLoader;

    public PatternMatcher(KnowledgeBaseLoader knowledgeBaseLoader) {
        this.knowledgeBaseLoader = knowledgeBaseLoader;
    }

    /**
     * Finds all pattern matches in the preprocessed log, sorted by confidence descending.
     */
    public List<PatternMatchResult> match(PreprocessedLog preprocessedLog) {
        List<PatternMatchResult> matches = new ArrayList<>();

        List<String> lines = preprocessedLog.lines();
        for (int lineIndex = 0; lineIndex < lines.size(); lineIndex++) {
            String line = lines.get(lineIndex);
            for (CompiledPattern compiled : knowledgeBaseLoader.getCompiledPatterns()) {
                Matcher matcher = compiled.linePattern().matcher(line);
                if (matcher.find()) {
                    matches.add(buildMatchResult(compiled, line, lineIndex + 1, matcher, preprocessedLog.content()));
                }
            }
        }

        // Also scan full content for multiline patterns (merge conflicts, liquibase blocks)
        for (CompiledPattern compiled : knowledgeBaseLoader.getCompiledPatterns()) {
            Matcher matcher = compiled.linePattern().matcher(preprocessedLog.content());
            if (matcher.find() && matches.stream().noneMatch(m -> m.patternId().equals(compiled.definition().id()))) {
                matches.add(buildMatchResult(
                        compiled,
                        matcher.group(),
                        -1,
                        matcher,
                        preprocessedLog.content()
                ));
            }
        }

        matches.sort(Comparator.comparingInt(PatternMatchResult::confidence).reversed());
        return matches;
    }

    private PatternMatchResult buildMatchResult(
            CompiledPattern compiled,
            String matchedLine,
            int lineNumber,
            Matcher lineMatcher,
            String fullContent) {
        List<String> groups = extractGroups(lineMatcher, compiled.definition().extractGroups());
        List<String> classes = extractUsingPattern(fullContent, compiled.classExtractor());
        List<String> sqlObjects = extractUsingPattern(fullContent, compiled.sqlExtractor());
        String module = extractModule(fullContent, compiled.moduleExtractor());

        String rootCause = TemplateRenderer.render(compiled.definition().rootCauseTemplate(), groups);
        String suggestedFix = TemplateRenderer.render(compiled.definition().suggestedFixTemplate(), groups);

        return new PatternMatchResult(
                compiled.definition().id(),
                compiled.entry().category(),
                compiled.definition().confidence(),
                matchedLine.trim(),
                lineNumber,
                groups,
                rootCause,
                suggestedFix,
                classes,
                sqlObjects,
                module
        );
    }

    private List<String> extractGroups(Matcher matcher, List<Integer> groupIndexes) {
        if (groupIndexes.isEmpty()) {
            return List.of(matcher.group());
        }
        List<String> groups = new ArrayList<>();
        for (int index : groupIndexes) {
            if (index >= 0 && index <= matcher.groupCount()) {
                groups.add(matcher.group(index));
            }
        }
        return groups;
    }

    private List<String> extractUsingPattern(String content, java.util.regex.Pattern pattern) {
        if (pattern == null) {
            return List.of();
        }
        Matcher matcher = pattern.matcher(content);
        List<String> results = new ArrayList<>();
        while (matcher.find()) {
            String value = matcher.groupCount() >= 1 ? matcher.group(1) : matcher.group();
            if (value != null && !value.isBlank()) {
                results.add(value.trim());
            }
        }
        return results.stream().distinct().toList();
    }

    private String extractModule(String content, java.util.regex.Pattern pattern) {
        List<String> modules = extractUsingPattern(content, pattern);
        return modules.isEmpty() ? null : modules.getFirst();
    }
}
