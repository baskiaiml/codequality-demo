package com.cognizant.eop.parser;

import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;
import com.cognizant.eop.parser.extractor.FailureSnippetExtractor;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseEntry;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader;
import com.cognizant.eop.parser.knowledge.RecommendationRule;
import com.cognizant.eop.parser.matcher.PatternMatcher;
import com.cognizant.eop.parser.model.LogParseResult;
import com.cognizant.eop.parser.model.PatternMatchResult;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor.PreprocessedLog;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.List;

/**
 * Default implementation orchestrating preprocessing, pattern matching, and snippet extraction.
 */
public class DefaultBuildLogParser implements BuildLogParser {

    private static final int MIN_CONFIDENCE_THRESHOLD = 50;

    private final LogPreprocessor preprocessor;
    private final PatternMatcher patternMatcher;
    private final FailureSnippetExtractor snippetExtractor;
    private final KnowledgeBaseLoader knowledgeBaseLoader;

    public DefaultBuildLogParser(
            KnowledgeBaseLoader knowledgeBaseLoader,
            LogPreprocessor preprocessor,
            PatternMatcher patternMatcher,
            FailureSnippetExtractor snippetExtractor) {
        this.knowledgeBaseLoader = knowledgeBaseLoader;
        this.preprocessor = preprocessor;
        this.patternMatcher = patternMatcher;
        this.snippetExtractor = snippetExtractor;
    }

    @Override
    public LogParseResult parse(BuildLog buildLog) {
        PreprocessedLog preprocessed = preprocessor.preprocess(buildLog.content());
        List<PatternMatchResult> matches = patternMatcher.match(preprocessed);

        if (matches.isEmpty()) {
            return LogParseResult.unknown(snippetExtractor.extract(preprocessed, null));
        }

        PatternMatchResult best = selectBestMatch(matches, preprocessed.content());
        if (best.confidence() < MIN_CONFIDENCE_THRESHOLD) {
            LogParseResult unknown = LogParseResult.unknown(snippetExtractor.extract(preprocessed, best));
            return withMatches(unknown, matches);
        }

        KnowledgeBaseEntry entry = findEntry(best.category());
        Severity severity = entry != null ? entry.defaultSeverity() : Severity.MEDIUM;
        String recommendation = resolveRecommendation(entry, best.confidence());

        LogParseResult result = new LogParseResult(
                best.category(),
                BigDecimal.valueOf(best.confidence()).setScale(2, RoundingMode.HALF_UP),
                best.rootCause(),
                best.suggestedFix(),
                best.affectedModule(),
                best.relevantClasses(),
                best.sqlObjects(),
                snippetExtractor.extract(preprocessed, best),
                recommendation,
                severity,
                matches
        );

        return result;
    }

    /**
     * Selects the best pattern match, applying category priority when multiple categories match.
     */
    private PatternMatchResult selectBestMatch(List<PatternMatchResult> matches, String logContent) {
        PatternMatchResult top = matches.getFirst();

        if (logContent.contains("ORA-")) {
            return matches.stream()
                    .filter(match -> match.category() == FailureCategory.ORACLE_SQL_FAILURE)
                    .max(Comparator.comparingInt(PatternMatchResult::confidence))
                    .orElse(top);
        }

        if (logContent.toLowerCase().contains("merge conflict")) {
            return matches.stream()
                    .filter(match -> match.category() == FailureCategory.MERGE_CONFLICT)
                    .max(Comparator.comparingInt(PatternMatchResult::confidence))
                    .orElse(top);
        }

        long categoryAgreement = matches.stream()
                .filter(match -> match.category() == top.category())
                .count();

        if (categoryAgreement > 1) {
            int boosted = Math.min(100, top.confidence() + 10);
            return new PatternMatchResult(
                    top.patternId(), top.category(), boosted, top.matchedLine(),
                    top.lineNumber(), top.extractedGroups(), top.rootCause(),
                    top.suggestedFix(), top.relevantClasses(), top.sqlObjects(),
                    top.affectedModule()
            );
        }

        return top;
    }

    private KnowledgeBaseEntry findEntry(FailureCategory category) {
        return knowledgeBaseLoader.getEntries().stream()
                .filter(entry -> entry.category() == category)
                .findFirst()
                .orElse(null);
    }

    private String resolveRecommendation(KnowledgeBaseEntry entry, int confidence) {
        if (entry == null || entry.recommendations().isEmpty()) {
            return defaultRecommendation(confidence);
        }

        for (RecommendationRule rule : entry.recommendations()) {
            if (evaluateCondition(rule.condition(), confidence)) {
                return rule.message();
            }
        }
        return defaultRecommendation(confidence);
    }

    private boolean evaluateCondition(String condition, int confidence) {
        if (condition == null || condition.isBlank()) {
            return false;
        }
        String trimmed = condition.trim();
        if (trimmed.startsWith("confidence >=")) {
            int threshold = Integer.parseInt(trimmed.substring("confidence >=".length()).trim());
            return confidence >= threshold;
        }
        if (trimmed.startsWith("confidence <")) {
            int threshold = Integer.parseInt(trimmed.substring("confidence <".length()).trim());
            return confidence < threshold;
        }
        return false;
    }

    private String defaultRecommendation(int confidence) {
        if (confidence >= 90) {
            return "High confidence match. Apply suggested fix directly.";
        }
        if (confidence < 70) {
            return "Low confidence. Manual investigation recommended.";
        }
        return "Review the suggested fix and verify against the full build log.";
    }

    private LogParseResult withMatches(LogParseResult base, List<PatternMatchResult> matches) {
        return new LogParseResult(
                base.primaryCategory(), base.confidenceScore(), base.rootCause(),
                base.suggestedFix(), base.affectedModule(), base.relevantClasses(),
                base.sqlObjects(), base.logSnippet(), base.recommendation(),
                base.severity(), matches
        );
    }
}
