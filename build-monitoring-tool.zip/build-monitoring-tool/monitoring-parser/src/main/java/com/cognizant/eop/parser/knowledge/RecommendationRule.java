package com.cognizant.eop.parser.knowledge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record RecommendationRule(
        String condition,
        String message
) {}
