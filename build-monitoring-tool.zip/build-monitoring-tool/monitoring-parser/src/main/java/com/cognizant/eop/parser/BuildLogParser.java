package com.cognizant.eop.parser;

import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.parser.model.LogParseResult;

/**
 * Parses build console logs and extracts failure classification signals from the knowledge base.
 */
public interface BuildLogParser {

    /**
     * Parses a build log and returns structured failure analysis signals.
     *
     * @param buildLog raw build console output
     * @return parse result with classification, confidence, and extracted details
     */
    LogParseResult parse(BuildLog buildLog);
}
