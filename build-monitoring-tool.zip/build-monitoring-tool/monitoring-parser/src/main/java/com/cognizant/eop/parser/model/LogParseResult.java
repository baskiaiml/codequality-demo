package com.cognizant.eop.parser.model;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;

import java.math.BigDecimal;
import java.util.List;

/**
 * Structured result of parsing a build log against the knowledge base.
 * Consumed by the AI analysis module to produce {@code AIAnalysis}.
 *
 * @param primaryCategory  best-matching failure category
 * @param confidenceScore  confidence level (0.00–100.00)
 * @param rootCause        human-readable root cause from pattern template
 * @param suggestedFix     actionable fix recommendation
 * @param affectedModule   module or package affected
 * @param relevantClasses  Java classes extracted from the log
 * @param sqlObjects       SQL objects extracted from the log
 * @param logSnippet       relevant excerpt from the build log
 * @param recommendation   broader recommendation based on confidence rules
 * @param severity         estimated severity
 * @param allMatches       all pattern matches found (ordered by confidence descending)
 */
public record LogParseResult(
        FailureCategory primaryCategory,
        BigDecimal confidenceScore,
        String rootCause,
        String suggestedFix,
        String affectedModule,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String logSnippet,
        String recommendation,
        Severity severity,
        List<PatternMatchResult> allMatches
) {
    public static LogParseResult unknown(String logSnippet) {
        return new LogParseResult(
                FailureCategory.UNKNOWN_FAILURE,
                BigDecimal.ZERO,
                "Unable to classify failure from build log",
                "Review the full build log manually to identify the root cause",
                null,
                List.of(),
                List.of(),
                logSnippet,
                "No knowledge base pattern matched. Manual investigation required.",
                Severity.MEDIUM,
                List.of()
        );
    }
}
