package com.cognizant.eop.parser.preprocessor;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Normalizes and prepares raw build log content for pattern matching.
 */
public class LogPreprocessor {

    private static final int DEFAULT_MAX_LENGTH = 50_000;
    private static final Pattern ANSI_ESCAPE = Pattern.compile("\u001B\\[[\\d;]*[mK]");
    private static final Pattern CARRIAGE_RETURN = Pattern.compile("\\r\\n?");
    private static final Pattern CONSECUTIVE_BLANK_LINES = Pattern.compile("\\n{3,}");

    private final int maxLength;

    public LogPreprocessor() {
        this(DEFAULT_MAX_LENGTH);
    }

    public LogPreprocessor(int maxLength) {
        this.maxLength = maxLength;
    }

    /**
     * Preprocesses raw log content into normalized lines.
     */
    public PreprocessedLog preprocess(String rawContent) {
        if (rawContent == null || rawContent.isBlank()) {
            return new PreprocessedLog("", List.of(), List.of());
        }

        String normalized = ANSI_ESCAPE.matcher(rawContent).replaceAll("");
        normalized = CARRIAGE_RETURN.matcher(normalized).replaceAll("\n");
        normalized = CONSECUTIVE_BLANK_LINES.matcher(normalized).replaceAll("\n\n");

        if (normalized.length() > maxLength) {
            normalized = normalized.substring(normalized.length() - maxLength);
        }

        List<String> lines = List.of(normalized.split("\n", -1));
        List<String> deduplicated = deduplicateConsecutiveLines(lines);
        List<String> errorBlocks = extractErrorBlocks(deduplicated);

        return new PreprocessedLog(String.join("\n", deduplicated), deduplicated, errorBlocks);
    }

    private List<String> deduplicateConsecutiveLines(List<String> lines) {
        List<String> result = new ArrayList<>(lines.size());
        String previous = null;
        for (String line : lines) {
            if (line.equals(previous)) {
                continue;
            }
            result.add(line);
            previous = line;
        }
        return result;
    }

    private List<String> extractErrorBlocks(List<String> lines) {
        Set<String> blocks = new LinkedHashSet<>();
        for (String line : lines) {
            if (isErrorLine(line)) {
                blocks.add(line.trim());
            }
        }
        return List.copyOf(blocks);
    }

    private boolean isErrorLine(String line) {
        String lower = line.toLowerCase();
        return lower.contains("error")
                || lower.contains("failed")
                || lower.contains("failure")
                || lower.contains("exception")
                || lower.contains("ora-")
                || lower.contains("conflict")
                || lower.contains("fatal");
    }

    /**
     * Result of log preprocessing.
     *
     * @param content     full normalized log text
     * @param lines       normalized log lines
     * @param errorBlocks lines identified as error-related
     */
    public record PreprocessedLog(
            String content,
            List<String> lines,
            List<String> errorBlocks
    ) {}
}
