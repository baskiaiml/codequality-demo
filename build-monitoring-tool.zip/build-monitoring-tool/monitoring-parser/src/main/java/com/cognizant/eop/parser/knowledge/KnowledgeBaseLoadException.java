package com.cognizant.eop.parser.knowledge;

/**
 * Thrown when a knowledge base file cannot be loaded or parsed.
 */
public class KnowledgeBaseLoadException extends RuntimeException {

    public KnowledgeBaseLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}
