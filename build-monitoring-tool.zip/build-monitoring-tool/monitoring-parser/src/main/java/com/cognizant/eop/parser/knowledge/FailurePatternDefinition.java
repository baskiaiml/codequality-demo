package com.cognizant.eop.parser.knowledge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record FailurePatternDefinition(
        String id,
        String regex,
        int confidence,
        String rootCauseTemplate,
        String suggestedFixTemplate,
        List<Integer> extractGroups,
        String classExtractor,
        String sqlExtractor,
        String moduleExtractor
) {
    public FailurePatternDefinition {
        if (extractGroups == null) {
            extractGroups = List.of();
        }
    }
}
