package com.cognizant.eop.parser.knowledge;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Loads failure patterns dynamically from YAML knowledge base files on the classpath.
 * Adding new failure types requires only a new YAML file — no code changes.
 */
public class KnowledgeBaseLoader {

    private static final Logger log = LoggerFactory.getLogger(KnowledgeBaseLoader.class);

    static final List<String> KNOWLEDGE_BASE_FILES = List.of(
            "knowledge-base/compilation-patterns.yaml",
            "knowledge-base/junit-patterns.yaml",
            "knowledge-base/merge-conflict-patterns.yaml",
            "knowledge-base/liquibase-patterns.yaml",
            "knowledge-base/oracle-patterns.yaml",
            "knowledge-base/maven-patterns.yaml",
            "knowledge-base/gradle-patterns.yaml",
            "knowledge-base/docker-patterns.yaml",
            "knowledge-base/git-patterns.yaml",
            "knowledge-base/timeout-patterns.yaml",
            "knowledge-base/environment-patterns.yaml",
            "knowledge-base/infrastructure-patterns.yaml",
            "knowledge-base/dependency-patterns.yaml"
    );

    private final ObjectMapper yamlMapper;
    private final ClassLoader classLoader;
    private List<KnowledgeBaseEntry> entries = List.of();
    private List<CompiledPattern> compiledPatterns = List.of();

    public KnowledgeBaseLoader() {
        this(KnowledgeBaseLoader.class.getClassLoader());
    }

    KnowledgeBaseLoader(ClassLoader classLoader) {
        this.classLoader = classLoader;
        this.yamlMapper = new ObjectMapper(new YAMLFactory());
    }

    /**
     * Loads and compiles all knowledge base pattern files.
     */
    public void load() {
        List<KnowledgeBaseEntry> loaded = new ArrayList<>();
        List<CompiledPattern> compiled = new ArrayList<>();

        for (String file : KNOWLEDGE_BASE_FILES) {
            loadFile(file).ifPresent(entry -> {
                loaded.add(entry);
                compilePatterns(entry, compiled);
            });
        }

        this.entries = List.copyOf(loaded);
        this.compiledPatterns = List.copyOf(compiled);
        log.info("Knowledge base loaded: {} categories, {} patterns", entries.size(), compiledPatterns.size());
    }

    public List<KnowledgeBaseEntry> getEntries() {
        return entries;
    }

    public List<CompiledPattern> getCompiledPatterns() {
        return compiledPatterns;
    }

    private java.util.Optional<KnowledgeBaseEntry> loadFile(String resourcePath) {
        try (InputStream inputStream = classLoader.getResourceAsStream(resourcePath)) {
            if (inputStream == null) {
                log.warn("Knowledge base file not found: {}", resourcePath);
                return java.util.Optional.empty();
            }
            KnowledgeBaseEntry entry = yamlMapper.readValue(inputStream, KnowledgeBaseEntry.class);
            return java.util.Optional.of(entry);
        } catch (IOException ex) {
            throw new KnowledgeBaseLoadException("Failed to load knowledge base file: " + resourcePath, ex);
        }
    }

    private void compilePatterns(KnowledgeBaseEntry entry, List<CompiledPattern> compiled) {
        for (FailurePatternDefinition pattern : entry.patterns()) {
            try {
                compiled.add(new CompiledPattern(
                        entry,
                        pattern,
                        Pattern.compile(pattern.regex(), Pattern.CASE_INSENSITIVE | Pattern.MULTILINE),
                        compileOptional(pattern.classExtractor()),
                        compileOptional(pattern.sqlExtractor()),
                        compileOptional(pattern.moduleExtractor())
                ));
            } catch (PatternSyntaxException ex) {
                log.error("Invalid regex in pattern {}: {}", pattern.id(), ex.getMessage());
            }
        }
    }

    private Pattern compileOptional(String regex) {
        if (regex == null || regex.isBlank()) {
            return null;
        }
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);
    }

    /**
     * A pre-compiled pattern bound to its knowledge base entry.
     */
    public record CompiledPattern(
            KnowledgeBaseEntry entry,
            FailurePatternDefinition definition,
            Pattern linePattern,
            Pattern classExtractor,
            Pattern sqlExtractor,
            Pattern moduleExtractor
    ) {}
}
