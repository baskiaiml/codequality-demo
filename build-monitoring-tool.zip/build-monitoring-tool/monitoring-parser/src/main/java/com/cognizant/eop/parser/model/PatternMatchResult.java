package com.cognizant.eop.parser.model;

import com.cognizant.eop.api.model.FailureCategory;

import java.util.List;

/**
 * A single pattern match against a build log line.
 */
public record PatternMatchResult(
        String patternId,
        FailureCategory category,
        int confidence,
        String matchedLine,
        int lineNumber,
        List<String> extractedGroups,
        String rootCause,
        String suggestedFix,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String affectedModule
) {}
