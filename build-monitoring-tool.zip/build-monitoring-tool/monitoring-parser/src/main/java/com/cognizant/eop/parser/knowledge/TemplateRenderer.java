package com.cognizant.eop.parser.knowledge;

import java.util.List;

/**
 * Applies template placeholders using extracted regex groups.
 */
public final class TemplateRenderer {

    private TemplateRenderer() {
    }

    public static String render(String template, List<String> groups) {
        if (template == null || template.isBlank()) {
            return "";
        }
        String result = template;
        for (int i = 0; i < groups.size(); i++) {
            String value = groups.get(i) != null ? groups.get(i) : "";
            result = result.replace("{" + i + "}", value);
        }
        return result;
    }
}
