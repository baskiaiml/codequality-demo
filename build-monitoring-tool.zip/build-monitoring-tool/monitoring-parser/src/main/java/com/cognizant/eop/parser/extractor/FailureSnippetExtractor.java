package com.cognizant.eop.parser.extractor;

import com.cognizant.eop.parser.model.PatternMatchResult;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor.PreprocessedLog;

import java.util.List;

/**
 * Extracts a concise, relevant snippet from the build log around the best pattern match.
 */
public class FailureSnippetExtractor {

    private static final int CONTEXT_BEFORE = 3;
    private static final int CONTEXT_AFTER = 8;
    private static final int MAX_SNIPPET_LENGTH = 2_000;

    /**
     * Extracts a log snippet centered on the best match line.
     */
    public String extract(PreprocessedLog preprocessedLog, PatternMatchResult bestMatch) {
        if (bestMatch == null) {
            return truncate(preprocessedLog.content());
        }

        List<String> lines = preprocessedLog.lines();
        if (bestMatch.lineNumber() <= 0 || bestMatch.lineNumber() > lines.size()) {
            return truncate(bestMatch.matchedLine());
        }

        int matchIndex = bestMatch.lineNumber() - 1;
        int start = Math.max(0, matchIndex - CONTEXT_BEFORE);
        int end = Math.min(lines.size(), matchIndex + CONTEXT_AFTER + 1);

        String snippet = String.join("\n", lines.subList(start, end));
        return truncate(snippet);
    }

    private String truncate(String content) {
        if (content == null) {
            return "";
        }
        if (content.length() <= MAX_SNIPPET_LENGTH) {
            return content;
        }
        return content.substring(0, MAX_SNIPPET_LENGTH) + "\n... (truncated)";
    }
}
