package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.core.dto.JobSummaryResponse;
import com.cognizant.eop.core.service.JobBuildProcessingService;
import com.cognizant.eop.core.service.JobService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import com.cognizant.eop.core.config.SecurityConfig;
import com.cognizant.eop.core.config.WebConfig;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.jwt.JwtTokenService;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = JobAdminController.class)
@Import({SecurityConfig.class, WebConfig.class})
@ImportAutoConfiguration(SecurityAutoConfiguration.class)
class JobAdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobService jobService;

    @MockBean
    private JobBuildProcessingService jobBuildProcessingService;

    @MockBean
    private AuditRecorder auditRecorder;

    @MockBean
    private JwtTokenService jwtTokenService;

    @MockBean
    private SecurityProperties securityProperties;

    @Test
    @WithMockUser(roles = "ADMINISTRATOR")
    void registerForMonitoring_adminUser_returnsJob() throws Exception {
        when(jobService.registerForMonitoring(eq(1L), eq("BuildType_A")))
                .thenReturn(new JobSummaryResponse(
                        1L, "BuildType_A", "Build A", "main", "BuildType_A",
                        true, true, 1L, "Alpha Team", null));

        mockMvc.perform(post("/api/v1/admin/jobs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"teamId":1,"externalId":"BuildType_A"}
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.externalId").value("BuildType_A"))
                .andExpect(jsonPath("$.pollingEnabled").value(true));

        verify(jobService).registerForMonitoring(1L, "BuildType_A");
        verify(auditRecorder).record(org.mockito.ArgumentMatchers.any());
    }

    @Test
    @WithMockUser(roles = "ADMINISTRATOR")
    void removeFromMonitoring_adminUser_returnsJob() throws Exception {
        when(jobService.removeFromMonitoring("BuildType_A"))
                .thenReturn(new JobSummaryResponse(
                        1L, "BuildType_A", "Build A", "main", "BuildType_A",
                        false, false, 1L, "Alpha Team", null));

        mockMvc.perform(delete("/api/v1/admin/jobs/BuildType_A"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pollingEnabled").value(false));

        verify(jobService).removeFromMonitoring("BuildType_A");
        verify(auditRecorder).record(org.mockito.ArgumentMatchers.any());
    }

    @Test
    @WithMockUser(roles = "ADMINISTRATOR")
    void syncJobs_adminUser_returnsSyncedCount() throws Exception {
        when(jobService.syncJobsFromProvider()).thenReturn(42);

        mockMvc.perform(post("/api/v1/admin/jobs/sync").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.jobsSynced").value(42));

        verify(jobService).syncJobsFromProvider();
        verify(auditRecorder).record(org.mockito.ArgumentMatchers.any());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void syncJobs_viewerForbidden() throws Exception {
        mockMvc.perform(post("/api/v1/admin/jobs/sync"))
                .andExpect(status().isForbidden());
    }
}
