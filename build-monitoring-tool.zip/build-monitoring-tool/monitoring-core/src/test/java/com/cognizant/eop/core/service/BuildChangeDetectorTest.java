package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BuildChangeDetectorTest {

    private BuildChangeDetector detector;

    @BeforeEach
    void setUp() {
        detector = new BuildChangeDetector();
    }

    @Test
    void detect_noCurrentBuild_returnsUnchanged() {
        Build lastKnown = build("build-1", 100, BuildStatus.SUCCESS);

        BuildChangeResult result = detector.detect(lastKnown, null);

        assertEquals(BuildChangeType.UNCHANGED, result.changeType());
    }

    @Test
    void detect_firstPoll_returnsNewBuild() {
        Build current = build("build-1", 100, BuildStatus.SUCCESS);

        BuildChangeResult result = detector.detect(null, current);

        assertEquals(BuildChangeType.NEW_BUILD, result.changeType());
    }

    @Test
    void detect_firstPollWithFailure_returnsFailure() {
        Build current = build("build-1", 100, BuildStatus.FAILURE);

        BuildChangeResult result = detector.detect(null, current);

        assertEquals(BuildChangeType.FAILURE, result.changeType());
        assertTrue(result.requiresFailureProcessing());
    }

    @Test
    void detect_sameBuildSameStatus_returnsUnchanged() {
        Build lastKnown = build("build-1", 100, BuildStatus.RUNNING);
        Build current = build("build-1", 100, BuildStatus.RUNNING);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.UNCHANGED, result.changeType());
        assertFalse(result.hasChanged());
    }

    @Test
    void detect_runningToFailure_returnsFailure() {
        Build lastKnown = build("build-1", 100, BuildStatus.RUNNING);
        Build current = build("build-1", 100, BuildStatus.FAILURE);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.FAILURE, result.changeType());
    }

    @Test
    void detect_runningToSuccess_returnsStatusChanged() {
        Build lastKnown = build("build-1", 100, BuildStatus.RUNNING);
        Build current = build("build-1", 100, BuildStatus.SUCCESS);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.STATUS_CHANGED, result.changeType());
    }

    @Test
    void detect_newBuildNumber_returnsNewBuild() {
        Build lastKnown = build("build-1", 100, BuildStatus.SUCCESS);
        Build current = build("build-2", 101, BuildStatus.SUCCESS);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.NEW_BUILD, result.changeType());
    }

    @Test
    void detect_failureToSuccess_returnsRecovery() {
        Build lastKnown = build("build-1", 100, BuildStatus.FAILURE);
        Build current = build("build-2", 101, BuildStatus.SUCCESS);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.RECOVERY, result.changeType());
        assertTrue(result.requiresRecoveryNotification());
    }

    @Test
    void detect_failureToNewFailure_returnsFailure() {
        Build lastKnown = build("build-1", 100, BuildStatus.FAILURE);
        Build current = build("build-2", 101, BuildStatus.FAILURE);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.FAILURE, result.changeType());
    }

    @Test
    void detect_cancelledBuild_returnsNewBuild() {
        Build lastKnown = build("build-1", 100, BuildStatus.SUCCESS);
        Build current = build("build-2", 101, BuildStatus.CANCELLED);

        BuildChangeResult result = detector.detect(lastKnown, current);

        assertEquals(BuildChangeType.NEW_BUILD, result.changeType());
    }

    @Test
    void detect_queuedBuild_returnsNewBuild() {
        Build current = build("build-1", 100, BuildStatus.QUEUED);

        BuildChangeResult result = detector.detect(null, current);

        assertEquals(BuildChangeType.NEW_BUILD, result.changeType());
    }

    private Build build(String id, int number, BuildStatus status) {
        return new Build(
                id, "job-1", number, status, "main",
                Instant.parse("2026-06-29T06:00:00Z"),
                status == BuildStatus.RUNNING ? null : Instant.parse("2026-06-29T06:05:00Z"),
                300000L, "developer", "http://build/" + id
        );
    }
}
