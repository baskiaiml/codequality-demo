package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.core.service.JobBuildProcessingService;
import com.cognizant.eop.security.model.AuthenticatedUser;
import com.cognizant.eop.security.jwt.JwtTokenService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ProcessBuildsIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtTokenService jwtTokenService;

    @MockBean
    private JobBuildProcessingService jobBuildProcessingService;

    @Test
    void processBuilds_withValidJwt_returnsOk() throws Exception {
        String token = jwtTokenService.generateToken(new AuthenticatedUser(
                "admin",
                UserRole.ADMINISTRATOR,
                null,
                "System Administrator",
                "admin@titan.internal"
        ));
        when(jobBuildProcessingService.processBuilds(eq("KidsPiggyBank_KidsPiggybankLocal")))
                .thenReturn(List.of());

        mockMvc.perform(post("/api/v1/jobs/KidsPiggyBank_KidsPiggybankLocal/process-builds")
                        .header("Authorization", "Bearer " + token)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void processBuildsAdminPath_withValidJwt_returnsOk() throws Exception {
        String token = jwtTokenService.generateToken(new AuthenticatedUser(
                "admin",
                UserRole.ADMINISTRATOR,
                null,
                "System Administrator",
                "admin@titan.internal"
        ));
        when(jobBuildProcessingService.processBuilds(eq("KidsPiggyBank_KidsPiggybankLocal")))
                .thenReturn(List.of());

        mockMvc.perform(post("/api/v1/admin/jobs/KidsPiggyBank_KidsPiggybankLocal/process-builds")
                        .header("Authorization", "Bearer " + token)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
