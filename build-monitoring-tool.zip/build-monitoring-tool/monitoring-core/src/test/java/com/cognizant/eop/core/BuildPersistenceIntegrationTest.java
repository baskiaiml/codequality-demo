package com.cognizant.eop.core;

import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.service.BuildChangeType;
import com.cognizant.eop.core.service.BuildPersistenceService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Testcontainers(disabledWithoutDocker = true)
class BuildPersistenceIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("eop_test")
            .withUsername("eop")
            .withPassword("eop");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private BuildPersistenceService buildPersistenceService;

    @Autowired
    private BuildRepository buildRepository;

    @Autowired
    private JobRepository jobRepository;

    @Test
    void seedData_containsSixPollingJobs() {
        assertEquals(6, jobRepository.findByEnabledTrueAndPollingEnabledTrue().size());
    }

    @Test
    void processNewBuildsSinceLastKnown_persistsAllMockBuilds() {
        List<com.cognizant.eop.core.service.BuildChangeResult> results =
                buildPersistenceService.processNewBuildsSinceLastKnown("job-fo-alpha-instream");

        assertFalse(results.isEmpty());
        assertEquals(2, results.size());
        assertEquals(2, buildRepository.findByJobIdOrderByBuildNumberDesc(
                jobRepository.findByExternalId("job-fo-alpha-instream").orElseThrow().getId()).size());
    }

    @Test
    void processLatestBuild_secondPoll_returnsUnchanged() {
        buildPersistenceService.processNewBuildsSinceLastKnown("job-fo-beta-staging");

        var result = buildPersistenceService.processLatestBuild("job-fo-beta-staging");

        assertTrue(result.isPresent());
        assertEquals(BuildChangeType.UNCHANGED, result.get().changeType());
    }

    @Test
    void processLatestBuild_failureBuild_detectsFailure() {
        var result = buildPersistenceService.processLatestBuild("job-fo-alpha-instream");

        assertTrue(result.isPresent());
        assertEquals(BuildChangeType.FAILURE, result.get().changeType());
    }
}
