package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuildFailureProcessingServiceTest {

    @Mock
    private BuildRepository buildRepository;
    @Mock
    private FailureAnalysisService failureAnalysisService;
    @Mock
    private NotificationDispatchService notificationDispatchService;

    private BuildFailureProcessingService service;

    @BeforeEach
    void setUp() {
        service = new BuildFailureProcessingService(
                buildRepository, failureAnalysisService, notificationDispatchService);
    }

    @Test
    void analyzeAndNotify_dispatchesFailureNotificationForNewAnalysis() {
        BuildEntity build = buildEntity();
        FailureEntity failure = new FailureEntity();
        failure.setCategory(FailureCategory.COMPILATION_ERROR);
        FailureAnalysisResult analysisResult =
                new FailureAnalysisResult(failure, FailureAnalysisOutcome.CREATED);

        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(failureAnalysisService.analyzeAndPersist("build-1001")).thenReturn(analysisResult);
        when(notificationDispatchService.dispatchBuildFailure("build-1001", "job-fo-alpha-instream"))
                .thenReturn(1);

        FailureProcessingResult result = service.analyzeAndNotify("build-1001");

        assertEquals(1, result.notificationsSent());
        verify(notificationDispatchService).dispatchBuildFailure("build-1001", "job-fo-alpha-instream");
    }

    @Test
    void analyzeAndNotify_backfillsNotificationWhenAnalysisUnchanged() {
        BuildEntity build = buildEntity();
        FailureEntity failure = new FailureEntity();
        failure.setCategory(FailureCategory.COMPILATION_ERROR);
        FailureAnalysisResult analysisResult =
                new FailureAnalysisResult(failure, FailureAnalysisOutcome.UNCHANGED);

        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(failureAnalysisService.analyzeAndPersist("build-1001")).thenReturn(analysisResult);
        when(notificationDispatchService.dispatchBuildFailure("build-1001", "job-fo-alpha-instream"))
                .thenReturn(1);

        FailureProcessingResult result = service.analyzeAndNotify("build-1001");

        assertEquals(1, result.notificationsSent());
        verify(notificationDispatchService).dispatchBuildFailure("build-1001", "job-fo-alpha-instream");
    }

    private BuildEntity buildEntity() {
        JobEntity job = new JobEntity();
        job.setExternalId("job-fo-alpha-instream");

        BuildEntity build = new BuildEntity();
        build.setExternalId("build-1001");
        build.setJob(job);
        return build;
    }
}
