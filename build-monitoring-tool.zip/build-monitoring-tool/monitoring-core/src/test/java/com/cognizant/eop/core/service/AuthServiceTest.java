package com.cognizant.eop.core.service;

import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.core.dto.LoginRequest;
import com.cognizant.eop.core.dto.LoginResponse;
import com.cognizant.eop.core.entity.AppUserEntity;
import com.cognizant.eop.core.repository.AppUserRepository;
import com.cognizant.eop.core.repository.AuditEventRepository;
import com.cognizant.eop.security.jwt.JwtTokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class AuthServiceTest {

    @Autowired
    private AuthService authService;

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    private AuditEventRepository auditEventRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenService jwtTokenService;

    @BeforeEach
    void seedUser() {
        AppUserEntity user = new AppUserEntity();
        user.setUsername("tester");
        user.setPasswordHash(passwordEncoder.encode("secret"));
        user.setDisplayName("Test User");
        user.setEmail("tester@titan.internal");
        user.setRole(UserRole.DEVELOPER);
        user.setTeamId(1L);
        appUserRepository.save(user);
    }

    @Test
    void login_validCredentials_returnsTokenAndAuditsLogin() {
        LoginResponse response = authService.login(new LoginRequest("tester", "secret"));

        assertNotNull(response.token());
        assertEquals("tester", response.user().username());
        assertEquals(UserRole.DEVELOPER, response.user().role());
        assertEquals(jwtTokenService.getExpirationMs(), response.expiresInMs());
        assertEquals(1, auditEventRepository.countByEventType(AuditEventType.USER_LOGIN));
    }

    @Test
    void login_invalidPassword_throwsAndAuditsFailure() {
        assertThrows(InvalidCredentialsException.class,
                () -> authService.login(new LoginRequest("tester", "wrong")));
        assertEquals(1, auditEventRepository.countByEventType(AuditEventType.USER_LOGIN_FAILED));
    }
}
