package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.service.JobBuildProcessingService;
import com.cognizant.eop.core.service.JobQueryService;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.jwt.JwtTokenService;
import com.cognizant.eop.security.model.AuthenticatedUser;
import com.cognizant.eop.api.security.UserRole;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.cognizant.eop.core.config.SecurityConfig;
import com.cognizant.eop.core.config.WebConfig;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = JobController.class)
@Import({SecurityConfig.class, WebConfig.class})
@ImportAutoConfiguration(SecurityAutoConfiguration.class)
class JobControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobQueryService jobQueryService;

    @MockBean
    private JobBuildProcessingService jobBuildProcessingService;

    @MockBean
    private JwtTokenService jwtTokenService;

    @MockBean
    private SecurityProperties securityProperties;

    private String adminToken;
    private AuthenticatedUser adminUser;

    @BeforeEach
    void setUp() {
        when(securityProperties.jwtSecret()).thenReturn("dev-only-change-me-use-at-least-32-characters");
        when(securityProperties.jwtExpirationMs()).thenReturn(86400000L);
        JwtTokenService tokenService = new JwtTokenService(securityProperties);
        adminUser = new AuthenticatedUser(
                "admin",
                UserRole.ADMINISTRATOR,
                null,
                "System Administrator",
                "admin@titan.internal"
        );
        adminToken = tokenService.generateToken(adminUser);
        when(jwtTokenService.parseToken(eq(adminToken))).thenReturn(adminUser);
    }

    @Test
    void processBuilds_withJwtToken_allowsAdministrator() throws Exception {
        mockMvc.perform(post("/api/v1/jobs/KidsPiggyBank_KidsPiggybankLocal/process-builds")
                        .header("Authorization", "Bearer " + adminToken)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void processBuilds_withoutToken_returnsUnauthorized() throws Exception {
        mockMvc.perform(post("/api/v1/jobs/KidsPiggyBank_KidsPiggybankLocal/process-builds"))
                .andExpect(status().isUnauthorized());
    }
}
