package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.core.dto.CreateTeamRequest;
import com.cognizant.eop.core.dto.TeamResponse;
import com.cognizant.eop.core.service.OrganizationAdminService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import com.cognizant.eop.core.config.SecurityConfig;
import com.cognizant.eop.core.config.WebConfig;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.jwt.JwtTokenService;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = TeamAdminController.class)
@Import({SecurityConfig.class, WebConfig.class})
@ImportAutoConfiguration(SecurityAutoConfiguration.class)
class TeamAdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrganizationAdminService organizationAdminService;

    @MockBean
    private AuditRecorder auditRecorder;

    @MockBean
    private JwtTokenService jwtTokenService;

    @MockBean
    private SecurityProperties securityProperties;

    @Test
    @WithMockUser(roles = "ADMINISTRATOR")
    void createTeam_adminUser_returnsCreatedTeam() throws Exception {
        when(organizationAdminService.createTeam(any(CreateTeamRequest.class)))
                .thenReturn(new TeamResponse(10L, "Ops Team", 1L, "Front Office", "ops@example.com", true, 0));

        mockMvc.perform(post("/api/v1/admin/teams")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"groupId":1,"name":"Ops Team","email":"ops@example.com"}
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.name").value("Ops Team"));

        verify(organizationAdminService).createTeam(any(CreateTeamRequest.class));
        verify(auditRecorder).record(org.mockito.ArgumentMatchers.any());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void createTeam_viewerForbidden() throws Exception {
        mockMvc.perform(post("/api/v1/admin/teams")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"groupId":1,"name":"Ops Team"}
                                """))
                .andExpect(status().isForbidden());
    }
}
