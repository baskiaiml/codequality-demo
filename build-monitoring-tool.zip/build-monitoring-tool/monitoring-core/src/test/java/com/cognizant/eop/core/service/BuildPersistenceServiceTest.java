package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.mapper.BuildMapper;
import com.cognizant.eop.core.repository.BuildCommitRepository;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuildPersistenceServiceTest {

    @Mock
    private BuildRepository buildRepository;

    @Mock
    private BuildCommitRepository buildCommitRepository;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private BuildMapper buildMapper;

    @Mock
    private BuildChangeDetector changeDetector;

    @Mock
    private BuildProvider buildProvider;

    @InjectMocks
    private BuildPersistenceService buildPersistenceService;

    @Test
    void processLatestBuild_unchangedBuild_doesNotPersist() {
        JobEntity job = jobWithId(1L, "job-fo-alpha-instream");
        Build current = build("build-1001", 1523, BuildStatus.FAILURE);
        Build lastKnown = current;

        when(jobRepository.findByExternalId("job-fo-alpha-instream")).thenReturn(Optional.of(job));
        when(buildProvider.getLatestBuild("job-fo-alpha-instream")).thenReturn(current);
        when(buildRepository.findTopByJobIdOrderByBuildNumberDesc(1L)).thenReturn(Optional.of(new BuildEntity()));
        when(buildMapper.toDomain(any(BuildEntity.class))).thenReturn(lastKnown);
        when(changeDetector.detect(lastKnown, current))
                .thenReturn(new BuildChangeResult(BuildChangeType.UNCHANGED, lastKnown, current));

        Optional<BuildChangeResult> result = buildPersistenceService.processLatestBuild("job-fo-alpha-instream");

        assertTrue(result.isPresent());
        assertEquals(BuildChangeType.UNCHANGED, result.get().changeType());
        verify(buildRepository, never()).save(any());
    }

    @Test
    void processLatestBuild_newFailure_persistsBuildAndCommits() {
        JobEntity job = jobWithId(1L, "job-fo-alpha-instream");
        Build current = build("build-1001", 1523, BuildStatus.FAILURE);
        BuildEntity entity = new BuildEntity();
        entity.setId(10L);

        when(jobRepository.findByExternalId("job-fo-alpha-instream")).thenReturn(Optional.of(job));
        when(buildProvider.getLatestBuild("job-fo-alpha-instream")).thenReturn(current);
        when(buildRepository.findTopByJobIdOrderByBuildNumberDesc(1L)).thenReturn(Optional.empty());
        when(changeDetector.detect(null, current))
                .thenReturn(new BuildChangeResult(BuildChangeType.FAILURE, null, current));
        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.empty());
        when(buildMapper.toEntity(current, job)).thenReturn(entity);
        when(buildRepository.save(entity)).thenReturn(entity);
        when(buildProvider.getChanges("build-1001")).thenReturn(List.of(
                new Commit("abc123", "jsmith", "Fix bug", Instant.now())
        ));
        when(buildMapper.toCommitEntity(any(), any())).thenReturn(new com.cognizant.eop.core.entity.BuildCommitEntity());

        Optional<BuildChangeResult> result = buildPersistenceService.processLatestBuild("job-fo-alpha-instream");

        assertTrue(result.isPresent());
        assertEquals(BuildChangeType.FAILURE, result.get().changeType());
        verify(buildRepository).save(entity);
        verify(buildCommitRepository).deleteByBuildId(10L);
    }

    private JobEntity jobWithId(Long id, String externalId) {
        JobEntity job = new JobEntity();
        job.setId(id);
        job.setExternalId(externalId);
        return job;
    }

    private Build build(String id, int number, BuildStatus status) {
        return new Build(
                id, "job-fo-alpha-instream", number, status, "fo/alpha/instream",
                Instant.now(), Instant.now(), 300000L, "jsmith", "http://build/" + id
        );
    }
}
