package com.cognizant.eop.core.mapper;

import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.core.entity.BuildCommitEntity;
import com.cognizant.eop.core.entity.BuildEntity;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class BuildMapperTest {

    private final BuildMapper mapper = Mappers.getMapper(BuildMapper.class);

    @Test
    void toCommitEntity_mapsHashToCommitHash() {
        Commit commit = new Commit(
                "a1b2c3d4e5f6789012345678901234567890abcd",
                "jsmith",
                "Refactor CustomerDTO",
                Instant.parse("2026-06-29T06:10:00Z")
        );
        BuildEntity build = new BuildEntity();
        build.setId(1L);

        BuildCommitEntity entity = mapper.toCommitEntity(commit, build);

        assertNotNull(entity);
        assertEquals(commit.hash(), entity.getCommitHash());
        assertEquals(commit.author(), entity.getAuthor());
        assertEquals(commit.message(), entity.getMessage());
        assertEquals(build, entity.getBuild());
    }

    @Test
    void toCommitDomain_mapsCommitHashToHash() {
        BuildCommitEntity entity = new BuildCommitEntity();
        entity.setCommitHash("abc123");
        entity.setAuthor("jsmith");
        entity.setMessage("Fix bug");

        Commit commit = mapper.toCommitDomain(entity);

        assertEquals("abc123", commit.hash());
        assertEquals("jsmith", commit.author());
    }
}
