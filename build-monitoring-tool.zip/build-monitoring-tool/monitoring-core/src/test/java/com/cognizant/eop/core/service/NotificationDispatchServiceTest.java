package com.cognizant.eop.core.service;

import com.cognizant.eop.api.notification.NotificationChannel;
import com.cognizant.eop.api.notification.NotificationContext;
import com.cognizant.eop.api.notification.NotificationEventType;
import com.cognizant.eop.api.notification.NotificationMessage;
import com.cognizant.eop.api.notification.NotificationSender;
import com.cognizant.eop.api.notification.NotificationTemplateRenderer;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.entity.NotificationRuleEntity;
import com.cognizant.eop.core.entity.TeamEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.DeveloperRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.repository.NotificationRepository;
import com.cognizant.eop.core.repository.NotificationRuleRepository;
import com.cognizant.eop.core.scheduler.NotificationCycleTracker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationDispatchServiceTest {

    @Mock
    private NotificationRuleRepository notificationRuleRepository;
    @Mock
    private NotificationRepository notificationRepository;
    @Mock
    private JobRepository jobRepository;
    @Mock
    private BuildRepository buildRepository;
    @Mock
    private FailureRepository failureRepository;
    @Mock
    private DeveloperRepository developerRepository;
    @Mock
    private NotificationTemplateRenderer templateRenderer;
    @Mock
    private NotificationSender notificationSender;
    @Mock
    private PlatformConfigurationService platformConfigurationService;
    @Mock
    private NotificationCycleTracker notificationCycleTracker;

    private NotificationDispatchService service;

    @BeforeEach
    void setUp() {
        service = new NotificationDispatchService(
                notificationRuleRepository,
                notificationRepository,
                jobRepository,
                buildRepository,
                failureRepository,
                developerRepository,
                templateRenderer,
                notificationSender,
                platformConfigurationService,
                notificationCycleTracker
        );
    }

    @Test
    void dispatchBuildFailure_sendsAndPersistsNotification() {
        JobEntity job = jobWithTeam();
        BuildEntity build = buildEntity();
        FailureEntity failure = failureEntity(build);
        NotificationRuleEntity rule = rule("BUILD_FAILURE", "failure-notification");

        when(platformConfigurationService.isNotificationEnabled()).thenReturn(true);
        when(jobRepository.findByExternalId("job-fo-alpha-instream")).thenReturn(Optional.of(job));
        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(notificationRepository.existsByBuildIdAndNotificationType(1L, "BUILD_FAILURE")).thenReturn(false);
        when(failureRepository.findByBuildId(1L)).thenReturn(Optional.of(failure));
        when(notificationRuleRepository.findByEventTypeAndEnabledTrue("BUILD_FAILURE")).thenReturn(List.of(rule));
        when(developerRepository.findByUsername("jsmith")).thenReturn(Optional.empty());
        when(templateRenderer.render(eq("failure-notification"), any(NotificationContext.class)))
                .thenReturn(new NotificationTemplateRenderer.RenderedNotification(
                        "Build Failed",
                        "Root cause details"
                ));

        int sent = service.dispatchBuildFailure("build-1001", "job-fo-alpha-instream");

        assertEquals(1, sent);
        verify(notificationSender).send(any(NotificationMessage.class));
        verify(notificationRepository).save(any());
        verify(notificationCycleTracker).add(1);
    }

    @Test
    void dispatchBuildFailure_skipsWhenDisabled() {
        when(platformConfigurationService.isNotificationEnabled()).thenReturn(false);

        int sent = service.dispatchBuildFailure("build-1001", "job-fo-alpha-instream");

        assertEquals(0, sent);
        verify(notificationSender, never()).send(any());
    }

    @Test
    void dispatchBuildFailure_skipsDuplicate() {
        JobEntity job = jobWithTeam();
        BuildEntity build = buildEntity();

        when(platformConfigurationService.isNotificationEnabled()).thenReturn(true);
        when(jobRepository.findByExternalId("job-fo-alpha-instream")).thenReturn(Optional.of(job));
        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(notificationRepository.existsByBuildIdAndNotificationType(1L, "BUILD_FAILURE")).thenReturn(true);

        int sent = service.dispatchBuildFailure("build-1001", "job-fo-alpha-instream");

        assertEquals(0, sent);
        verify(notificationSender, never()).send(any());
    }

    @Test
    void dispatchBuildFailure_usesDeveloperEmailWhenAvailable() {
        JobEntity job = jobWithTeam();
        BuildEntity build = buildEntity();
        FailureEntity failure = failureEntity(build);
        NotificationRuleEntity rule = rule("BUILD_FAILURE", "failure-notification");

        when(platformConfigurationService.isNotificationEnabled()).thenReturn(true);
        when(jobRepository.findByExternalId("job-fo-alpha-instream")).thenReturn(Optional.of(job));
        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(notificationRepository.existsByBuildIdAndNotificationType(1L, "BUILD_FAILURE")).thenReturn(false);
        when(failureRepository.findByBuildId(1L)).thenReturn(Optional.of(failure));
        when(notificationRuleRepository.findByEventTypeAndEnabledTrue("BUILD_FAILURE")).thenReturn(List.of(rule));
        when(developerRepository.findByUsername("jsmith")).thenReturn(Optional.of(developer("jsmith@titan.internal")));
        when(templateRenderer.render(eq("failure-notification"), any(NotificationContext.class)))
                .thenReturn(new NotificationTemplateRenderer.RenderedNotification("Subject", "Body"));

        service.dispatchBuildFailure("build-1001", "job-fo-alpha-instream");

        ArgumentCaptor<NotificationMessage> captor = ArgumentCaptor.forClass(NotificationMessage.class);
        verify(notificationSender).send(captor.capture());
        assertEquals("jsmith@titan.internal", captor.getValue().recipient());
    }

    private JobEntity jobWithTeam() {
        TeamEntity team = new TeamEntity();
        team.setName("Alpha Team");
        team.setEmail("alpha-team@titan.internal");

        JobEntity job = new JobEntity();
        job.setExternalId("job-fo-alpha-instream");
        job.setName("Alpha Instream Build");
        job.setTeam(team);
        return job;
    }

    private BuildEntity buildEntity() {
        BuildEntity build = new BuildEntity();
        build.setId(1L);
        build.setExternalId("build-1001");
        build.setBuildNumber(1523);
        build.setBranch("fo/alpha/instream");
        build.setBuildUrl("http://build/1001");
        return build;
    }

    private FailureEntity failureEntity(BuildEntity build) {
        FailureEntity failure = new FailureEntity();
        failure.setBuild(build);
        failure.setCategory(FailureCategory.COMPILATION_ERROR);
        failure.setRootCause("Cannot find symbol CustomerDTO");
        failure.setPossibleOwner("jsmith");
        return failure;
    }

    private NotificationRuleEntity rule(String eventType, String templateName) {
        NotificationRuleEntity rule = new NotificationRuleEntity();
        rule.setEventType(eventType);
        rule.setChannel(NotificationChannel.EMAIL.name());
        rule.setTemplateName(templateName);
        rule.setEnabled(true);
        return rule;
    }

    private com.cognizant.eop.core.entity.DeveloperEntity developer(String email) {
        com.cognizant.eop.core.entity.DeveloperEntity developer = new com.cognizant.eop.core.entity.DeveloperEntity();
        developer.setEmail(email);
        return developer;
    }
}
