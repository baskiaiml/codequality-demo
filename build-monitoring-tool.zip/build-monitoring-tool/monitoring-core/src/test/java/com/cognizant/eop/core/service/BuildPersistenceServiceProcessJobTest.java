package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.mapper.BuildMapper;
import com.cognizant.eop.core.repository.BuildCommitRepository;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuildPersistenceServiceProcessJobTest {

    @Mock
    private BuildRepository buildRepository;

    @Mock
    private BuildCommitRepository buildCommitRepository;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private BuildMapper buildMapper;

    @Mock
    private BuildProvider buildProvider;

    private BuildChangeDetector changeDetector;
    private BuildPersistenceService service;

    @BeforeEach
    void setUp() {
        changeDetector = new BuildChangeDetector();
        service = new BuildPersistenceService(
                buildRepository, buildCommitRepository, jobRepository,
                buildMapper, changeDetector, buildProvider);
    }

    @Test
    void processJob_runningBuildStatusChange_detectsFailureWithoutNewBuildNumber() {
        JobEntity job = jobEntity(1L, "job-running");
        Build runningInDb = build("build-5001", 100, BuildStatus.RUNNING);
        Build failedInProvider = build("build-5001", 100, BuildStatus.FAILURE);

        BuildEntity entity = new BuildEntity();
        entity.setId(10L);
        entity.setExternalId("build-5001");
        entity.setBuildNumber(100);
        entity.setStatus(BuildStatus.RUNNING);

        when(jobRepository.findByExternalId("job-running")).thenReturn(Optional.of(job));
        when(buildRepository.findTopByJobIdOrderByBuildNumberDesc(1L)).thenReturn(Optional.of(entity));
        when(buildMapper.toDomain(entity)).thenReturn(runningInDb);
        when(buildProvider.getBuildHistory("job-running")).thenReturn(List.of(failedInProvider));
        when(buildProvider.getLatestBuild("job-running")).thenReturn(failedInProvider);
        when(buildRepository.findByExternalId("build-5001")).thenReturn(Optional.of(entity));
        when(buildProvider.getChanges("build-5001")).thenReturn(List.of());
        when(buildRepository.save(entity)).thenReturn(entity);

        List<BuildChangeResult> results = service.processJob("job-running");

        assertEquals(1, results.size());
        assertEquals(BuildChangeType.FAILURE, results.get(0).changeType());
        assertTrue(results.get(0).requiresFailureProcessing());
        verify(buildRepository).save(entity);
    }

    @Test
    void processJob_noChanges_returnsEmptyList() {
        JobEntity job = jobEntity(1L, "job-stable");
        Build build = build("build-1", 100, BuildStatus.SUCCESS);
        BuildEntity entity = new BuildEntity();
        entity.setId(10L);

        when(jobRepository.findByExternalId("job-stable")).thenReturn(Optional.of(job));
        when(buildRepository.findTopByJobIdOrderByBuildNumberDesc(1L)).thenReturn(Optional.of(entity));
        when(buildMapper.toDomain(entity)).thenReturn(build);
        when(buildProvider.getBuildHistory("job-stable")).thenReturn(List.of(build));
        when(buildProvider.getLatestBuild("job-stable")).thenReturn(build);

        List<BuildChangeResult> results = service.processJob("job-stable");

        assertTrue(results.isEmpty());
    }

    private JobEntity jobEntity(Long id, String externalId) {
        JobEntity job = new JobEntity();
        job.setId(id);
        job.setExternalId(externalId);
        return job;
    }

    private Build build(String id, int number, BuildStatus status) {
        return new Build(
                id, "job", number, status, "main",
                Instant.parse("2026-06-29T06:00:00Z"),
                status == BuildStatus.RUNNING ? null : Instant.parse("2026-06-29T06:05:00Z"),
                300000L, "dev", "http://build/" + id
        );
    }
}
