package com.cognizant.eop.core;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class EopApplicationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BuildProvider buildProvider;

    @Test
    void contextLoads() {
        // Verifies Spring context starts with all modules wired
    }

    @Test
    void healthEndpoint_returnsUp() throws Exception {
        mockMvc.perform(get("/api/v1/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
    }

    @Test
    void mockBuildProvider_isWiredAndReturnsJobs() {
        List<Job> jobs = buildProvider.getConfiguredJobs();

        assertFalse(jobs.isEmpty());
        assertEquals(6, jobs.size());
    }

    @Test
    void mockBuildProvider_returnsLatestBuild() {
        Build latest = buildProvider.getLatestBuild("job-fo-alpha-instream");

        assertEquals(1523, latest.buildNumber());
    }

    @Test
    void providerJobsEndpoint_returnsJobs() throws Exception {
        mockMvc.perform(get("/api/v1/provider/jobs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(6));
    }
}
