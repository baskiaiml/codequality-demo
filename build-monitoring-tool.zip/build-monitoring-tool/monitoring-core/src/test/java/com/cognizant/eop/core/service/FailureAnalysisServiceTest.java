package com.cognizant.eop.core.service;

import com.cognizant.eop.api.analyzer.AIAnalyzer;
import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.mapper.FailureAnalysisMapper;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FailureAnalysisServiceTest {

    @Mock
    private BuildRepository buildRepository;

    @Mock
    private FailureRepository failureRepository;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private BuildProvider buildProvider;

    @Mock
    private AIAnalyzer aiAnalyzer;

    @Mock
    private PlatformConfigurationService platformConfigurationService;

    private final FailureAnalysisMapper failureAnalysisMapper = Mappers.getMapper(FailureAnalysisMapper.class);

    private FailureAnalysisService service;

    @BeforeEach
    void setUp() {
        service = new FailureAnalysisService(
                buildRepository,
                failureRepository,
                jobRepository,
                buildProvider,
                aiAnalyzer,
                failureAnalysisMapper,
                platformConfigurationService
        );
    }

    @Test
    void analyzeAndPersist_persistsAnalysisWithOwnerFromCommit() {
        BuildEntity build = buildEntity("build-1001", "alice.dev");
        AIAnalysis analysis = sampleAnalysis(null);

        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(failureRepository.findByBuildId(1L)).thenReturn(Optional.empty());
        when(buildProvider.getBuildLog("build-1001")).thenReturn(new BuildLog("build-1001", "log"));
        when(aiAnalyzer.analyze(any())).thenReturn(analysis);
        when(platformConfigurationService.getConfidenceThreshold()).thenReturn(BigDecimal.valueOf(50));
        when(buildProvider.getChanges("build-1001")).thenReturn(List.of(
                new Commit("abc123", "bob.dev", "Fix compile error", Instant.now())
        ));
        when(failureRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        FailureAnalysisResult result = service.analyzeAndPersist("build-1001");

        assertEquals(FailureCategory.COMPILATION_ERROR, result.failure().getCategory());
        assertEquals("bob.dev", result.failure().getPossibleOwner());
        assertEquals(FailureAnalysisOutcome.CREATED, result.outcome());
        verify(failureRepository).save(any(FailureEntity.class));
    }

    @Test
    void analyzeAndPersist_skipsWhenRootCauseUnchanged() {
        BuildEntity build = buildEntity("build-1001", "alice.dev");
        FailureEntity existing = new FailureEntity();
        existing.setRootCause("Cannot find symbol CustomerDTO");
        existing.setCategory(FailureCategory.COMPILATION_ERROR);

        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(failureRepository.findByBuildId(1L)).thenReturn(Optional.of(existing));
        when(buildProvider.getBuildLog("build-1001")).thenReturn(new BuildLog("build-1001", "log"));
        when(aiAnalyzer.analyze(any())).thenReturn(sampleAnalysis("alice.dev"));
        when(platformConfigurationService.getConfidenceThreshold()).thenReturn(BigDecimal.valueOf(50));
        when(buildProvider.getChanges("build-1001")).thenReturn(List.of());

        FailureAnalysisResult result = service.analyzeAndPersist("build-1001");

        assertEquals(existing, result.failure());
        assertEquals(FailureAnalysisOutcome.UNCHANGED, result.outcome());
        verify(failureRepository, never()).save(any());
    }

    @Test
    void analyzeAndPersist_downgradesWhenBelowConfidenceThreshold() {
        BuildEntity build = buildEntity("build-1001", "alice.dev");
        AIAnalysis lowConfidence = new AIAnalysis(
                FailureCategory.COMPILATION_ERROR,
                BigDecimal.valueOf(30),
                "Uncertain match",
                "Review manually",
                null,
                null,
                List.of(),
                List.of(),
                "snippet",
                "Low confidence",
                "Impact",
                Severity.MEDIUM
        );

        when(buildRepository.findByExternalId("build-1001")).thenReturn(Optional.of(build));
        when(failureRepository.findByBuildId(1L)).thenReturn(Optional.empty());
        when(buildProvider.getBuildLog("build-1001")).thenReturn(new BuildLog("build-1001", "log"));
        when(aiAnalyzer.analyze(any())).thenReturn(lowConfidence);
        when(platformConfigurationService.getConfidenceThreshold()).thenReturn(BigDecimal.valueOf(50));
        when(buildProvider.getChanges("build-1001")).thenReturn(List.of());
        when(failureRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        FailureAnalysisResult result = service.analyzeAndPersist("build-1001");

        assertEquals(FailureCategory.UNKNOWN_FAILURE, result.failure().getCategory());
    }

    @Test
    void markJobFailuresResolved_marksUnresolvedFailures() {
        JobEntity job = new JobEntity();
        job.setId(10L);
        job.setExternalId("job-alpha");

        FailureEntity failure = new FailureEntity();
        failure.setResolved(false);

        when(jobRepository.findByExternalId("job-alpha")).thenReturn(Optional.of(job));
        when(failureRepository.findByBuild_JobIdAndResolvedFalse(10L)).thenReturn(List.of(failure));

        int count = service.markJobFailuresResolved("job-alpha");

        assertEquals(1, count);
        assertTrue(failure.isResolved());
        assertFalse(failure.getResolvedAt() == null);
    }

    private BuildEntity buildEntity(String externalId, String triggeredBy) {
        BuildEntity build = new BuildEntity();
        build.setId(1L);
        build.setExternalId(externalId);
        build.setTriggeredBy(triggeredBy);
        JobEntity job = new JobEntity();
        job.setId(10L);
        build.setJob(job);
        return build;
    }

    private AIAnalysis sampleAnalysis(String owner) {
        return new AIAnalysis(
                FailureCategory.COMPILATION_ERROR,
                BigDecimal.valueOf(95),
                "Cannot find symbol CustomerDTO",
                "Replace CustomerDTO with CustomerSummaryDTO",
                "com.example.customer",
                owner,
                List.of("CustomerDTO"),
                List.of(),
                "error snippet",
                "High confidence match",
                "Blocks compilation",
                Severity.HIGH
        );
    }
}
