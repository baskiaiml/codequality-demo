package com.cognizant.eop.core.service;

import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JobQueryServiceTest {

    @Mock
    private JobRepository jobRepository;

    @Mock
    private BuildRepository buildRepository;

    @InjectMocks
    private JobQueryService jobQueryService;

    @Test
    void findJobs_returnsPagedSummaries() {
        JobEntity job = new JobEntity();
        job.setId(1L);
        job.setExternalId("job-alpha");
        job.setName("Alpha Build");
        job.setEnabled(true);
        job.setPollingEnabled(true);

        Page<JobEntity> page = new PageImpl<>(List.of(job), PageRequest.of(0, 20), 1);
        when(jobRepository.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(page);
        when(buildRepository.findTopByJobIdOrderByBuildNumberDesc(1L)).thenReturn(java.util.Optional.empty());

        PageResponse<?> response = jobQueryService.findJobs(PageRequest.of(0, 20), null, null, null, null);

        assertEquals(1, response.content().size());
        assertEquals(1, response.page().totalElements());
    }
}
