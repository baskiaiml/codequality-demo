package com.cognizant.eop.core.service;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.dto.page.PageResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class AuditQueryServiceTest {

    @Autowired
    private AuditQueryService auditQueryService;

    @Test
    void recordAndFindEvents_persistsAuditTrail() {
        auditQueryService.record(new AuditEventRequest(
                AuditEventType.CONFIG_UPDATED,
                "configuration",
                "polling.interval.ms",
                "admin",
                AuditDetailsBuilder.create()
                        .put("previousValue", "300000")
                        .put("newValue", "600000")
                        .build()
        ));

        PageResponse<?> page = auditQueryService.findEvents(
                "CONFIG_UPDATED",
                null,
                null,
                PageRequest.of(0, 10)
        );

        assertFalse(page.content().isEmpty());
        assertEquals(1, page.page().totalElements());
    }
}
