package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.service.BuildChangeResult;
import com.cognizant.eop.core.service.BuildChangeType;
import com.cognizant.eop.core.service.BuildPersistenceService;
import com.cognizant.eop.core.service.JobNotFoundException;
import com.cognizant.eop.core.service.JobService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuildMonitoringOrchestratorTest {

    @Mock
    private JobService jobService;

    @Mock
    private BuildPersistenceService buildPersistenceService;

    @Mock
    private BuildChangePostProcessor buildChangePostProcessor;

    @Mock
    private NotificationCycleTracker notificationCycleTracker;

    private BuildMonitoringOrchestrator orchestrator;

    @BeforeEach
    void setUp() {
        orchestrator = new BuildMonitoringOrchestrator(
                jobService, buildPersistenceService, buildChangePostProcessor, notificationCycleTracker);
        when(notificationCycleTracker.getCount()).thenReturn(0);
    }

    @Test
    void executeMonitoringCycle_processesAllJobsAndSummarizesResults() {
        JobEntity failureJob = job("job-failure");
        JobEntity recoveryJob = job("job-recovery");
        JobEntity stableJob = job("job-stable");

        when(jobService.findAllPollingEnabled())
                .thenReturn(List.of(failureJob, recoveryJob, stableJob));

        BuildChangeResult failure = failureChange(1523);
        BuildChangeResult recovery = recoveryChange(200);

        when(buildPersistenceService.processJob("job-failure")).thenReturn(List.of(failure));
        when(buildPersistenceService.processJob("job-recovery")).thenReturn(List.of(recovery));
        when(buildPersistenceService.processJob("job-stable")).thenReturn(List.of());

        MonitoringCycleSummary summary = orchestrator.executeMonitoringCycle();

        assertEquals(3, summary.jobsChecked());
        assertEquals(2, summary.newBuilds());
        assertEquals(1, summary.failures());
        assertEquals(1, summary.recoveries());
        assertEquals(0, summary.errors());
        assertNotNull(summary.startTime());
        assertNotNull(summary.endTime());
        assert summary.durationMs() >= 0;

        verify(buildChangePostProcessor).process(failure, "job-failure");
        verify(buildChangePostProcessor).process(recovery, "job-recovery");
    }

    @Test
    void executeMonitoringCycle_continuesAfterJobError() {
        JobEntity failingJob = job("job-error");
        JobEntity successJob = job("job-ok");

        when(jobService.findAllPollingEnabled()).thenReturn(List.of(failingJob, successJob));
        when(buildPersistenceService.processJob("job-error"))
                .thenThrow(new JobNotFoundException("job-error"));
        when(buildPersistenceService.processJob("job-ok")).thenReturn(List.of());

        MonitoringCycleSummary summary = orchestrator.executeMonitoringCycle();

        assertEquals(2, summary.jobsChecked());
        assertEquals(1, summary.errors());
        verify(buildChangePostProcessor, never()).process(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    void getLastCycleSummary_returnsMostRecentCycle() {
        when(jobService.findAllPollingEnabled()).thenReturn(List.of());
        orchestrator.executeMonitoringCycle();

        assertNotNull(orchestrator.getLastCycleSummary());
    }

    private JobEntity job(String externalId) {
        JobEntity job = new JobEntity();
        job.setExternalId(externalId);
        job.setName(externalId);
        return job;
    }

    private BuildChangeResult failureChange(int buildNumber) {
        Build build = new Build(
                "build-" + buildNumber, "job-failure", buildNumber, BuildStatus.FAILURE,
                "main", Instant.now(), Instant.now(), 1000L, "dev", "http://build"
        );
        return new BuildChangeResult(BuildChangeType.FAILURE, null, build);
    }

    private BuildChangeResult recoveryChange(int buildNumber) {
        Build build = new Build(
                "build-" + buildNumber, "job-recovery", buildNumber, BuildStatus.SUCCESS,
                "main", Instant.now(), Instant.now(), 1000L, "dev", "http://build"
        );
        return new BuildChangeResult(BuildChangeType.RECOVERY, null, build);
    }
}
