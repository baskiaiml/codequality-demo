package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.TrendCalculator;

public record TrendPointResponse(
        String date,
        int successCount,
        int failureCount,
        double successRatePercent
) {
    public static TrendPointResponse from(TrendCalculator.TrendDataPoint point) {
        return new TrendPointResponse(
                point.date().toString(),
                point.successCount(),
                point.failureCount(),
                point.successRatePercent()
        );
    }
}
