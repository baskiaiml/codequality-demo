package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.JobEntity;

public record JobSummaryResponse(
        Long id,
        String externalId,
        String name,
        String branch,
        String buildType,
        boolean enabled,
        boolean pollingEnabled,
        Long teamId,
        String teamName,
        LatestBuildSummary latestBuild
) {
    public static JobSummaryResponse from(JobEntity entity, LatestBuildSummary latestBuild) {
        return new JobSummaryResponse(
                entity.getId(),
                entity.getExternalId(),
                entity.getName(),
                entity.getBranch(),
                entity.getBuildType(),
                entity.isEnabled(),
                entity.isPollingEnabled(),
                entity.getTeam() != null ? entity.getTeam().getId() : null,
                entity.getTeam() != null ? entity.getTeam().getName() : null,
                latestBuild
        );
    }
}
