package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.mapper.BuildMapper;
import com.cognizant.eop.core.mapper.JobMapper;
import com.cognizant.eop.core.repository.BuildCommitRepository;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Persists builds and commits, tracking state changes between polling cycles.
 */
@Service
public class BuildPersistenceService {

    private static final Logger log = LoggerFactory.getLogger(BuildPersistenceService.class);

    private final BuildRepository buildRepository;
    private final BuildCommitRepository buildCommitRepository;
    private final JobRepository jobRepository;
    private final BuildMapper buildMapper;
    private final BuildChangeDetector changeDetector;
    private final BuildProvider buildProvider;

    public BuildPersistenceService(
            BuildRepository buildRepository,
            BuildCommitRepository buildCommitRepository,
            JobRepository jobRepository,
            BuildMapper buildMapper,
            BuildChangeDetector changeDetector,
            BuildProvider buildProvider) {
        this.buildRepository = buildRepository;
        this.buildCommitRepository = buildCommitRepository;
        this.jobRepository = jobRepository;
        this.buildMapper = buildMapper;
        this.changeDetector = changeDetector;
        this.buildProvider = buildProvider;
    }

    /**
     * Evaluates the latest provider build for a job, persists changes, and returns the change result.
     */
    @Transactional
    public Optional<BuildChangeResult> processLatestBuild(String jobExternalId) {
        JobEntity job = jobRepository.findByExternalId(jobExternalId)
                .orElseThrow(() -> new JobNotFoundException(jobExternalId));

        Build currentBuild = buildProvider.getLatestBuild(jobExternalId);
        if (currentBuild == null) {
            return Optional.empty();
        }

        Build lastKnown = buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId())
                .map(buildMapper::toDomain)
                .orElse(null);

        BuildChangeResult changeResult = changeDetector.detect(lastKnown, currentBuild);

        if (!changeResult.hasChanged()) {
            return Optional.of(changeResult);
        }

        BuildEntity savedBuild = upsertBuild(job, currentBuild);
        persistCommits(savedBuild, currentBuild.id());

        log.info("Build change detected: jobExternalId={}, changeType={}, buildNumber={}, status={}",
                jobExternalId, changeResult.changeType(), currentBuild.buildNumber(), currentBuild.status());

        return Optional.of(changeResult);
    }

    /**
     * Processes all builds that appeared since the last known build (handles multiple builds between polls).
     */
    @Transactional
    public List<BuildChangeResult> processNewBuildsSinceLastKnown(String jobExternalId) {
        JobEntity job = jobRepository.findByExternalId(jobExternalId)
                .orElseThrow(() -> new JobNotFoundException(jobExternalId));

        Build previous = buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId())
                .map(buildMapper::toDomain)
                .orElse(null);

        int lastKnownNumber = previous != null ? previous.buildNumber() : 0;

        List<Build> newBuilds = buildProvider.getBuildHistory(jobExternalId).stream()
                .filter(build -> build.buildNumber() > lastKnownNumber)
                .sorted(Comparator.comparingInt(Build::buildNumber))
                .toList();

        List<BuildChangeResult> results = new ArrayList<>();
        for (Build build : newBuilds) {
            BuildChangeResult result = changeDetector.detect(previous, build);
            BuildEntity saved = upsertBuild(job, build);
            persistCommits(saved, build.id());
            results.add(result);
            previous = build;
        }

        return results;
    }

    /**
     * Processes all new builds and any status updates on the current latest build.
     * Used by the scheduler and manual trigger endpoints.
     */
    @Transactional
    public List<BuildChangeResult> processJob(String jobExternalId) {
        List<BuildChangeResult> results = new ArrayList<>(processNewBuildsSinceLastKnown(jobExternalId));

        processLatestBuild(jobExternalId).ifPresent(latest -> {
            if (!latest.hasChanged() || latest.currentBuild() == null) {
                return;
            }
            boolean alreadyHandled = results.stream()
                    .anyMatch(result -> result.currentBuild() != null
                            && result.currentBuild().id().equals(latest.currentBuild().id()));
            if (!alreadyHandled) {
                results.add(latest);
            }
        });

        return results.stream()
                .filter(BuildChangeResult::hasChanged)
                .toList();
    }

    /**
     * Returns the last known build for a job from the database.
     */
    @Transactional(readOnly = true)
    public Optional<Build> findLastKnownBuild(String jobExternalId) {
        return jobRepository.findByExternalId(jobExternalId)
                .flatMap(job -> buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId()))
                .map(buildMapper::toDomain);
    }

    private BuildEntity upsertBuild(JobEntity job, Build build) {
        BuildEntity entity = buildRepository.findByExternalId(build.id())
                .orElseGet(() -> buildMapper.toEntity(build, job));

        if (entity.getId() != null) {
            buildMapper.updateEntity(build, entity);
        }

        return buildRepository.save(entity);
    }

    private void persistCommits(BuildEntity buildEntity, String buildExternalId) {
        List<Commit> commits = buildProvider.getChanges(buildExternalId);
        if (commits.isEmpty()) {
            return;
        }

        buildCommitRepository.deleteByBuildId(buildEntity.getId());

        commits.stream()
                .map(commit -> buildMapper.toCommitEntity(commit, buildEntity))
                .forEach(buildCommitRepository::save);
    }
}
