package com.cognizant.eop.core.service;

public class ProviderJobNotFoundException extends RuntimeException {

    public ProviderJobNotFoundException(String externalId) {
        super("Build job not found in provider: " + externalId);
    }
}
