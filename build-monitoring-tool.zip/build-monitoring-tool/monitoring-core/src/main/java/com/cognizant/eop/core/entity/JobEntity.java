package com.cognizant.eop.core.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "job")
@Getter
@Setter
@NoArgsConstructor
public class JobEntity extends BaseEntity {

    @Column(name = "external_id", nullable = false, unique = true, length = 255)
    private String externalId;

    @Column(nullable = false, length = 500)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private TeamEntity team;

    @Column(length = 255)
    private String branch;

    @Column(name = "build_type", length = 100)
    private String buildType;

    @Column(nullable = false)
    private boolean enabled = true;

    @Column(name = "polling_enabled", nullable = false)
    private boolean pollingEnabled = true;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();

    @OneToMany(mappedBy = "job")
    private List<BuildEntity> builds = new ArrayList<>();
}
