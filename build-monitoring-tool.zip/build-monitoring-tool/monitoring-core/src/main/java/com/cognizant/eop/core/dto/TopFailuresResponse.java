package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.TopFailuresAggregator;

import java.util.List;

public record TopFailuresResponse(
        List<RankingEntryResponse> topFailingJobs,
        List<RankingEntryResponse> topFailingTeams,
        List<RankingEntryResponse> topFailureCategories
) {
    public static TopFailuresResponse from(TopFailuresAggregator.TopFailuresResult result) {
        return new TopFailuresResponse(
                result.topFailingJobs().stream().map(RankingEntryResponse::from).toList(),
                result.topFailingTeams().stream().map(RankingEntryResponse::from).toList(),
                result.topFailureCategories().stream().map(RankingEntryResponse::from).toList()
        );
    }
}
