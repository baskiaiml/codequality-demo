package com.cognizant.eop.core.config;

import com.cognizant.eop.api.notification.NotificationSender;
import com.cognizant.eop.api.notification.NotificationTemplateRenderer;
import com.cognizant.eop.notification.sender.LoggingNotificationSender;
import com.cognizant.eop.notification.template.ClasspathNotificationTemplateRenderer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;

@Configuration
public class NotificationConfig {

    @Bean
    NotificationTemplateRenderer notificationTemplateRenderer() {
        return new ClasspathNotificationTemplateRenderer();
    }

    @Bean
    @ConditionalOnProperty(name = "eop.notification.sender", havingValue = "logging", matchIfMissing = true)
    NotificationSender loggingNotificationSender() {
        return new LoggingNotificationSender();
    }

    @Bean
    @ConditionalOnProperty(name = "eop.notification.sender", havingValue = "smtp")
    NotificationSender smtpNotificationSender(JavaMailSender mailSender) {
        return new SmtpNotificationSender(mailSender);
    }
}
