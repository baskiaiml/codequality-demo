package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.NotificationRuleResponse;
import com.cognizant.eop.core.repository.NotificationRuleRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/notification-rules")
public class NotificationRuleController {

    private final NotificationRuleRepository notificationRuleRepository;

    public NotificationRuleController(NotificationRuleRepository notificationRuleRepository) {
        this.notificationRuleRepository = notificationRuleRepository;
    }

    @GetMapping
    public ResponseEntity<List<NotificationRuleResponse>> listNotificationRules() {
        List<NotificationRuleResponse> rules = notificationRuleRepository.findAll()
                .stream()
                .map(NotificationRuleResponse::from)
                .toList();
        return ResponseEntity.ok(rules);
    }
}
