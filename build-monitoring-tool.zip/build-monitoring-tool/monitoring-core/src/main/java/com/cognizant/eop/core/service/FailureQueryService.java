package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.core.dto.FailureDetailResponse;
import com.cognizant.eop.core.dto.FailureSummaryResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.spec.EntitySpecs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class FailureQueryService {

    private final FailureRepository failureRepository;

    public FailureQueryService(FailureRepository failureRepository) {
        this.failureRepository = failureRepository;
    }

    @Transactional(readOnly = true)
    public PageResponse<FailureSummaryResponse> findFailures(
            Pageable pageable,
            FailureCategory category,
            Boolean resolved,
            Long teamId,
            Instant from,
            Instant to) {
        Specification<FailureEntity> spec = Specification.allOf(
                EntitySpecs.failureForMonitoredJobs(),
                EntitySpecs.failureHasCategory(category),
                EntitySpecs.failureIsResolved(resolved),
                EntitySpecs.failureHasTeamId(teamId),
                EntitySpecs.failureCreatedAfter(from),
                EntitySpecs.failureCreatedBefore(to)
        );

        Page<FailureSummaryResponse> page = failureRepository.findAll(spec, pageable)
                .map(FailureSummaryResponse::from);
        return PageResponse.from(page);
    }

    @Transactional(readOnly = true)
    public FailureDetailResponse findById(Long failureId) {
        FailureEntity failure = failureRepository.findById(failureId)
                .orElseThrow(() -> new FailureNotFoundException(failureId));
        return FailureDetailResponse.from(failure);
    }
}
