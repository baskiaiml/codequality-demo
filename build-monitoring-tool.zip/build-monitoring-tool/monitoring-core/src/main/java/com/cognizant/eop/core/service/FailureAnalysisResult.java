package com.cognizant.eop.core.service;

import com.cognizant.eop.core.entity.FailureEntity;

/**
 * Result of failure analysis including whether the persisted record changed.
 */
public record FailureAnalysisResult(
        FailureEntity failure,
        FailureAnalysisOutcome outcome
) {}
