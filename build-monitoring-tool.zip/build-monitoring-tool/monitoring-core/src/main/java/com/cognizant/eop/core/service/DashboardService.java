package com.cognizant.eop.core.service;



import com.cognizant.eop.api.model.BuildStatus;

import com.cognizant.eop.api.provider.BuildProvider;

import com.cognizant.eop.core.dto.FailureSummaryResponse;

import com.cognizant.eop.core.dto.GlobalDashboardResponse;

import com.cognizant.eop.core.dto.GroupDashboardResponse;

import com.cognizant.eop.core.dto.GroupStatusSummary;

import com.cognizant.eop.core.dto.JobSummaryResponse;

import com.cognizant.eop.core.dto.TeamDashboardResponse;

import com.cognizant.eop.core.dto.TeamStatusSummary;

import com.cognizant.eop.core.entity.BuildEntity;

import com.cognizant.eop.core.entity.FailureEntity;

import com.cognizant.eop.core.entity.GroupEntity;

import com.cognizant.eop.core.entity.JobEntity;

import com.cognizant.eop.core.entity.TeamEntity;

import com.cognizant.eop.core.repository.BuildRepository;

import com.cognizant.eop.core.repository.FailureRepository;

import com.cognizant.eop.core.repository.GroupRepository;

import com.cognizant.eop.core.repository.JobRepository;

import com.cognizant.eop.core.repository.TeamRepository;

import org.springframework.data.domain.PageRequest;

import org.springframework.data.domain.Sort;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;



import java.util.List;

import java.util.Map;

import java.util.Set;

import java.util.stream.Collectors;



@Service

public class DashboardService {



    private final JobRepository jobRepository;

    private final BuildRepository buildRepository;

    private final FailureRepository failureRepository;

    private final TeamRepository teamRepository;

    private final GroupRepository groupRepository;

    private final BuildProvider buildProvider;

    private final BuildQueryService buildQueryService;

    private final JobQueryService jobQueryService;

    private final OrganizationQueryService organizationQueryService;



    public DashboardService(

            JobRepository jobRepository,

            BuildRepository buildRepository,

            FailureRepository failureRepository,

            TeamRepository teamRepository,

            GroupRepository groupRepository,

            BuildProvider buildProvider,

            BuildQueryService buildQueryService,

            JobQueryService jobQueryService,

            OrganizationQueryService organizationQueryService) {

        this.jobRepository = jobRepository;

        this.buildRepository = buildRepository;

        this.failureRepository = failureRepository;

        this.teamRepository = teamRepository;

        this.groupRepository = groupRepository;

        this.buildProvider = buildProvider;

        this.buildQueryService = buildQueryService;

        this.jobQueryService = jobQueryService;

        this.organizationQueryService = organizationQueryService;

    }



    @Transactional(readOnly = true)

    public GlobalDashboardResponse getGlobalDashboard() {

        long totalJobs = jobRepository.countByEnabledTrueAndPollingEnabledTrue();

        long runningBuilds = buildQueryService.findRunningBuilds().size();

        List<FailureEntity> activeFailures = findActiveFailuresForMonitoredJobs();



        List<FailureSummaryResponse> recentFailures = failureRepository

                .findAll(PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "createdAt")))

                .stream()

                .filter(this::isMonitoredFailure)

                .map(FailureSummaryResponse::from)

                .toList();



        Map<String, Long> failuresByCategory = activeFailures.stream()

                .collect(Collectors.groupingBy(f -> f.getCategory().name(), Collectors.counting()));



        List<GroupStatusSummary> groupSummaries = groupRepository.findWithMonitoredJobs().stream()

                .map(group -> summarizeGroup(group.getId()))

                .toList();



        return new GlobalDashboardResponse(

                totalJobs,

                runningBuilds,

                activeFailures.size(),

                calculateGlobalSuccessRate(),

                recentFailures,

                buildQueryService.findRunningBuilds(),

                failuresByCategory,

                groupSummaries

        );

    }



    @Transactional(readOnly = true)

    public GroupDashboardResponse getGroupDashboard(Long groupId) {

        GroupEntity group = organizationQueryService.requireGroup(groupId);

        List<TeamEntity> teams = teamRepository.findWithMonitoredJobs().stream()

                .filter(team -> groupId.equals(team.getGroup().getId()))

                .toList();



        List<TeamStatusSummary> teamSummaries = teams.stream()

                .map(team -> summarizeTeam(team.getId()))

                .toList();



        long jobCount = teams.stream()

                .mapToLong(team -> countMonitoredJobsForTeam(team.getId()))

                .sum();

        long activeFailures = teams.stream()

                .mapToLong(team -> countActiveFailuresForTeam(team.getId()))

                .sum();



        return new GroupDashboardResponse(

                group.getId(),

                group.getName(),

                teams.size(),

                jobCount,

                activeFailures,

                calculateSuccessRateForTeams(teams),

                teamSummaries

        );

    }



    @Transactional(readOnly = true)

    public TeamDashboardResponse getTeamDashboard(Long teamId) {

        TeamEntity team = organizationQueryService.requireTeam(teamId);

        List<JobEntity> jobs = jobRepository.findByTeamId(teamId).stream()

                .filter(MonitoredJobRules::isMonitored)

                .toList();



        List<JobSummaryResponse> jobSummaries = jobs.stream()

                .map(job -> jobQueryService.findByExternalId(job.getExternalId()))

                .toList();



        List<FailureSummaryResponse> recentFailures = failureRepository.findAll(

                        (root, query, cb) -> cb.equal(root.get("build").get("job").get("team").get("id"), teamId),

                        PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "createdAt")))

                .stream()

                .filter(this::isMonitoredFailure)

                .map(FailureSummaryResponse::from)

                .toList();



        return new TeamDashboardResponse(

                team.getId(),

                team.getName(),

                team.getGroup().getName(),

                team.getEmail(),

                jobs.size(),

                countActiveFailuresForTeam(teamId),

                calculateSuccessRateForTeam(teamId),

                jobSummaries,

                recentFailures

        );

    }



    private GroupStatusSummary summarizeGroup(Long groupId) {

        GroupEntity group = organizationQueryService.requireGroup(groupId);

        List<TeamEntity> teams = teamRepository.findWithMonitoredJobs().stream()

                .filter(team -> groupId.equals(team.getGroup().getId()))

                .toList();

        long jobCount = teams.stream()

                .mapToLong(team -> countMonitoredJobsForTeam(team.getId()))

                .sum();

        long activeFailures = teams.stream()

                .mapToLong(team -> countActiveFailuresForTeam(team.getId()))

                .sum();



        return new GroupStatusSummary(

                group.getId(),

                group.getName(),

                jobCount,

                activeFailures,

                calculateSuccessRateForTeams(teams)

        );

    }



    private TeamStatusSummary summarizeTeam(Long teamId) {

        TeamEntity team = organizationQueryService.requireTeam(teamId);

        return new TeamStatusSummary(

                team.getId(),

                team.getName(),

                countMonitoredJobsForTeam(teamId),

                countActiveFailuresForTeam(teamId),

                calculateSuccessRateForTeam(teamId)

        );

    }



    private long countMonitoredJobsForTeam(Long teamId) {

        return jobRepository.findByTeamId(teamId).stream()

                .filter(MonitoredJobRules::isMonitored)

                .count();

    }



    private List<FailureEntity> findActiveFailuresForMonitoredJobs() {

        return failureRepository.findByResolvedFalse().stream()

                .filter(this::isMonitoredFailure)

                .toList();

    }



    private boolean isMonitoredFailure(FailureEntity failure) {

        return failure.getBuild() != null

                && MonitoredJobRules.isMonitored(failure.getBuild().getJob());

    }



    private long countActiveFailuresForTeam(Long teamId) {

        return findActiveFailuresForMonitoredJobs().stream()

                .filter(failure -> failure.getBuild().getJob().getTeam() != null

                        && teamId.equals(failure.getBuild().getJob().getTeam().getId()))

                .count();

    }



    private double calculateGlobalSuccessRate() {

        List<BuildEntity> completed = monitoredBuilds().stream()

                .filter(build -> build.getStatus() == BuildStatus.SUCCESS || build.getStatus() == BuildStatus.FAILURE)

                .toList();

        if (completed.isEmpty()) {

            return 0.0;

        }

        long successes = completed.stream().filter(build -> build.getStatus() == BuildStatus.SUCCESS).count();

        return roundPercent(successes * 100.0 / completed.size());

    }



    private double calculateSuccessRateForTeam(Long teamId) {

        List<BuildEntity> builds = monitoredBuilds().stream()

                .filter(build -> build.getJob().getTeam() != null

                        && teamId.equals(build.getJob().getTeam().getId()))

                .filter(build -> build.getStatus() == BuildStatus.SUCCESS || build.getStatus() == BuildStatus.FAILURE)

                .toList();

        return calculateSuccessRate(builds);

    }



    private double calculateSuccessRateForTeams(List<TeamEntity> teams) {

        Set<Long> teamIds = teams.stream().map(TeamEntity::getId).collect(Collectors.toSet());

        List<BuildEntity> builds = monitoredBuilds().stream()

                .filter(build -> build.getJob().getTeam() != null

                        && teamIds.contains(build.getJob().getTeam().getId()))

                .filter(build -> build.getStatus() == BuildStatus.SUCCESS || build.getStatus() == BuildStatus.FAILURE)

                .toList();

        return calculateSuccessRate(builds);

    }



    private List<BuildEntity> monitoredBuilds() {

        return buildRepository.findAll().stream()

                .filter(build -> MonitoredJobRules.isMonitored(build.getJob()))

                .toList();

    }



    private double calculateSuccessRate(List<BuildEntity> builds) {

        if (builds.isEmpty()) {

            return 0.0;

        }

        long successes = builds.stream().filter(build -> build.getStatus() == BuildStatus.SUCCESS).count();

        return roundPercent(successes * 100.0 / builds.size());

    }



    private double roundPercent(double value) {

        return Math.round(value * 10.0) / 10.0;

    }

}


