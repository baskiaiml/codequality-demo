package com.cognizant.eop.core.config;

import com.cognizant.eop.api.notification.NotificationChannel;
import com.cognizant.eop.api.notification.NotificationMessage;
import com.cognizant.eop.api.notification.NotificationSender;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * Sends notifications via SMTP using Spring Mail.
 */
public class SmtpNotificationSender implements NotificationSender {

    private static final Logger log = LoggerFactory.getLogger(SmtpNotificationSender.class);

    private final JavaMailSender mailSender;

    public SmtpNotificationSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Override
    public NotificationChannel channel() {
        return NotificationChannel.EMAIL;
    }

    @Override
    public void send(NotificationMessage message) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
            helper.setTo(message.recipient());
            helper.setSubject(message.subject());
            helper.setText(message.body(), false);
            mailSender.send(mimeMessage);
            log.info("SMTP notification sent: event={} to={}", message.eventType(), message.recipient());
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to send SMTP notification to " + message.recipient(), ex);
        }
    }
}
