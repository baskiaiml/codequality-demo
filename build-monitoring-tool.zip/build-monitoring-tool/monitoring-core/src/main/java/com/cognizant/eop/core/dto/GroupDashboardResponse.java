package com.cognizant.eop.core.dto;

import java.util.List;

public record GroupDashboardResponse(
        Long groupId,
        String groupName,
        long teamCount,
        long jobCount,
        long activeFailures,
        double successRatePercent,
        List<TeamStatusSummary> teams
) {}
