package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.FailureAnalysisResponse;
import com.cognizant.eop.core.dto.FailureProcessingResponse;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.service.BuildFailureProcessingService;
import com.cognizant.eop.core.service.FailureAnalysisService;
import com.cognizant.eop.core.service.FailureProcessingResult;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST API for build failure AI analysis.
 */
@RestController
@RequestMapping("/api/v1/builds")
public class AnalysisController {

    private final FailureAnalysisService failureAnalysisService;
    private final BuildFailureProcessingService buildFailureProcessingService;

    public AnalysisController(
            FailureAnalysisService failureAnalysisService,
            BuildFailureProcessingService buildFailureProcessingService) {
        this.failureAnalysisService = failureAnalysisService;
        this.buildFailureProcessingService = buildFailureProcessingService;
    }

    @GetMapping("/{buildId}/analysis")
    public ResponseEntity<FailureAnalysisResponse> getBuildAnalysis(@PathVariable String buildId) {
        FailureEntity failure = failureAnalysisService.getOrCreateAnalysis(buildId);
        return ResponseEntity.ok(FailureAnalysisResponse.from(failure));
    }

    /**
     * Runs AI analysis and sends failure notifications. Use to backfill builds already in the database.
     */
    @PreAuthorize("hasAnyRole('ADMINISTRATOR', 'MANAGER', 'DEVELOPER')")
    @PostMapping("/{buildId}/process-failure")
    public ResponseEntity<FailureProcessingResponse> processFailure(@PathVariable String buildId) {
        FailureProcessingResult result = buildFailureProcessingService.analyzeAndNotify(buildId);
        return ResponseEntity.ok(FailureProcessingResponse.from(buildId, result));
    }
}
