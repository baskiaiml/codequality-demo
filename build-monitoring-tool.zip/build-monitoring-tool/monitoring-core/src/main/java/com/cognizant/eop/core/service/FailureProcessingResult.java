package com.cognizant.eop.core.service;

/**
 * Result of running failure analysis and notification dispatch for a build.
 */
public record FailureProcessingResult(
        FailureAnalysisResult analysisResult,
        int notificationsSent
) {}
