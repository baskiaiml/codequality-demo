package com.cognizant.eop.core.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for the build monitoring scheduler.
 *
 * @param enabled           whether the scheduler is active
 * @param pollingIntervalMs delay between monitoring cycles in milliseconds
 */
@ConfigurationProperties(prefix = "eop.scheduler")
public record SchedulerProperties(
        boolean enabled,
        long pollingIntervalMs
) {
    public SchedulerProperties {
        if (pollingIntervalMs <= 0) {
            pollingIntervalMs = 300_000L;
        }
    }
}
