package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.service.BuildChangeResult;
import com.cognizant.eop.core.service.FailureAnalysisOutcome;
import com.cognizant.eop.core.service.FailureAnalysisResult;
import com.cognizant.eop.core.service.FailureAnalysisService;
import com.cognizant.eop.core.service.NotificationDispatchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Runs AI analysis on detected build failures and dispatches notifications.
 */
@Component
public class BuildFailureAnalysisProcessor implements BuildFailureProcessor {

    private static final Logger log = LoggerFactory.getLogger(BuildFailureAnalysisProcessor.class);

    private final FailureAnalysisService failureAnalysisService;
    private final NotificationDispatchService notificationDispatchService;

    public BuildFailureAnalysisProcessor(
            FailureAnalysisService failureAnalysisService,
            NotificationDispatchService notificationDispatchService) {
        this.failureAnalysisService = failureAnalysisService;
        this.notificationDispatchService = notificationDispatchService;
    }

    @Override
    public void processFailure(BuildChangeResult change, String jobExternalId) {
        if (change.currentBuild() == null) {
            return;
        }

        String buildExternalId = change.currentBuild().id();
        try {
            FailureAnalysisResult result = failureAnalysisService.analyzeAndPersist(buildExternalId);
            dispatchNotifications(buildExternalId, jobExternalId, result.outcome());
        } catch (Exception ex) {
            log.error("Failed to analyze build failure: jobExternalId={}, buildExternalId={}",
                    jobExternalId, buildExternalId, ex);
        }
    }

    private void dispatchNotifications(
            String buildExternalId,
            String jobExternalId,
            FailureAnalysisOutcome outcome) {
        switch (outcome) {
            case CREATED -> notificationDispatchService.dispatchBuildFailure(buildExternalId, jobExternalId);
            case UPDATED -> notificationDispatchService.dispatchRootCauseChanged(buildExternalId, jobExternalId);
            case UNCHANGED -> { /* no notification */ }
        }
    }
}
