package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.service.BuildChangeResult;
import org.springframework.stereotype.Component;

/**
 * Runs failure analysis and recovery handling after build changes are detected.
 */
@Component
public class BuildChangePostProcessor {

    private final BuildFailureProcessor failureProcessor;
    private final BuildRecoveryProcessor recoveryProcessor;

    public BuildChangePostProcessor(
            BuildFailureProcessor failureProcessor,
            BuildRecoveryProcessor recoveryProcessor) {
        this.failureProcessor = failureProcessor;
        this.recoveryProcessor = recoveryProcessor;
    }

    public void process(BuildChangeResult change, String jobExternalId) {
        if (!change.hasChanged()) {
            return;
        }
        if (change.requiresFailureProcessing()) {
            failureProcessor.processFailure(change, jobExternalId);
        }
        if (change.requiresRecoveryNotification()) {
            recoveryProcessor.processRecovery(change, jobExternalId);
        }
    }
}
