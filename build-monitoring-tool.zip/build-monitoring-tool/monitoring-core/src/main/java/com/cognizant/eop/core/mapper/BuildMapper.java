package com.cognizant.eop.core.mapper;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.core.entity.BuildCommitEntity;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

/**
 * MapStruct mapper between provider domain records and JPA entities.
 */
@Mapper(componentModel = "spring")
public interface BuildMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "job", source = "job")
    @Mapping(target = "externalId", source = "build.id")
    @Mapping(target = "buildNumber", source = "build.buildNumber")
    @Mapping(target = "status", source = "build.status")
    @Mapping(target = "branch", source = "build.branch")
    @Mapping(target = "startedAt", source = "build.startedAt")
    @Mapping(target = "finishedAt", source = "build.finishedAt")
    @Mapping(target = "durationMs", source = "build.durationMs")
    @Mapping(target = "triggeredBy", source = "build.triggeredBy")
    @Mapping(target = "buildUrl", source = "build.buildUrl")
    @Mapping(target = "commits", ignore = true)
    @Mapping(target = "failure", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    BuildEntity toEntity(Build build, JobEntity job);

    @Mapping(target = "jobId", source = "job.externalId")
    Build toDomain(BuildEntity entity);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "job", ignore = true)
    @Mapping(target = "externalId", source = "id")
    @Mapping(target = "commits", ignore = true)
    @Mapping(target = "failure", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    void updateEntity(Build build, @MappingTarget BuildEntity entity);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "build", source = "build")
    @Mapping(target = "commitHash", source = "commit.hash")
    BuildCommitEntity toCommitEntity(Commit commit, BuildEntity build);

    @Mapping(target = "hash", source = "commitHash")
    Commit toCommitDomain(BuildCommitEntity entity);
}
