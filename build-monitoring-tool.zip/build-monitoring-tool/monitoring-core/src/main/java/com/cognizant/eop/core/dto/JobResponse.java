package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.JobEntity;

/**
 * REST response DTO for a monitored CI/CD job.
 */
public record JobResponse(
        String externalId,
        String name,
        String branch,
        String buildType,
        boolean enabled,
        boolean pollingEnabled
) {
    public static JobResponse from(JobEntity entity) {
        return new JobResponse(
                entity.getExternalId(),
                entity.getName(),
                entity.getBranch(),
                entity.getBuildType(),
                entity.isEnabled(),
                entity.isPollingEnabled()
        );
    }
}
