package com.cognizant.eop.core.service;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.core.dto.AuditEventResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.entity.AuditEventEntity;
import com.cognizant.eop.core.repository.AuditEventRepository;
import com.cognizant.eop.core.repository.spec.EntitySpecs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class AuditQueryService implements AuditRecorder {

    private final AuditEventRepository auditEventRepository;

    public AuditQueryService(AuditEventRepository auditEventRepository) {
        this.auditEventRepository = auditEventRepository;
    }

    @Override
    @Transactional
    public void record(AuditEventRequest event) {
        AuditEventEntity entity = new AuditEventEntity();
        entity.setEventType(event.eventType());
        entity.setEntityType(event.entityType());
        entity.setEntityId(event.entityId());
        entity.setActor(event.actor());
        entity.setDetails(event.details());
        auditEventRepository.save(entity);
    }

    @Transactional(readOnly = true)
    public PageResponse<AuditEventResponse> findEvents(
            String eventType,
            Instant from,
            Instant to,
            Pageable pageable) {
        Specification<AuditEventEntity> spec = EntitySpecs.auditEvents(eventType, from, to);
        Page<AuditEventResponse> page = auditEventRepository.findAll(spec, pageable)
                .map(AuditEventResponse::from);
        return PageResponse.from(page);
    }
}
