package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.dto.JobSummaryResponse;
import com.cognizant.eop.core.dto.LatestBuildSummary;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.entity.TeamEntity;
import com.cognizant.eop.core.mapper.JobMapper;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * Manages job registration and synchronization with the build provider.
 */
@Service
public class JobService {

    private static final Logger log = LoggerFactory.getLogger(JobService.class);

    private final JobRepository jobRepository;
    private final BuildRepository buildRepository;
    private final JobMapper jobMapper;
    private final BuildProvider buildProvider;
    private final OrganizationQueryService organizationQueryService;

    public JobService(
            JobRepository jobRepository,
            BuildRepository buildRepository,
            JobMapper jobMapper,
            BuildProvider buildProvider,
            OrganizationQueryService organizationQueryService) {
        this.jobRepository = jobRepository;
        this.buildRepository = buildRepository;
        this.jobMapper = jobMapper;
        this.buildProvider = buildProvider;
        this.organizationQueryService = organizationQueryService;
    }

    @Transactional(readOnly = true)
    public List<JobEntity> findAllPollingEnabled() {
        return jobRepository.findByEnabledTrueAndPollingEnabledTrue();
    }

    @Transactional(readOnly = true)
    public List<Job> findAllPollingEnabledAsDomain() {
        return findAllPollingEnabled().stream()
                .map(jobMapper::toDomain)
                .toList();
    }

    /**
     * Enables monitoring for a build job under an existing team.
     * The job must exist in the database or in the build provider catalog.
     */
    @Transactional
    public JobSummaryResponse registerForMonitoring(Long teamId, String externalId) {
        TeamEntity team = organizationQueryService.requireTeam(teamId);
        if (!team.isEnabled()) {
            throw new TeamDisabledException(teamId);
        }

        JobEntity job = jobRepository.findByExternalId(externalId)
                .orElseGet(() -> createUnmonitoredJobFromProvider(externalId));

        job.setTeam(team);
        job.setEnabled(true);
        job.setPollingEnabled(true);
        job.setUpdatedAt(Instant.now());
        JobEntity saved = jobRepository.save(job);

        log.info("Registered job {} for monitoring under team {}", externalId, team.getName());
        return JobSummaryResponse.from(saved, resolveLatestBuild(saved));
    }

    /**
     * Stops monitoring a build job while preserving historical data and team assignment.
     */
    @Transactional
    public JobSummaryResponse removeFromMonitoring(String externalId) {
        JobEntity job = jobRepository.findByExternalId(externalId)
                .orElseThrow(() -> new JobNotFoundException(externalId));

        job.setEnabled(false);
        job.setPollingEnabled(false);
        job.setUpdatedAt(Instant.now());
        JobEntity saved = jobRepository.save(job);

        log.info("Removed job {} from monitoring", externalId);
        return JobSummaryResponse.from(saved, resolveLatestBuild(saved));
    }

    /**
     * Synchronizes jobs from the provider into the database.
     * Existing jobs have metadata updated; new jobs are registered as unmonitored until an admin assigns a team.
     */
    @Transactional
    public int syncJobsFromProvider() {
        List<Job> providerJobs = buildProvider.getConfiguredJobs();
        int synced = 0;

        for (Job providerJob : providerJobs) {
            jobRepository.findByExternalId(providerJob.id())
                    .ifPresentOrElse(
                            existing -> updateExistingJob(existing, providerJob),
                            () -> registerNewJob(providerJob)
                    );
            synced++;
        }

        log.info("Synchronized {} jobs from provider", synced);
        return synced;
    }

    private void updateExistingJob(JobEntity existing, Job providerJob) {
        existing.setName(providerJob.name());
        existing.setBranch(providerJob.branch());
        existing.setBuildType(providerJob.buildTypeId());
        existing.setUpdatedAt(Instant.now());
        jobRepository.save(existing);
    }

    private void registerNewJob(Job providerJob) {
        JobEntity entity = jobMapper.toEntity(providerJob);
        entity.setEnabled(false);
        entity.setPollingEnabled(false);
        entity.setUpdatedAt(Instant.now());
        jobRepository.save(entity);
        log.info("Registered unmonitored job from provider: {}", providerJob.id());
    }

    private JobEntity createUnmonitoredJobFromProvider(String externalId) {
        Job providerJob = buildProvider.getConfiguredJobs().stream()
                .filter(job -> job.id().equals(externalId))
                .findFirst()
                .orElseThrow(() -> new ProviderJobNotFoundException(externalId));

        JobEntity entity = jobMapper.toEntity(providerJob);
        entity.setEnabled(false);
        entity.setPollingEnabled(false);
        entity.setUpdatedAt(Instant.now());
        return jobRepository.save(entity);
    }

    private LatestBuildSummary resolveLatestBuild(JobEntity job) {
        return buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId())
                .map(this::toLatestBuildSummary)
                .orElse(null);
    }

    private LatestBuildSummary toLatestBuildSummary(BuildEntity build) {
        return new LatestBuildSummary(
                build.getExternalId(),
                build.getBuildNumber(),
                build.getStatus().name(),
                build.getStartedAt(),
                build.getDurationMs()
        );
    }
}
