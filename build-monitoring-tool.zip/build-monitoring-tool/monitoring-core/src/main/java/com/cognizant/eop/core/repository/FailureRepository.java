package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.FailureEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface FailureRepository extends JpaRepository<FailureEntity, Long>, JpaSpecificationExecutor<FailureEntity> {

    Optional<FailureEntity> findByBuildId(Long buildId);

    List<FailureEntity> findByResolvedFalse();

    List<FailureEntity> findByBuild_JobIdAndResolvedFalse(Long jobId);
}
