package com.cognizant.eop.core.mapper;

import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.core.entity.FailureEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Mapper(componentModel = "spring")
public interface FailureAnalysisMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "build", source = "build")
    @Mapping(target = "category", source = "analysis.failureType")
    @Mapping(target = "confidenceScore", source = "analysis.confidenceScore")
    @Mapping(target = "rootCause", source = "analysis.rootCause")
    @Mapping(target = "suggestedFix", source = "analysis.suggestedFix")
    @Mapping(target = "affectedModule", source = "analysis.affectedModule")
    @Mapping(target = "possibleOwner", source = "analysis.possibleOwner")
    @Mapping(target = "relevantClasses", expression = "java(joinList(analysis.relevantClasses()))")
    @Mapping(target = "sqlObjects", expression = "java(joinList(analysis.sqlObjects()))")
    @Mapping(target = "logSnippet", source = "analysis.logSnippet")
    @Mapping(target = "recommendation", source = "analysis.recommendation")
    @Mapping(target = "developerImpact", source = "analysis.developerImpact")
    @Mapping(target = "severity", source = "analysis.severity")
    @Mapping(target = "resolved", constant = "false")
    @Mapping(target = "resolvedAt", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    FailureEntity toEntity(AIAnalysis analysis, com.cognizant.eop.core.entity.BuildEntity build);

    @Mapping(target = "failureType", source = "category")
    @Mapping(target = "relevantClasses", expression = "java(splitList(entity.getRelevantClasses()))")
    @Mapping(target = "sqlObjects", expression = "java(splitList(entity.getSqlObjects()))")
    AIAnalysis toAnalysis(FailureEntity entity);

    default String joinList(List<String> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        return String.join(", ", values);
    }

    default List<String> splitList(String value) {
        if (value == null || value.isBlank()) {
            return Collections.emptyList();
        }
        return Arrays.stream(value.split(",\\s*")).toList();
    }
}
