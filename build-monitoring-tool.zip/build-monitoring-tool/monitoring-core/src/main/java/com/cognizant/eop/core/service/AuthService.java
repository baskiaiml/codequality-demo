package com.cognizant.eop.core.service;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.dto.LoginRequest;
import com.cognizant.eop.core.dto.LoginResponse;
import com.cognizant.eop.core.dto.UserProfileResponse;
import com.cognizant.eop.core.entity.AppUserEntity;
import com.cognizant.eop.core.repository.AppUserRepository;
import com.cognizant.eop.security.auth.EopAuthenticationToken;
import com.cognizant.eop.security.auth.SecurityContextAccessor;
import com.cognizant.eop.security.jwt.JwtTokenService;
import com.cognizant.eop.security.model.AuthenticatedUser;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class AuthService {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenService jwtTokenService;
    private final AuditRecorder auditRecorder;

    public AuthService(
            AppUserRepository appUserRepository,
            PasswordEncoder passwordEncoder,
            JwtTokenService jwtTokenService,
            AuditRecorder auditRecorder) {
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenService = jwtTokenService;
        this.auditRecorder = auditRecorder;
    }

    @Transactional
    public LoginResponse login(LoginRequest request) {
        AppUserEntity user = appUserRepository.findByUsernameAndEnabledTrue(request.username())
                .orElseThrow(() -> recordFailedLogin(request.username()));

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw recordFailedLogin(request.username());
        }

        user.setLastLoginAt(Instant.now());
        appUserRepository.save(user);

        AuthenticatedUser authenticatedUser = toAuthenticatedUser(user);
        String token = jwtTokenService.generateToken(authenticatedUser);

        auditRecorder.record(new AuditEventRequest(
                AuditEventType.USER_LOGIN,
                "app_user",
                user.getUsername(),
                user.getUsername(),
                AuditDetailsBuilder.create()
                        .put("role", user.getRole().name())
                        .build()
        ));

        return new LoginResponse(token, jwtTokenService.getExpirationMs(), UserProfileResponse.from(user));
    }

    @Transactional(readOnly = true)
    public UserProfileResponse currentUser() {
        AuthenticatedUser user = SecurityContextAccessor.currentUserOrNull();
        if (user != null) {
            return UserProfileResponse.from(user);
        }

        return appUserRepository.findByUsernameAndEnabledTrue(SecurityContextAccessor.currentUsernameOrSystem())
                .map(UserProfileResponse::from)
                .orElseThrow(InvalidCredentialsException::new);
    }

    public void establishSecurityContext(AuthenticatedUser user) {
        SecurityContextHolder.getContext().setAuthentication(new EopAuthenticationToken(user));
    }

    private InvalidCredentialsException recordFailedLogin(String username) {
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.USER_LOGIN_FAILED,
                "app_user",
                username,
                username == null ? "anonymous" : username,
                AuditDetailsBuilder.create()
                        .put("username", username)
                        .build()
        ));
        return new InvalidCredentialsException();
    }

    private AuthenticatedUser toAuthenticatedUser(AppUserEntity user) {
        return new AuthenticatedUser(
                user.getUsername(),
                user.getRole(),
                user.getTeamId(),
                user.getDisplayName(),
                user.getEmail()
        );
    }
}
