package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.JobRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Health and provider verification endpoints for development and operations.
 */
@RestController
@RequestMapping("/api/v1")
public class HealthController {

    private final BuildProvider buildProvider;
    private final JobRepository jobRepository;

    public HealthController(BuildProvider buildProvider, JobRepository jobRepository) {
        this.buildProvider = buildProvider;
        this.jobRepository = jobRepository;
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "application", "Enterprise Engineering Operations Platform"
        ));
    }

    @GetMapping("/provider/jobs")
    public ResponseEntity<List<Job>> getProviderJobs() {
        return ResponseEntity.ok(buildProvider.getConfiguredJobs());
    }

    @GetMapping("/provider/jobs/{jobId}/latest-build")
    public ResponseEntity<Build> getLatestBuild(@PathVariable String jobId) {
        Build build = buildProvider.getLatestBuild(jobId);
        if (build == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(build);
    }

    @GetMapping("/provider/running-builds")
    public ResponseEntity<List<Build>> getRunningBuilds() {
        Set<String> monitoredJobIds = jobRepository.findByEnabledTrueAndPollingEnabledTrue().stream()
                .map(JobEntity::getExternalId)
                .collect(Collectors.toSet());
        List<Build> running = buildProvider.getRunningBuilds().stream()
                .filter(build -> monitoredJobIds.contains(build.jobId()))
                .toList();
        return ResponseEntity.ok(running);
    }
}
