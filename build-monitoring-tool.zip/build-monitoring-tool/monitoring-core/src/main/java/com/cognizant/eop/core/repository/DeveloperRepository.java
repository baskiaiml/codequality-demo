package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.DeveloperEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DeveloperRepository extends JpaRepository<DeveloperEntity, Long> {

    Optional<DeveloperEntity> findByUsername(String username);
}
