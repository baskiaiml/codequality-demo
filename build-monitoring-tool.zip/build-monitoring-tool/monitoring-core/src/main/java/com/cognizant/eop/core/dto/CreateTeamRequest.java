package com.cognizant.eop.core.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateTeamRequest(
        @NotNull Long groupId,
        @NotBlank @Size(max = 100) String name,
        @Size(max = 255) String email
) {
}
