package com.cognizant.eop.core.service;

import com.cognizant.eop.api.analyzer.AIAnalyzer;
import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.mapper.FailureAnalysisMapper;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class FailureAnalysisService {

    private static final Logger log = LoggerFactory.getLogger(FailureAnalysisService.class);

    private final BuildRepository buildRepository;
    private final FailureRepository failureRepository;
    private final JobRepository jobRepository;
    private final BuildProvider buildProvider;
    private final AIAnalyzer aiAnalyzer;
    private final FailureAnalysisMapper failureAnalysisMapper;
    private final PlatformConfigurationService platformConfigurationService;

    public FailureAnalysisService(
            BuildRepository buildRepository,
            FailureRepository failureRepository,
            JobRepository jobRepository,
            BuildProvider buildProvider,
            AIAnalyzer aiAnalyzer,
            FailureAnalysisMapper failureAnalysisMapper,
            PlatformConfigurationService platformConfigurationService) {
        this.buildRepository = buildRepository;
        this.failureRepository = failureRepository;
        this.jobRepository = jobRepository;
        this.buildProvider = buildProvider;
        this.aiAnalyzer = aiAnalyzer;
        this.failureAnalysisMapper = failureAnalysisMapper;
        this.platformConfigurationService = platformConfigurationService;
    }

    @Transactional(readOnly = true)
    public Optional<FailureEntity> findByBuildExternalId(String buildExternalId) {
        return buildRepository.findByExternalId(buildExternalId)
                .flatMap(build -> failureRepository.findByBuildId(build.getId()));
    }

    @Transactional
    public FailureEntity getOrCreateAnalysis(String buildExternalId) {
        Optional<FailureEntity> existing = findByBuildExternalId(buildExternalId);
        if (existing.isPresent()) {
            return existing.get();
        }
        return analyzeAndPersist(buildExternalId).failure();
    }

    @Transactional
    public FailureAnalysisResult analyzeAndPersist(String buildExternalId) {
        BuildEntity build = buildRepository.findByExternalId(buildExternalId)
                .orElseThrow(() -> new BuildNotFoundException(buildExternalId));

        Optional<FailureEntity> existing = failureRepository.findByBuildId(build.getId());
        AIAnalysis analysis = runAnalysis(buildExternalId, build.getTriggeredBy());

        if (existing.isPresent()) {
            FailureEntity failure = existing.get();
            if (Objects.equals(failure.getRootCause(), analysis.rootCause())) {
                log.debug("Failure analysis unchanged for buildExternalId={}", buildExternalId);
                return new FailureAnalysisResult(failure, FailureAnalysisOutcome.UNCHANGED);
            }
            updateFailure(failure, analysis);
            log.info("Updated failure analysis: buildExternalId={}, category={}",
                    buildExternalId, analysis.failureType());
            return new FailureAnalysisResult(
                    failureRepository.save(failure),
                    FailureAnalysisOutcome.UPDATED);
        }

        FailureEntity failure = failureAnalysisMapper.toEntity(analysis, build);
        log.info("Persisted failure analysis: buildExternalId={}, category={}, confidence={}",
                buildExternalId, analysis.failureType(), analysis.confidenceScore());
        return new FailureAnalysisResult(
                failureRepository.save(failure),
                FailureAnalysisOutcome.CREATED);
    }

    @Transactional
    public int markJobFailuresResolved(String jobExternalId) {
        return jobRepository.findByExternalId(jobExternalId)
                .map(job -> {
                    List<FailureEntity> unresolved =
                            failureRepository.findByBuild_JobIdAndResolvedFalse(job.getId());
                    Instant now = Instant.now();
                    for (FailureEntity failure : unresolved) {
                        failure.setResolved(true);
                        failure.setResolvedAt(now);
                    }
                    if (!unresolved.isEmpty()) {
                        log.info("Marked {} failure(s) resolved for jobExternalId={}",
                                unresolved.size(), jobExternalId);
                    }
                    return unresolved.size();
                })
                .orElse(0);
    }

    private AIAnalysis runAnalysis(String buildExternalId, String triggeredBy) {
        BuildLog buildLog = buildProvider.getBuildLog(buildExternalId);
        AIAnalysis analysis = aiAnalyzer.analyze(buildLog);
        analysis = applyConfidenceThreshold(analysis);
        String possibleOwner = resolvePossibleOwner(buildExternalId, triggeredBy);
        return enrichWithOwner(analysis, possibleOwner);
    }

    private AIAnalysis applyConfidenceThreshold(AIAnalysis analysis) {
        BigDecimal threshold = platformConfigurationService.getConfidenceThreshold();
        if (analysis.confidenceScore().compareTo(threshold) >= 0) {
            return analysis;
        }

        return new AIAnalysis(
                FailureCategory.UNKNOWN_FAILURE,
                analysis.confidenceScore(),
                analysis.rootCause(),
                analysis.suggestedFix(),
                analysis.affectedModule(),
                analysis.possibleOwner(),
                analysis.relevantClasses(),
                analysis.sqlObjects(),
                analysis.logSnippet(),
                "Confidence below threshold (" + threshold + "). Manual investigation recommended.",
                analysis.developerImpact(),
                analysis.severity()
        );
    }

    private String resolvePossibleOwner(String buildExternalId, String triggeredBy) {
        List<Commit> commits = buildProvider.getChanges(buildExternalId);
        if (!commits.isEmpty()) {
            return commits.getFirst().author();
        }
        if (triggeredBy != null && !triggeredBy.isBlank()) {
            return triggeredBy;
        }
        return null;
    }

    private AIAnalysis enrichWithOwner(AIAnalysis analysis, String possibleOwner) {
        if (possibleOwner == null || possibleOwner.equals(analysis.possibleOwner())) {
            return analysis;
        }
        return new AIAnalysis(
                analysis.failureType(),
                analysis.confidenceScore(),
                analysis.rootCause(),
                analysis.suggestedFix(),
                analysis.affectedModule(),
                possibleOwner,
                analysis.relevantClasses(),
                analysis.sqlObjects(),
                analysis.logSnippet(),
                analysis.recommendation(),
                analysis.developerImpact(),
                analysis.severity()
        );
    }

    private void updateFailure(FailureEntity failure, AIAnalysis analysis) {
        failure.setCategory(analysis.failureType());
        failure.setConfidenceScore(analysis.confidenceScore());
        failure.setRootCause(analysis.rootCause());
        failure.setSuggestedFix(analysis.suggestedFix());
        failure.setAffectedModule(analysis.affectedModule());
        failure.setPossibleOwner(analysis.possibleOwner());
        failure.setRelevantClasses(failureAnalysisMapper.joinList(analysis.relevantClasses()));
        failure.setSqlObjects(failureAnalysisMapper.joinList(analysis.sqlObjects()));
        failure.setLogSnippet(analysis.logSnippet());
        failure.setRecommendation(analysis.recommendation());
        failure.setDeveloperImpact(analysis.developerImpact());
        failure.setSeverity(analysis.severity());
    }
}

