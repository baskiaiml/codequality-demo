package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.dto.JobSummaryResponse;
import com.cognizant.eop.core.dto.JobSyncResponse;
import com.cognizant.eop.core.dto.MonitorJobRequest;
import com.cognizant.eop.core.controller.JobController.BuildChangeResponse;
import com.cognizant.eop.core.service.JobBuildProcessingService;
import com.cognizant.eop.core.service.JobService;
import com.cognizant.eop.security.auth.SecurityContextAccessor;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/jobs")
public class JobAdminController {

    private final JobService jobService;
    private final JobBuildProcessingService jobBuildProcessingService;
    private final AuditRecorder auditRecorder;

    public JobAdminController(
            JobService jobService,
            JobBuildProcessingService jobBuildProcessingService,
            AuditRecorder auditRecorder) {
        this.jobService = jobService;
        this.jobBuildProcessingService = jobBuildProcessingService;
        this.auditRecorder = auditRecorder;
    }

    @PostMapping
    public ResponseEntity<JobSummaryResponse> registerForMonitoring(@Valid @RequestBody MonitorJobRequest request) {
        JobSummaryResponse job = jobService.registerForMonitoring(request.teamId(), request.externalId());
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.JOB_MONITORING_ENABLED,
                "job",
                job.externalId(),
                SecurityContextAccessor.currentUsernameOrSystem(),
                AuditDetailsBuilder.create()
                        .put("teamId", job.teamId())
                        .put("teamName", job.teamName())
                        .build()
        ));
        return ResponseEntity.status(HttpStatus.CREATED).body(job);
    }

    @DeleteMapping("/{externalId}")
    public ResponseEntity<JobSummaryResponse> removeFromMonitoring(@PathVariable String externalId) {
        JobSummaryResponse job = jobService.removeFromMonitoring(externalId);
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.JOB_MONITORING_DISABLED,
                "job",
                job.externalId(),
                SecurityContextAccessor.currentUsernameOrSystem(),
                AuditDetailsBuilder.create()
                        .put("teamId", job.teamId())
                        .put("teamName", job.teamName())
                        .build()
        ));
        return ResponseEntity.ok(job);
    }

    @PostMapping("/sync")
    public ResponseEntity<JobSyncResponse> syncJobsFromProvider() {
        int synced = jobService.syncJobsFromProvider();
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.JOB_SYNC,
                "job",
                "provider-sync",
                SecurityContextAccessor.currentUsernameOrSystem(),
                AuditDetailsBuilder.create()
                        .put("jobsSynced", synced)
                        .build()
        ));
        return ResponseEntity.ok(new JobSyncResponse(synced));
    }

    @PostMapping("/{externalId}/process-builds")
    public ResponseEntity<List<BuildChangeResponse>> processBuilds(@PathVariable String externalId) {
        return ResponseEntity.ok(jobBuildProcessingService.processBuilds(externalId).stream()
                .map(BuildChangeResponse::from)
                .toList());
    }
}
