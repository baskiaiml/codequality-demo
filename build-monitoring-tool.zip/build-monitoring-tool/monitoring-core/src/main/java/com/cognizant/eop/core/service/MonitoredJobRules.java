package com.cognizant.eop.core.service;

import com.cognizant.eop.core.entity.JobEntity;

/**
 * Shared rules for jobs that are actively monitored from the build provider.
 */
public final class MonitoredJobRules {

    private MonitoredJobRules() {
    }

    public static boolean isMonitored(JobEntity job) {
        return job != null && job.isEnabled() && job.isPollingEnabled();
    }
}
