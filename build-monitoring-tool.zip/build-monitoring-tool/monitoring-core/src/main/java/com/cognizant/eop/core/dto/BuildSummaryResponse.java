package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.BuildEntity;

import java.time.Instant;

public record BuildSummaryResponse(
        Long id,
        String externalId,
        String jobExternalId,
        String jobName,
        int buildNumber,
        String status,
        String branch,
        Instant startedAt,
        Instant finishedAt,
        Long durationMs,
        String triggeredBy,
        String buildUrl
) {
    public static BuildSummaryResponse from(BuildEntity entity) {
        return new BuildSummaryResponse(
                entity.getId(),
                entity.getExternalId(),
                entity.getJob().getExternalId(),
                entity.getJob().getName(),
                entity.getBuildNumber(),
                entity.getStatus().name(),
                entity.getBranch(),
                entity.getStartedAt(),
                entity.getFinishedAt(),
                entity.getDurationMs(),
                entity.getTriggeredBy(),
                entity.getBuildUrl()
        );
    }
}
