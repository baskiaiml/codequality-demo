package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.GroupResponse;
import com.cognizant.eop.core.service.OrganizationQueryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/groups")
public class GroupController {

    private final OrganizationQueryService organizationQueryService;

    public GroupController(OrganizationQueryService organizationQueryService) {
        this.organizationQueryService = organizationQueryService;
    }

    @GetMapping
    public ResponseEntity<List<GroupResponse>> listGroups(
            @RequestParam(defaultValue = "false") boolean all) {
        return ResponseEntity.ok(all
                ? organizationQueryService.findAllGroups()
                : organizationQueryService.findGroupsWithMonitoredJobs());
    }
}
