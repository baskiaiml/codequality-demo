package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.NotificationRuleEntity;

import java.time.Instant;

public record NotificationRuleResponse(
        Long id,
        String name,
        String eventType,
        String channel,
        String templateName,
        boolean enabled,
        Instant createdAt
) {
    public static NotificationRuleResponse from(NotificationRuleEntity entity) {
        return new NotificationRuleResponse(
                entity.getId(),
                entity.getName(),
                entity.getEventType(),
                entity.getChannel(),
                entity.getTemplateName(),
                entity.isEnabled(),
                entity.getCreatedAt()
        );
    }
}
