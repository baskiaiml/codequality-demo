package com.cognizant.eop.core.service;

import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BuildFailureProcessingService {

    private final BuildRepository buildRepository;
    private final FailureAnalysisService failureAnalysisService;
    private final NotificationDispatchService notificationDispatchService;

    public BuildFailureProcessingService(
            BuildRepository buildRepository,
            FailureAnalysisService failureAnalysisService,
            NotificationDispatchService notificationDispatchService) {
        this.buildRepository = buildRepository;
        this.failureAnalysisService = failureAnalysisService;
        this.notificationDispatchService = notificationDispatchService;
    }

    /**
     * Runs AI analysis and dispatches failure notifications.
     * Safe to call on already-analyzed builds — notifications are deduplicated.
     */
    @Transactional
    public FailureProcessingResult analyzeAndNotify(String buildExternalId) {
        BuildEntity build = buildRepository.findByExternalId(buildExternalId)
                .orElseThrow(() -> new BuildNotFoundException(buildExternalId));
        String jobExternalId = build.getJob().getExternalId();

        FailureAnalysisResult analysisResult = failureAnalysisService.analyzeAndPersist(buildExternalId);
        int notificationsSent = dispatchNotifications(buildExternalId, jobExternalId, analysisResult.outcome());

        return new FailureProcessingResult(analysisResult, notificationsSent);
    }

    private int dispatchNotifications(
            String buildExternalId,
            String jobExternalId,
            FailureAnalysisOutcome outcome) {
        return switch (outcome) {
            case CREATED -> notificationDispatchService.dispatchBuildFailure(buildExternalId, jobExternalId);
            case UPDATED -> notificationDispatchService.dispatchRootCauseChanged(buildExternalId, jobExternalId);
            case UNCHANGED -> notificationDispatchService.dispatchBuildFailure(buildExternalId, jobExternalId);
        };
    }
}
