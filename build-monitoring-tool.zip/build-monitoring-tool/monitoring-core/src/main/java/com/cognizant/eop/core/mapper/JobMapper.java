package com.cognizant.eop.core.mapper;

import com.cognizant.eop.api.model.Job;
import com.cognizant.eop.core.entity.JobEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface JobMapper {

    @Mapping(target = "id", source = "externalId")
    Job toDomain(JobEntity entity);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "team", ignore = true)
    @Mapping(target = "builds", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "externalId", source = "id")
    @Mapping(target = "buildType", source = "buildTypeId")
    JobEntity toEntity(Job job);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "team", ignore = true)
    @Mapping(target = "builds", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "externalId", source = "id")
    @Mapping(target = "buildType", source = "buildTypeId")
    void updateEntity(Job job, @MappingTarget JobEntity entity);
}
