package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.scheduler.BuildMonitoringOrchestrator;
import com.cognizant.eop.core.scheduler.MonitoringCycleSummary;
import com.cognizant.eop.security.auth.SecurityContextAccessor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Administrative endpoints for scheduler management and manual triggering.
 */
@RestController
@RequestMapping("/api/v1/admin/scheduler")
public class SchedulerController {

    private final BuildMonitoringOrchestrator orchestrator;
    private final AuditRecorder auditRecorder;

    public SchedulerController(BuildMonitoringOrchestrator orchestrator, AuditRecorder auditRecorder) {
        this.orchestrator = orchestrator;
        this.auditRecorder = auditRecorder;
    }

    @PostMapping("/trigger")
    public ResponseEntity<MonitoringCycleSummary> triggerMonitoringCycle() {
        MonitoringCycleSummary summary = orchestrator.executeMonitoringCycle();
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.SCHEDULER_TRIGGERED,
                "scheduler",
                "manual",
                SecurityContextAccessor.currentUsernameOrSystem(),
                AuditDetailsBuilder.create()
                        .put("jobsChecked", summary.jobsChecked())
                        .put("newBuilds", summary.newBuilds())
                        .put("failures", summary.failures())
                        .build()
        ));
        return ResponseEntity.ok(summary);
    }

    @GetMapping("/last-cycle")
    public ResponseEntity<MonitoringCycleSummary> getLastCycleSummary() {
        MonitoringCycleSummary summary = orchestrator.getLastCycleSummary();
        if (summary == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(summary);
    }
}
