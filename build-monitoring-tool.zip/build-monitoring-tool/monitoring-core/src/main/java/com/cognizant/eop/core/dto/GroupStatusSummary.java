package com.cognizant.eop.core.dto;

public record GroupStatusSummary(
        Long groupId,
        String groupName,
        long jobCount,
        long activeFailures,
        double successRatePercent
) {}
