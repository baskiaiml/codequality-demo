package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.NotificationEntity;

import java.time.Instant;

public record NotificationResponse(
        Long id,
        String channel,
        String recipient,
        String subject,
        String notificationType,
        String status,
        Instant sentAt
) {
    public static NotificationResponse from(NotificationEntity entity) {
        return new NotificationResponse(
                entity.getId(),
                entity.getChannel(),
                entity.getRecipient(),
                entity.getSubject(),
                entity.getNotificationType(),
                entity.getStatus(),
                entity.getSentAt()
        );
    }
}
