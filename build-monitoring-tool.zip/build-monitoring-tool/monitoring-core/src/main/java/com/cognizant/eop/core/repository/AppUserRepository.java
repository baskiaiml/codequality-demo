package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.AppUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUserEntity, Long> {

    Optional<AppUserEntity> findByUsernameAndEnabledTrue(String username);
}
