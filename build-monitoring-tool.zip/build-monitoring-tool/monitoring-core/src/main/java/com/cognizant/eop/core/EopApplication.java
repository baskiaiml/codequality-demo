package com.cognizant.eop.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Enterprise Engineering Operations Platform — application entry point.
 */
@SpringBootApplication(
        scanBasePackages = "com.cognizant.eop",
        exclude = UserDetailsServiceAutoConfiguration.class
)
@EnableCaching
public class EopApplication {

    public static void main(String[] args) {
        SpringApplication.run(EopApplication.class, args);
    }
}
