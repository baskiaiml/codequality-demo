package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.service.FailureProcessingResult;

public record FailureProcessingResponse(
        String buildId,
        String analysisOutcome,
        String failureCategory,
        int notificationsSent
) {
    public static FailureProcessingResponse from(String buildId, FailureProcessingResult result) {
        return new FailureProcessingResponse(
                buildId,
                result.analysisResult().outcome().name(),
                result.analysisResult().failure().getCategory().name(),
                result.notificationsSent()
        );
    }
}
