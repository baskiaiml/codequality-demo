package com.cognizant.eop.core.entity;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "failure")
@Getter
@Setter
@NoArgsConstructor
public class FailureEntity extends BaseEntity {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "build_id", nullable = false, unique = true)
    private BuildEntity build;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 100)
    private FailureCategory category;

    @Column(name = "confidence_score", precision = 5, scale = 2)
    private BigDecimal confidenceScore;

    @Column(name = "root_cause", columnDefinition = "TEXT")
    private String rootCause;

    @Column(name = "suggested_fix", columnDefinition = "TEXT")
    private String suggestedFix;

    @Column(name = "affected_module", length = 255)
    private String affectedModule;

    @Column(name = "possible_owner", length = 255)
    private String possibleOwner;

    @Column(name = "relevant_classes", columnDefinition = "TEXT")
    private String relevantClasses;

    @Column(name = "sql_objects", columnDefinition = "TEXT")
    private String sqlObjects;

    @Column(name = "log_snippet", columnDefinition = "TEXT")
    private String logSnippet;

    @Column(columnDefinition = "TEXT")
    private String recommendation;

    @Column(name = "developer_impact", length = 500)
    private String developerImpact;

    @Enumerated(EnumType.STRING)
    @Column(length = 50)
    private Severity severity;

    @Column(nullable = false)
    private boolean resolved = false;

    @Column(name = "resolved_at")
    private Instant resolvedAt;
}
