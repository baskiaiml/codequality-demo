package com.cognizant.eop.core.dto;

import java.util.List;

public record TeamDashboardResponse(
        Long teamId,
        String teamName,
        String groupName,
        String email,
        long jobCount,
        long activeFailures,
        double successRatePercent,
        List<JobSummaryResponse> jobs,
        List<FailureSummaryResponse> recentFailures
) {}
