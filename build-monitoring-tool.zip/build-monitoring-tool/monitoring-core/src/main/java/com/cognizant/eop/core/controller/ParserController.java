package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.dto.LogParseResponse;
import com.cognizant.eop.parser.BuildLogParser;
import com.cognizant.eop.parser.model.LogParseResult;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST API for parsing build logs against the knowledge base.
 */
@RestController
@RequestMapping("/api/v1/builds")
public class ParserController {

    private final BuildProvider buildProvider;
    private final BuildLogParser buildLogParser;

    public ParserController(BuildProvider buildProvider, BuildLogParser buildLogParser) {
        this.buildProvider = buildProvider;
        this.buildLogParser = buildLogParser;
    }

    @GetMapping("/{buildId}/parse")
    public ResponseEntity<LogParseResponse> parseBuildLog(@PathVariable String buildId) {
        BuildLog buildLog = buildProvider.getBuildLog(buildId);
        LogParseResult result = buildLogParser.parse(buildLog);
        return ResponseEntity.ok(LogParseResponse.from(result));
    }
}
