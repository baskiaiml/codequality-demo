package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.FailureEntity;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * REST response DTO for persisted build failure analysis.
 */
public record FailureAnalysisResponse(
        String buildId,
        String category,
        BigDecimal confidenceScore,
        String rootCause,
        String suggestedFix,
        String affectedModule,
        String possibleOwner,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String logSnippet,
        String recommendation,
        String developerImpact,
        String severity,
        boolean resolved,
        Instant analyzedAt
) {
    public static FailureAnalysisResponse from(FailureEntity failure) {
        return new FailureAnalysisResponse(
                failure.getBuild().getExternalId(),
                failure.getCategory().name(),
                failure.getConfidenceScore(),
                failure.getRootCause(),
                failure.getSuggestedFix(),
                failure.getAffectedModule(),
                failure.getPossibleOwner(),
                splitList(failure.getRelevantClasses()),
                splitList(failure.getSqlObjects()),
                failure.getLogSnippet(),
                failure.getRecommendation(),
                failure.getDeveloperImpact(),
                failure.getSeverity() != null ? failure.getSeverity().name() : null,
                failure.isResolved(),
                failure.getCreatedAt()
        );
    }

    private static List<String> splitList(String value) {
        if (value == null || value.isBlank()) {
            return Collections.emptyList();
        }
        return Arrays.stream(value.split(",\\s*")).toList();
    }
}
