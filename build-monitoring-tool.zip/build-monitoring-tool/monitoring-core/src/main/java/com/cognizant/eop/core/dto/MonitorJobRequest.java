package com.cognizant.eop.core.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record MonitorJobRequest(
        @NotNull Long teamId,
        @NotBlank @Size(max = 255) String externalId
) {
}
