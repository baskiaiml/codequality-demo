package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.NotificationResponse;
import com.cognizant.eop.core.service.NotificationDispatchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/builds")
public class NotificationController {

    private final NotificationDispatchService notificationDispatchService;

    public NotificationController(NotificationDispatchService notificationDispatchService) {
        this.notificationDispatchService = notificationDispatchService;
    }

    @GetMapping("/{buildId}/notifications")
    public ResponseEntity<List<NotificationResponse>> getBuildNotifications(@PathVariable String buildId) {
        List<NotificationResponse> notifications = notificationDispatchService.findByBuildExternalId(buildId)
                .stream()
                .map(NotificationResponse::from)
                .toList();
        return ResponseEntity.ok(notifications);
    }
}
