package com.cognizant.eop.core.service;

import com.cognizant.eop.core.repository.ConfigurationRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class PlatformConfigurationService {

    static final String CONFIDENCE_THRESHOLD_KEY = "ai.confidence.threshold";
    static final String NOTIFICATION_ENABLED_KEY = "notification.enabled";
    private static final BigDecimal DEFAULT_CONFIDENCE_THRESHOLD = BigDecimal.valueOf(50);

    private final ConfigurationRepository configurationRepository;

    public PlatformConfigurationService(ConfigurationRepository configurationRepository) {
        this.configurationRepository = configurationRepository;
    }

    public BigDecimal getConfidenceThreshold() {
        return configurationRepository.findByConfigKey(CONFIDENCE_THRESHOLD_KEY)
                .map(config -> new BigDecimal(config.getConfigValue()))
                .orElse(DEFAULT_CONFIDENCE_THRESHOLD);
    }

    public boolean isNotificationEnabled() {
        return configurationRepository.findByConfigKey(NOTIFICATION_ENABLED_KEY)
                .map(config -> Boolean.parseBoolean(config.getConfigValue()))
                .orElse(true);
    }
}
