package com.cognizant.eop.core.service;

public class TeamAlreadyExistsException extends RuntimeException {

    public TeamAlreadyExistsException(String name) {
        super("Team already exists with name: " + name);
    }
}
