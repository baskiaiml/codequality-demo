package com.cognizant.eop.core.service;

import com.cognizant.eop.core.scheduler.BuildChangePostProcessor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobBuildProcessingService {

    private final BuildPersistenceService buildPersistenceService;
    private final BuildChangePostProcessor buildChangePostProcessor;

    public JobBuildProcessingService(
            BuildPersistenceService buildPersistenceService,
            BuildChangePostProcessor buildChangePostProcessor) {
        this.buildPersistenceService = buildPersistenceService;
        this.buildChangePostProcessor = buildChangePostProcessor;
    }

    public List<BuildChangeResult> processBuilds(String externalId) {
        List<BuildChangeResult> results = buildPersistenceService.processJob(externalId);
        for (BuildChangeResult change : results) {
            buildChangePostProcessor.process(change, externalId);
        }
        return results;
    }
}
