package com.cognizant.eop.core.service;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.dto.ConfigurationResponse;
import com.cognizant.eop.core.dto.ConfigurationUpdateRequest;
import com.cognizant.eop.core.entity.ConfigurationEntity;
import com.cognizant.eop.core.repository.ConfigurationRepository;
import com.cognizant.eop.security.auth.SecurityContextAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class ConfigurationAdminService {

    private final ConfigurationRepository configurationRepository;
    private final AuditRecorder auditRecorder;

    public ConfigurationAdminService(
            ConfigurationRepository configurationRepository,
            AuditRecorder auditRecorder) {
        this.configurationRepository = configurationRepository;
        this.auditRecorder = auditRecorder;
    }

    @Transactional(readOnly = true)
    public List<ConfigurationResponse> findAll() {
        return configurationRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public ConfigurationResponse update(String configKey, ConfigurationUpdateRequest request) {
        ConfigurationEntity entity = configurationRepository.findByConfigKey(configKey)
                .orElseThrow(() -> new ConfigurationNotFoundException(configKey));
        String previousValue = entity.getConfigValue();
        String actor = SecurityContextAccessor.currentUsernameOrSystem();
        entity.setConfigValue(request.configValue());
        entity.setUpdatedBy(actor);
        entity.setUpdatedAt(Instant.now());
        ConfigurationEntity saved = configurationRepository.save(entity);

        auditRecorder.record(new AuditEventRequest(
                AuditEventType.CONFIG_UPDATED,
                "configuration",
                configKey,
                actor,
                AuditDetailsBuilder.create()
                        .put("previousValue", previousValue)
                        .put("newValue", request.configValue())
                        .build()
        ));

        return toResponse(saved);
    }

    private ConfigurationResponse toResponse(ConfigurationEntity entity) {
        return new ConfigurationResponse(
                entity.getId(),
                entity.getConfigKey(),
                entity.getConfigValue(),
                entity.getDescription()
        );
    }
}
