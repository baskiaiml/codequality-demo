package com.cognizant.eop.core.service;

public class ConfigurationNotFoundException extends RuntimeException {

    public ConfigurationNotFoundException(String configKey) {
        super("Configuration not found with key: " + configKey);
    }
}
