package com.cognizant.eop.core.dto;

import jakarta.validation.constraints.NotBlank;

public record ConfigurationUpdateRequest(
        @NotBlank String configValue
) {}
