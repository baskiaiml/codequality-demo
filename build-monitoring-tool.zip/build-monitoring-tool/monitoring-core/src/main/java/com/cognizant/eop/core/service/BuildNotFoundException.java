package com.cognizant.eop.core.service;

/**
 * Thrown when a build cannot be found by external identifier.
 */
public class BuildNotFoundException extends RuntimeException {

    public BuildNotFoundException(String buildExternalId) {
        super("Build not found with external id: " + buildExternalId);
    }
}
