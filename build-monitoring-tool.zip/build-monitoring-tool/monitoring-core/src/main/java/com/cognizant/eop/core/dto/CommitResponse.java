package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.BuildCommitEntity;

import java.time.Instant;

public record CommitResponse(
        String hash,
        String author,
        String message,
        Instant timestamp
) {
    public static CommitResponse from(BuildCommitEntity entity) {
        return new CommitResponse(
                entity.getCommitHash(),
                entity.getAuthor(),
                entity.getMessage(),
                entity.getTimestamp()
        );
    }
}
