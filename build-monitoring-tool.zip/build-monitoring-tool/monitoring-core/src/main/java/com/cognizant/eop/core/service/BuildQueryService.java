package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.provider.BuildProvider;
import com.cognizant.eop.core.dto.BuildDetailResponse;
import com.cognizant.eop.core.dto.BuildLogResponse;
import com.cognizant.eop.core.dto.BuildSummaryResponse;
import com.cognizant.eop.core.dto.CommitResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.BuildCommitRepository;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.repository.spec.EntitySpecs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class BuildQueryService {

    private final BuildRepository buildRepository;
    private final BuildCommitRepository buildCommitRepository;
    private final FailureRepository failureRepository;
    private final JobRepository jobRepository;
    private final BuildProvider buildProvider;

    public BuildQueryService(
            BuildRepository buildRepository,
            BuildCommitRepository buildCommitRepository,
            FailureRepository failureRepository,
            JobRepository jobRepository,
            BuildProvider buildProvider) {
        this.buildRepository = buildRepository;
        this.buildCommitRepository = buildCommitRepository;
        this.failureRepository = failureRepository;
        this.jobRepository = jobRepository;
        this.buildProvider = buildProvider;
    }

    @Transactional(readOnly = true)
    public PageResponse<BuildSummaryResponse> findBuilds(
            Pageable pageable,
            BuildStatus status,
            Long teamId,
            Instant from,
            Instant to) {
        Specification<BuildEntity> spec = Specification.allOf(
                EntitySpecs.buildHasStatus(status),
                EntitySpecs.buildHasTeamId(teamId),
                EntitySpecs.buildStartedAfter(from),
                EntitySpecs.buildStartedBefore(to)
        );

        Page<BuildSummaryResponse> page = buildRepository.findAll(spec, pageable)
                .map(BuildSummaryResponse::from);
        return PageResponse.from(page);
    }

    @Transactional(readOnly = true)
    public BuildDetailResponse findByExternalId(String externalId) {
        BuildEntity build = buildRepository.findByExternalId(externalId)
                .orElseThrow(() -> new BuildNotFoundException(externalId));

        List<CommitResponse> commits = buildCommitRepository.findByBuildId(build.getId())
                .stream()
                .map(CommitResponse::from)
                .toList();
        boolean hasFailureAnalysis = failureRepository.findByBuildId(build.getId()).isPresent();

        return BuildDetailResponse.from(build, commits, hasFailureAnalysis);
    }

    @Transactional(readOnly = true)
    public List<BuildSummaryResponse> findRunningBuilds() {
        Set<String> monitoredJobIds = jobRepository.findByEnabledTrueAndPollingEnabledTrue().stream()
                .map(JobEntity::getExternalId)
                .collect(Collectors.toSet());

        return buildProvider.getRunningBuilds().stream()
                .filter(build -> monitoredJobIds.contains(build.jobId()))
                .map(this::toRunningBuildSummary)
                .toList();
    }

    public BuildLogResponse getBuildLog(String buildExternalId) {
        buildRepository.findByExternalId(buildExternalId)
                .orElseThrow(() -> new BuildNotFoundException(buildExternalId));

        BuildLog buildLog = buildProvider.getBuildLog(buildExternalId);
        return new BuildLogResponse(buildLog.buildId(), buildLog.content());
    }

    private BuildSummaryResponse toRunningBuildSummary(Build build) {
        return buildRepository.findByExternalId(build.id())
                .map(BuildSummaryResponse::from)
                .orElseGet(() -> new BuildSummaryResponse(
                        null,
                        build.id(),
                        build.jobId(),
                        resolveJobName(build.jobId()),
                        build.buildNumber(),
                        build.status().name(),
                        build.branch(),
                        build.startedAt(),
                        build.finishedAt(),
                        build.durationMs(),
                        build.triggeredBy(),
                        build.buildUrl()
                ));
    }

    private String resolveJobName(String jobExternalId) {
        return jobRepository.findByExternalId(jobExternalId)
                .map(job -> job.getName())
                .orElse(jobExternalId);
    }
}
