package com.cognizant.eop.core.service;

public class GroupNotFoundException extends RuntimeException {

    public GroupNotFoundException(Long groupId) {
        super("Group not found with id: " + groupId);
    }
}
