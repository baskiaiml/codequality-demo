package com.cognizant.eop.core.entity;

import com.cognizant.eop.api.model.BuildStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "build", uniqueConstraints = @UniqueConstraint(columnNames = {"job_id", "build_number"}))
@Getter
@Setter
@NoArgsConstructor
public class BuildEntity extends BaseEntity {

    @Column(name = "external_id", nullable = false, unique = true, length = 255)
    private String externalId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private JobEntity job;

    @Column(name = "build_number", nullable = false)
    private int buildNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private BuildStatus status;

    @Column(length = 255)
    private String branch;

    @Column(name = "started_at")
    private Instant startedAt;

    @Column(name = "finished_at")
    private Instant finishedAt;

    @Column(name = "duration_ms")
    private Long durationMs;

    @Column(name = "triggered_by", length = 255)
    private String triggeredBy;

    @Column(name = "build_url", length = 1000)
    private String buildUrl;

    @OneToMany(mappedBy = "build")
    private List<BuildCommitEntity> commits = new ArrayList<>();

    @OneToOne(mappedBy = "build")
    private FailureEntity failure;
}
