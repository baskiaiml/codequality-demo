package com.cognizant.eop.core.dto;

import java.util.List;
import java.util.Map;

public record GlobalDashboardResponse(
        long totalJobs,
        long runningBuilds,
        long activeFailures,
        double successRatePercent,
        List<FailureSummaryResponse> recentFailures,
        List<BuildSummaryResponse> runningBuildSummaries,
        Map<String, Long> failuresByCategory,
        List<GroupStatusSummary> groupSummaries
) {}
