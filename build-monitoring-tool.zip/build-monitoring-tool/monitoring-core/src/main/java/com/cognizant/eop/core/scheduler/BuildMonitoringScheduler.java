package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.config.SchedulerProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Spring Scheduler that triggers build monitoring every configured interval (default 5 minutes).
 */
@Component
@ConditionalOnProperty(name = "eop.scheduler.enabled", havingValue = "true", matchIfMissing = true)
public class BuildMonitoringScheduler {

    private static final Logger log = LoggerFactory.getLogger(BuildMonitoringScheduler.class);

    private final BuildMonitoringOrchestrator orchestrator;
    private final SchedulerProperties schedulerProperties;

    public BuildMonitoringScheduler(
            BuildMonitoringOrchestrator orchestrator,
            SchedulerProperties schedulerProperties) {
        this.orchestrator = orchestrator;
        this.schedulerProperties = schedulerProperties;
    }

    @Scheduled(fixedDelayString = "${eop.scheduler.polling-interval-ms:300000}")
    public void runMonitoringCycle() {
        log.debug("Scheduled monitoring cycle triggered (intervalMs={})",
                schedulerProperties.pollingIntervalMs());
        orchestrator.executeMonitoringCycle();
    }
}
