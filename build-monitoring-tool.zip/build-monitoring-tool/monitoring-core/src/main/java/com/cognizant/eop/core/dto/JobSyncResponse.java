package com.cognizant.eop.core.dto;

public record JobSyncResponse(
        int jobsSynced
) {
}
