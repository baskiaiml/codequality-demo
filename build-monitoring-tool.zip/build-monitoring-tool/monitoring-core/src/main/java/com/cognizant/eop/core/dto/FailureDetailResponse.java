package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.FailureEntity;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public record FailureDetailResponse(
        Long id,
        String buildExternalId,
        String jobExternalId,
        String jobName,
        Long teamId,
        String teamName,
        String category,
        BigDecimal confidenceScore,
        String rootCause,
        String suggestedFix,
        String affectedModule,
        String possibleOwner,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String logSnippet,
        String recommendation,
        String developerImpact,
        String severity,
        boolean resolved,
        Instant resolvedAt,
        Instant analyzedAt
) {
    public static FailureDetailResponse from(FailureEntity entity) {
        return new FailureDetailResponse(
                entity.getId(),
                entity.getBuild().getExternalId(),
                entity.getBuild().getJob().getExternalId(),
                entity.getBuild().getJob().getName(),
                entity.getBuild().getJob().getTeam() != null ? entity.getBuild().getJob().getTeam().getId() : null,
                entity.getBuild().getJob().getTeam() != null ? entity.getBuild().getJob().getTeam().getName() : null,
                entity.getCategory().name(),
                entity.getConfidenceScore(),
                entity.getRootCause(),
                entity.getSuggestedFix(),
                entity.getAffectedModule(),
                entity.getPossibleOwner(),
                splitList(entity.getRelevantClasses()),
                splitList(entity.getSqlObjects()),
                entity.getLogSnippet(),
                entity.getRecommendation(),
                entity.getDeveloperImpact(),
                entity.getSeverity() != null ? entity.getSeverity().name() : null,
                entity.isResolved(),
                entity.getResolvedAt(),
                entity.getCreatedAt()
        );
    }

    private static List<String> splitList(String value) {
        if (value == null || value.isBlank()) {
            return Collections.emptyList();
        }
        return Arrays.stream(value.split(",\\s*")).toList();
    }
}
