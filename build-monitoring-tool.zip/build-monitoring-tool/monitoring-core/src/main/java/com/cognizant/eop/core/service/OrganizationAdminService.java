package com.cognizant.eop.core.service;

import com.cognizant.eop.core.dto.CreateTeamRequest;
import com.cognizant.eop.core.dto.TeamResponse;
import com.cognizant.eop.core.entity.GroupEntity;
import com.cognizant.eop.core.entity.TeamEntity;
import com.cognizant.eop.core.repository.TeamRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

/**
 * Admin-only organization management. Teams can be created but not removed.
 */
@Service
public class OrganizationAdminService {

    private final OrganizationQueryService organizationQueryService;
    private final TeamRepository teamRepository;

    public OrganizationAdminService(
            OrganizationQueryService organizationQueryService,
            TeamRepository teamRepository) {
        this.organizationQueryService = organizationQueryService;
        this.teamRepository = teamRepository;
    }

    @Transactional
    public TeamResponse createTeam(CreateTeamRequest request) {
        GroupEntity group = organizationQueryService.requireGroup(request.groupId());
        teamRepository.findByName(request.name())
                .ifPresent(existing -> {
                    throw new TeamAlreadyExistsException(request.name());
                });

        TeamEntity team = new TeamEntity();
        team.setName(request.name().trim());
        team.setGroup(group);
        team.setEmail(request.email());
        team.setEnabled(true);
        team.setUpdatedAt(Instant.now());

        TeamEntity saved = teamRepository.save(team);
        return TeamResponse.from(saved, 0);
    }
}
