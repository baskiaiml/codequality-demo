package com.cognizant.eop.core.service;

/**
 * Thrown when a job cannot be found in the database by its external identifier.
 */
public class JobNotFoundException extends RuntimeException {

    public JobNotFoundException(String jobExternalId) {
        super("Job not found with external id: " + jobExternalId);
    }
}
