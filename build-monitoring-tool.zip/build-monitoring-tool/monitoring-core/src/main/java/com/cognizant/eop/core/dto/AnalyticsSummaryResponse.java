package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.EngineeringMetricsCalculator;

public record AnalyticsSummaryResponse(
        long totalBuilds,
        long successCount,
        long failureCount,
        double successRatePercent,
        Double mttrMinutes,
        Double mtbfHours,
        long activeFailures,
        long resolvedFailures,
        Double averageBuildDurationMs
) {
    public static AnalyticsSummaryResponse from(EngineeringMetricsCalculator.EngineeringMetrics metrics) {
        return new AnalyticsSummaryResponse(
                metrics.totalBuilds(),
                metrics.successCount(),
                metrics.failureCount(),
                metrics.successRatePercent(),
                metrics.mttrMinutes(),
                metrics.mtbfHours(),
                metrics.activeFailures(),
                metrics.resolvedFailures(),
                metrics.averageBuildDurationMs()
        );
    }
}
