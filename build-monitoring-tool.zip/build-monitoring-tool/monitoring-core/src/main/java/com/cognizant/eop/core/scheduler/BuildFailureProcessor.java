package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.service.BuildChangeResult;

/**
 * Handles detected build failures during a monitoring cycle.
 * Implemented by the AI analysis module in a future iteration.
 */
public interface BuildFailureProcessor {

    /**
     * Processes a detected build failure (log download, AI analysis, notification evaluation).
     */
    void processFailure(BuildChangeResult change, String jobExternalId);
}
