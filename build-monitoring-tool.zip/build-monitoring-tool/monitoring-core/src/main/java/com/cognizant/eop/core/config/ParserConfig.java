package com.cognizant.eop.core.config;

import com.cognizant.eop.parser.BuildLogParser;
import com.cognizant.eop.parser.DefaultBuildLogParser;
import com.cognizant.eop.parser.extractor.FailureSnippetExtractor;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader;
import com.cognizant.eop.parser.matcher.PatternMatcher;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ParserConfig {

    @Bean
    KnowledgeBaseLoader knowledgeBaseLoader() {
        KnowledgeBaseLoader loader = new KnowledgeBaseLoader();
        loader.load();
        return loader;
    }

    @Bean
    BuildLogParser buildLogParser(KnowledgeBaseLoader knowledgeBaseLoader) {
        LogPreprocessor preprocessor = new LogPreprocessor();
        PatternMatcher patternMatcher = new PatternMatcher(knowledgeBaseLoader);
        FailureSnippetExtractor snippetExtractor = new FailureSnippetExtractor();
        return new DefaultBuildLogParser(
                knowledgeBaseLoader, preprocessor, patternMatcher, snippetExtractor);
    }
}
