package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.FailureEntity;

import java.time.Instant;

public record FailureSummaryResponse(
        Long id,
        String buildExternalId,
        String jobExternalId,
        String jobName,
        String category,
        String severity,
        boolean resolved,
        String possibleOwner,
        Instant analyzedAt
) {
    public static FailureSummaryResponse from(FailureEntity entity) {
        return new FailureSummaryResponse(
                entity.getId(),
                entity.getBuild().getExternalId(),
                entity.getBuild().getJob().getExternalId(),
                entity.getBuild().getJob().getName(),
                entity.getCategory().name(),
                entity.getSeverity() != null ? entity.getSeverity().name() : null,
                entity.isResolved(),
                entity.getPossibleOwner(),
                entity.getCreatedAt()
        );
    }
}
