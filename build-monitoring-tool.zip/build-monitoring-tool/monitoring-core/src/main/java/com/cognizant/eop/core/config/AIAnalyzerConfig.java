package com.cognizant.eop.core.config;

import com.cognizant.eop.ai.engine.DeveloperImpactAssessor;
import com.cognizant.eop.ai.engine.RuleBasedAnalyzer;
import com.cognizant.eop.api.analyzer.AIAnalyzer;
import com.cognizant.eop.parser.BuildLogParser;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AIAnalyzerConfig {

    @Bean
    @ConditionalOnProperty(name = "eop.ai.analyzer", havingValue = "rule-based", matchIfMissing = true)
    AIAnalyzer ruleBasedAnalyzer(BuildLogParser buildLogParser) {
        return new RuleBasedAnalyzer(buildLogParser, new DeveloperImpactAssessor());
    }
}
