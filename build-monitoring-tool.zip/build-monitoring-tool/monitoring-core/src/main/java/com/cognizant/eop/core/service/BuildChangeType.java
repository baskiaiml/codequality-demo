package com.cognizant.eop.core.service;

/**
 * Describes the type of change detected when comparing a provider build with the last known database state.
 */
public enum BuildChangeType {

    /** No change detected — build and status are identical. */
    UNCHANGED,

    /** A new build was detected (higher build number or unknown external id). */
    NEW_BUILD,

    /** Same build external id but status has changed (e.g. RUNNING → FAILURE). */
    STATUS_CHANGED,

    /** Job transitioned from a failed build to a successful build. */
    RECOVERY,

    /** Build has failed — triggers failure analysis and notification evaluation. */
    FAILURE
}
