package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.BuildEntity;

import java.time.Instant;
import java.util.List;

public record BuildDetailResponse(
        Long id,
        String externalId,
        String jobExternalId,
        String jobName,
        Long teamId,
        String teamName,
        int buildNumber,
        String status,
        String branch,
        Instant startedAt,
        Instant finishedAt,
        Long durationMs,
        String triggeredBy,
        String buildUrl,
        List<CommitResponse> commits,
        boolean hasFailureAnalysis
) {
    public static BuildDetailResponse from(BuildEntity entity, List<CommitResponse> commits, boolean hasFailureAnalysis) {
        return new BuildDetailResponse(
                entity.getId(),
                entity.getExternalId(),
                entity.getJob().getExternalId(),
                entity.getJob().getName(),
                entity.getJob().getTeam() != null ? entity.getJob().getTeam().getId() : null,
                entity.getJob().getTeam() != null ? entity.getJob().getTeam().getName() : null,
                entity.getBuildNumber(),
                entity.getStatus().name(),
                entity.getBranch(),
                entity.getStartedAt(),
                entity.getFinishedAt(),
                entity.getDurationMs(),
                entity.getTriggeredBy(),
                entity.getBuildUrl(),
                commits,
                hasFailureAnalysis
        );
    }
}
