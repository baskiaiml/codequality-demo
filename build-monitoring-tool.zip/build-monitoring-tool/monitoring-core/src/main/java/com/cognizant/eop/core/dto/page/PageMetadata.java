package com.cognizant.eop.core.dto.page;

public record PageMetadata(
        int number,
        int size,
        long totalElements,
        int totalPages
) {}
