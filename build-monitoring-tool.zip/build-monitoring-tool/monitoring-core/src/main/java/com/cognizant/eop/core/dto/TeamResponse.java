package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.TeamEntity;

public record TeamResponse(
        Long id,
        String name,
        Long groupId,
        String groupName,
        String email,
        boolean enabled,
        int jobCount
) {
    public static TeamResponse from(TeamEntity entity, int jobCount) {
        return new TeamResponse(
                entity.getId(),
                entity.getName(),
                entity.getGroup().getId(),
                entity.getGroup().getName(),
                entity.getEmail(),
                entity.isEnabled(),
                jobCount
        );
    }
}
