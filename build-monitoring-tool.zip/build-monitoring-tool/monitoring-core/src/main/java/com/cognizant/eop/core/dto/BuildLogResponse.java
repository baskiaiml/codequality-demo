package com.cognizant.eop.core.dto;

public record BuildLogResponse(
        String buildId,
        String content
) {}
