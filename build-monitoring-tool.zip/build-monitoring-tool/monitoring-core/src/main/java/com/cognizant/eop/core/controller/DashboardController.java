package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.GlobalDashboardResponse;
import com.cognizant.eop.core.dto.GroupDashboardResponse;
import com.cognizant.eop.core.dto.ReleaseReadinessResponse;
import com.cognizant.eop.core.service.AnalyticsService;
import com.cognizant.eop.core.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;
    private final AnalyticsService analyticsService;

    public DashboardController(DashboardService dashboardService, AnalyticsService analyticsService) {
        this.dashboardService = dashboardService;
        this.analyticsService = analyticsService;
    }

    @GetMapping("/global")
    public ResponseEntity<GlobalDashboardResponse> getGlobalDashboard() {
        return ResponseEntity.ok(dashboardService.getGlobalDashboard());
    }

    @GetMapping("/group/{groupId}")
    public ResponseEntity<GroupDashboardResponse> getGroupDashboard(@PathVariable Long groupId) {
        return ResponseEntity.ok(dashboardService.getGroupDashboard(groupId));
    }

    @GetMapping("/release-readiness")
    public ResponseEntity<ReleaseReadinessResponse> getReleaseReadiness(
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) Long groupId) {
        return ResponseEntity.ok(analyticsService.getReleaseReadiness(teamId, groupId));
    }
}
