package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.TopFailuresAggregator;

public record RankingEntryResponse(
        String name,
        long count
) {
    public static RankingEntryResponse from(TopFailuresAggregator.RankingEntry entry) {
        return new RankingEntryResponse(entry.name(), entry.count());
    }
}
