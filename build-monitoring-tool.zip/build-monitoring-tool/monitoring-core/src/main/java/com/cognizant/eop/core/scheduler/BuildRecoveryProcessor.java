package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.service.BuildChangeResult;

/**
 * Handles detected build recoveries during a monitoring cycle.
 * Implemented by the notification module in a future iteration.
 */
public interface BuildRecoveryProcessor {

    /**
     * Processes a detected build recovery (notification evaluation).
     */
    void processRecovery(BuildChangeResult change, String jobExternalId);
}
