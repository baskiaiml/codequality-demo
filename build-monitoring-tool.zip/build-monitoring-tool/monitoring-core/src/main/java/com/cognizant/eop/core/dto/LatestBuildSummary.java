package com.cognizant.eop.core.dto;

import java.time.Instant;

public record LatestBuildSummary(
        String externalId,
        int buildNumber,
        String status,
        Instant startedAt,
        Long durationMs
) {}
