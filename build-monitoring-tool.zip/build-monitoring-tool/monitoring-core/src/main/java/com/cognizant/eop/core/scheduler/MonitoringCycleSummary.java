package com.cognizant.eop.core.scheduler;

import java.time.Instant;

/**
 * Summary of a single build monitoring scheduler execution cycle.
 *
 * @param startTime       when the cycle started
 * @param endTime         when the cycle finished
 * @param jobsChecked     number of jobs evaluated
 * @param newBuilds       number of new or updated builds persisted
 * @param failures        number of failures detected
 * @param recoveries      number of recoveries detected
 * @param notifications   number of notifications sent (zero until notification module)
 * @param errors          number of jobs that failed processing
 * @param durationMs      total execution time in milliseconds
 */
public record MonitoringCycleSummary(
        Instant startTime,
        Instant endTime,
        int jobsChecked,
        int newBuilds,
        int failures,
        int recoveries,
        int notifications,
        int errors,
        long durationMs
) {
    public static Builder builder(Instant startTime) {
        return new Builder(startTime);
    }

    public static final class Builder {
        private final Instant startTime;
        private Instant endTime;
        private int jobsChecked;
        private int newBuilds;
        private int failures;
        private int recoveries;
        private int notifications;
        private int errors;

        private Builder(Instant startTime) {
            this.startTime = startTime;
        }

        public Builder jobsChecked(int count) {
            this.jobsChecked = count;
            return this;
        }

        public Builder incrementNewBuilds() {
            this.newBuilds++;
            return this;
        }

        public Builder incrementFailures() {
            this.failures++;
            return this;
        }

        public Builder incrementRecoveries() {
            this.recoveries++;
            return this;
        }

        public Builder incrementNotifications() {
            this.notifications++;
            return this;
        }

        public Builder incrementErrors() {
            this.errors++;
            return this;
        }

        public MonitoringCycleSummary build() {
            this.endTime = Instant.now();
            long durationMs = endTime.toEpochMilli() - startTime.toEpochMilli();
            return new MonitoringCycleSummary(
                    startTime, endTime, jobsChecked, newBuilds,
                    failures, recoveries, notifications, errors, durationMs
            );
        }
    }
}
