package com.cognizant.eop.core.dto;

public record TeamStatusSummary(
        Long teamId,
        String teamName,
        long jobCount,
        long activeFailures,
        double successRatePercent
) {}
