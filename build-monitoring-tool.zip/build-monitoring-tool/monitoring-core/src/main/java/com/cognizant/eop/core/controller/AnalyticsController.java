package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.AnalyticsSummaryResponse;
import com.cognizant.eop.core.dto.AnalyticsTrendsResponse;
import com.cognizant.eop.core.dto.TopFailuresResponse;
import com.cognizant.eop.core.service.AnalyticsService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/analytics")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    public AnalyticsController(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    @GetMapping("/summary")
    public ResponseEntity<AnalyticsSummaryResponse> getSummary(
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) Long groupId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        return ResponseEntity.ok(analyticsService.getSummary(teamId, groupId, from, to));
    }

    @GetMapping("/trends")
    public ResponseEntity<AnalyticsTrendsResponse> getTrends(
            @RequestParam(defaultValue = "30") int days,
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) Long groupId) {
        return ResponseEntity.ok(analyticsService.getTrends(days, teamId, groupId));
    }

    @GetMapping("/top-failures")
    public ResponseEntity<TopFailuresResponse> getTopFailures(
            @RequestParam(defaultValue = "5") int limit,
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) Long groupId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        return ResponseEntity.ok(analyticsService.getTopFailures(limit, teamId, groupId, from, to));
    }
}
