package com.cognizant.eop.core.service;

public class TeamNotFoundException extends RuntimeException {

    public TeamNotFoundException(Long teamId) {
        super("Team not found with id: " + teamId);
    }
}
