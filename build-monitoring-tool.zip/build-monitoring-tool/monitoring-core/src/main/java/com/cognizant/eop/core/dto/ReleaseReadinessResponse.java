package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.ReleaseReadinessCalculator;

public record ReleaseReadinessResponse(
        double score,
        double buildStatusScore,
        double buildStabilityScore,
        long outstandingFailures,
        long blockedBuilds,
        double environmentReadiness,
        double deploymentReadiness
) {
    public static ReleaseReadinessResponse from(ReleaseReadinessCalculator.ReleaseReadinessScore score) {
        return new ReleaseReadinessResponse(
                score.score(),
                score.buildStatusScore(),
                score.buildStabilityScore(),
                score.outstandingFailures(),
                score.blockedBuilds(),
                score.environmentReadiness(),
                score.deploymentReadiness()
        );
    }
}
