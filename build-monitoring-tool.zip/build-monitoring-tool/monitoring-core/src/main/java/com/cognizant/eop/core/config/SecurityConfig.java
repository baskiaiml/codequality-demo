package com.cognizant.eop.core.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.jwt.JwtAuthenticationFilter;
import com.cognizant.eop.security.jwt.JwtTokenService;
import com.cognizant.eop.security.rbac.HttpAuthorizationRules;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfigurationSource;

import java.net.URI;

@Configuration
@EnableMethodSecurity
@ConditionalOnProperty(name = "eop.security.enabled", havingValue = "true", matchIfMissing = true)
public class SecurityConfig {

    private final ObjectMapper objectMapper;

    public SecurityConfig(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Bean
    SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            JwtTokenService jwtTokenService,
            CorsConfigurationSource corsConfigurationSource) throws Exception {
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtTokenService);

        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpAuthorizationRules.PUBLIC_PATHS).permitAll()
                        .requestMatchers(HttpAuthorizationRules.ADMIN_CONFIG).hasRole("ADMINISTRATOR")
                        .requestMatchers(HttpAuthorizationRules.ADMIN_TEAMS).hasRole("ADMINISTRATOR")
                        .requestMatchers(HttpAuthorizationRules.ADMIN_JOBS).hasRole("ADMINISTRATOR")
                        .requestMatchers(HttpAuthorizationRules.ADMIN_SCHEDULER).hasRole("ADMINISTRATOR")
                        .requestMatchers(HttpAuthorizationRules.ADMIN_AUDIT).hasRole("ADMINISTRATOR")
                        .requestMatchers(HttpAuthorizationRules.ADMIN_NOTIFICATION_RULES)
                                .hasAnyRole("ADMINISTRATOR", "MANAGER")
                        .requestMatchers(HttpAuthorizationRules.ANALYTICS)
                                .hasAnyRole("ADMINISTRATOR", "MANAGER", "DEVELOPER", "VIEWER")
                        .requestMatchers(HttpAuthorizationRules.DASHBOARD)
                                .hasAnyRole("ADMINISTRATOR", "MANAGER", "DEVELOPER", "VIEWER")
                        .anyRequest().authenticated()
                )
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint((request, response, authException) ->
                                writeProblem(response, HttpServletResponse.SC_UNAUTHORIZED,
                                        "Unauthorized", "Missing or invalid authentication"))
                        .accessDeniedHandler((request, response, accessDeniedException) ->
                                writeProblem(response, HttpServletResponse.SC_FORBIDDEN,
                                        "Forbidden", "Insufficient permissions"))
                )
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    private void writeProblem(HttpServletResponse response, int status, String title, String detail)
            throws java.io.IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(status), detail);
        problem.setTitle(title);
        problem.setType(URI.create(status == 401
                ? "https://eop.internal/errors/unauthorized"
                : "https://eop.internal/errors/forbidden"));
        response.getWriter().write(objectMapper.writeValueAsString(problem));
    }
}

@Configuration
@ConditionalOnProperty(name = "eop.security.enabled", havingValue = "false")
class DisabledSecurityConfig {

    @Bean
    SecurityFilterChain disabledSecurityFilterChain(HttpSecurity http, CorsConfigurationSource corsConfigurationSource)
            throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource))
                .authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
        return http.build();
    }
}
