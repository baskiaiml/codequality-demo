package com.cognizant.eop.core.dto;

import com.cognizant.eop.analytics.engine.TrendCalculator;

import java.time.LocalDate;
import java.util.List;

public record AnalyticsTrendsResponse(
        LocalDate fromDate,
        LocalDate toDate,
        List<TrendPointResponse> dataPoints
) {
    public static AnalyticsTrendsResponse from(LocalDate from, LocalDate to, List<TrendCalculator.TrendDataPoint> points) {
        return new AnalyticsTrendsResponse(
                from,
                to,
                points.stream().map(TrendPointResponse::from).toList()
        );
    }
}
