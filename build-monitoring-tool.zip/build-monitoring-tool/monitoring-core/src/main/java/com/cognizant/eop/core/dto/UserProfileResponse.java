package com.cognizant.eop.core.dto;

import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.core.entity.AppUserEntity;
import com.cognizant.eop.security.model.AuthenticatedUser;

public record UserProfileResponse(
        String username,
        String displayName,
        String email,
        UserRole role,
        Long teamId
) {
    public static UserProfileResponse from(AppUserEntity entity) {
        return new UserProfileResponse(
                entity.getUsername(),
                entity.getDisplayName(),
                entity.getEmail(),
                entity.getRole(),
                entity.getTeamId()
        );
    }

    public static UserProfileResponse from(AuthenticatedUser user) {
        return new UserProfileResponse(
                user.username(),
                user.displayName(),
                user.email(),
                user.role(),
                user.teamId()
        );
    }
}
