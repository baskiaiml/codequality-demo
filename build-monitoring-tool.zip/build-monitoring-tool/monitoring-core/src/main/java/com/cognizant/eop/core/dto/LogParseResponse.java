package com.cognizant.eop.core.dto;

import com.cognizant.eop.parser.model.LogParseResult;
import com.cognizant.eop.parser.model.PatternMatchResult;

import java.math.BigDecimal;
import java.util.List;

/**
 * REST response DTO for build log parse results.
 */
public record LogParseResponse(
        String category,
        BigDecimal confidenceScore,
        String rootCause,
        String suggestedFix,
        String affectedModule,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String logSnippet,
        String recommendation,
        String severity,
        int matchCount
) {
    public static LogParseResponse from(LogParseResult result) {
        return new LogParseResponse(
                result.primaryCategory().name(),
                result.confidenceScore(),
                result.rootCause(),
                result.suggestedFix(),
                result.affectedModule(),
                result.relevantClasses(),
                result.sqlObjects(),
                result.logSnippet(),
                result.recommendation(),
                result.severity().name(),
                result.allMatches().size()
        );
    }
}
