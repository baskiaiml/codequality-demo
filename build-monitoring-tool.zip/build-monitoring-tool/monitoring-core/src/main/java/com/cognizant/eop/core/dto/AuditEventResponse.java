package com.cognizant.eop.core.dto;

import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.core.entity.AuditEventEntity;

import java.time.Instant;
import java.util.Map;

public record AuditEventResponse(
        Long id,
        AuditEventType eventType,
        String entityType,
        String entityId,
        String actor,
        Map<String, Object> details,
        Instant createdAt
) {
    public static AuditEventResponse from(AuditEventEntity entity) {
        return new AuditEventResponse(
                entity.getId(),
                entity.getEventType(),
                entity.getEntityType(),
                entity.getEntityId(),
                entity.getActor(),
                entity.getDetails(),
                entity.getCreatedAt()
        );
    }
}
