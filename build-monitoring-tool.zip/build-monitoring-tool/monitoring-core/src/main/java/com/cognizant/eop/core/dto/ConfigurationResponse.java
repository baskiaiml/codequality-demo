package com.cognizant.eop.core.dto;

public record ConfigurationResponse(
        Long id,
        String configKey,
        String configValue,
        String description
) {}
