package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.TeamDashboardResponse;
import com.cognizant.eop.core.dto.TeamResponse;
import com.cognizant.eop.core.service.DashboardService;
import com.cognizant.eop.core.service.OrganizationQueryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/teams")
public class TeamController {

    private final OrganizationQueryService organizationQueryService;
    private final DashboardService dashboardService;

    public TeamController(OrganizationQueryService organizationQueryService, DashboardService dashboardService) {
        this.organizationQueryService = organizationQueryService;
        this.dashboardService = dashboardService;
    }

    @GetMapping
    public ResponseEntity<List<TeamResponse>> listTeams(
            @RequestParam(defaultValue = "false") boolean all) {
        return ResponseEntity.ok(all
                ? organizationQueryService.findAllTeams()
                : organizationQueryService.findTeamsWithMonitoredJobs());
    }

    @GetMapping("/{teamId}/dashboard")
    public ResponseEntity<TeamDashboardResponse> getTeamDashboard(@PathVariable Long teamId) {
        return ResponseEntity.ok(dashboardService.getTeamDashboard(teamId));
    }
}
