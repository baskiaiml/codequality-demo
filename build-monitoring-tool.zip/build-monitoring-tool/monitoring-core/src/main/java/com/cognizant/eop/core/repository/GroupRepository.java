package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.GroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface GroupRepository extends JpaRepository<GroupEntity, Long> {

    Optional<GroupEntity> findByName(String name);

    @Query("""
            SELECT DISTINCT g FROM GroupEntity g
            JOIN g.teams t
            JOIN t.jobs j
            WHERE j.enabled = true AND j.pollingEnabled = true
            ORDER BY g.name
            """)
    List<GroupEntity> findWithMonitoredJobs();
}
