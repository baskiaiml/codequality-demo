package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.JobEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface JobRepository extends JpaRepository<JobEntity, Long>, JpaSpecificationExecutor<JobEntity> {

    Optional<JobEntity> findByExternalId(String externalId);

    List<JobEntity> findByEnabledTrueAndPollingEnabledTrue();

    List<JobEntity> findByTeamId(Long teamId);

    long countByEnabledTrueAndPollingEnabledTrue();
}
