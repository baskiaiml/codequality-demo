package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;

/**
 * Result of comparing a provider build against the last known persisted build.
 *
 * @param changeType   the type of change detected
 * @param previousBuild the last known build from the database (null on first poll)
 * @param currentBuild  the build fetched from the provider
 */
public record BuildChangeResult(
        BuildChangeType changeType,
        Build previousBuild,
        Build currentBuild
) {
    public boolean hasChanged() {
        return changeType != BuildChangeType.UNCHANGED;
    }

    public boolean requiresFailureProcessing() {
        return changeType == BuildChangeType.FAILURE
                || (changeType == BuildChangeType.NEW_BUILD && currentBuild != null && currentBuild.isFailed());
    }

    public boolean requiresRecoveryNotification() {
        return changeType == BuildChangeType.RECOVERY;
    }
}
