package com.cognizant.eop.core.config;

import com.cognizant.eop.core.service.BuildNotFoundException;
import com.cognizant.eop.core.service.ConfigurationNotFoundException;
import com.cognizant.eop.core.service.FailureNotFoundException;
import com.cognizant.eop.core.service.GroupNotFoundException;
import com.cognizant.eop.core.service.InvalidCredentialsException;
import com.cognizant.eop.core.service.JobNotFoundException;
import com.cognizant.eop.core.service.ProviderJobNotFoundException;
import com.cognizant.eop.core.service.TeamAlreadyExistsException;
import com.cognizant.eop.core.service.TeamDisabledException;
import com.cognizant.eop.core.service.TeamNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Global exception handler returning RFC 9457 Problem Details responses.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InvalidCredentialsException.class)
    public ProblemDetail handleUnauthorized(InvalidCredentialsException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.UNAUTHORIZED, ex.getMessage());
        problem.setTitle("Unauthorized");
        problem.setType(java.net.URI.create("https://eop.internal/errors/unauthorized"));
        return problem;
    }

    @ExceptionHandler({
            JobNotFoundException.class,
            BuildNotFoundException.class,
            FailureNotFoundException.class,
            TeamNotFoundException.class,
            GroupNotFoundException.class,
            ConfigurationNotFoundException.class,
            ProviderJobNotFoundException.class
    })
    public ProblemDetail handleNotFound(RuntimeException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Resource Not Found");
        problem.setType(java.net.URI.create("https://eop.internal/errors/resource-not-found"));
        return problem;
    }

    @ExceptionHandler(TeamAlreadyExistsException.class)
    public ProblemDetail handleConflict(TeamAlreadyExistsException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problem.setTitle("Conflict");
        problem.setType(java.net.URI.create("https://eop.internal/errors/conflict"));
        return problem;
    }

    @ExceptionHandler(TeamDisabledException.class)
    public ProblemDetail handleBadRequest(TeamDisabledException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Invalid Request");
        problem.setType(java.net.URI.create("https://eop.internal/errors/invalid-request"));
        return problem;
    }
}
