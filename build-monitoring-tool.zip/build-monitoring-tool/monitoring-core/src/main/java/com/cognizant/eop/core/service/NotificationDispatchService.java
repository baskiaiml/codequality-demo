package com.cognizant.eop.core.service;

import com.cognizant.eop.api.notification.NotificationChannel;
import com.cognizant.eop.api.notification.NotificationContext;
import com.cognizant.eop.api.notification.NotificationEventType;
import com.cognizant.eop.api.notification.NotificationMessage;
import com.cognizant.eop.api.notification.NotificationSender;
import com.cognizant.eop.api.notification.NotificationTemplateRenderer;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.entity.NotificationEntity;
import com.cognizant.eop.core.entity.NotificationRuleEntity;
import com.cognizant.eop.core.entity.TeamEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.DeveloperRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.repository.NotificationRepository;
import com.cognizant.eop.core.repository.NotificationRuleRepository;
import com.cognizant.eop.core.scheduler.NotificationCycleTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class NotificationDispatchService {

    private static final Logger log = LoggerFactory.getLogger(NotificationDispatchService.class);
    private static final String DEFAULT_RECIPIENT = "engineering-ops@titan.internal";

    private final NotificationRuleRepository notificationRuleRepository;
    private final NotificationRepository notificationRepository;
    private final JobRepository jobRepository;
    private final BuildRepository buildRepository;
    private final FailureRepository failureRepository;
    private final DeveloperRepository developerRepository;
    private final NotificationTemplateRenderer templateRenderer;
    private final NotificationSender notificationSender;
    private final PlatformConfigurationService platformConfigurationService;
    private final NotificationCycleTracker notificationCycleTracker;

    public NotificationDispatchService(
            NotificationRuleRepository notificationRuleRepository,
            NotificationRepository notificationRepository,
            JobRepository jobRepository,
            BuildRepository buildRepository,
            FailureRepository failureRepository,
            DeveloperRepository developerRepository,
            NotificationTemplateRenderer templateRenderer,
            NotificationSender notificationSender,
            PlatformConfigurationService platformConfigurationService,
            NotificationCycleTracker notificationCycleTracker) {
        this.notificationRuleRepository = notificationRuleRepository;
        this.notificationRepository = notificationRepository;
        this.jobRepository = jobRepository;
        this.buildRepository = buildRepository;
        this.failureRepository = failureRepository;
        this.developerRepository = developerRepository;
        this.templateRenderer = templateRenderer;
        this.notificationSender = notificationSender;
        this.platformConfigurationService = platformConfigurationService;
        this.notificationCycleTracker = notificationCycleTracker;
    }

    @Transactional
    public int dispatchBuildFailure(String buildExternalId, String jobExternalId) {
        return dispatch(buildExternalId, jobExternalId, NotificationEventType.BUILD_FAILURE, 0);
    }

    @Transactional
    public int dispatchRootCauseChanged(String buildExternalId, String jobExternalId) {
        return dispatch(buildExternalId, jobExternalId, NotificationEventType.ROOT_CAUSE_CHANGED, 0);
    }

    @Transactional
    public int dispatchBuildRecovery(String buildExternalId, String jobExternalId, int resolvedFailureCount) {
        return dispatch(buildExternalId, jobExternalId, NotificationEventType.BUILD_RECOVERY, resolvedFailureCount);
    }

    @Transactional(readOnly = true)
    public List<NotificationEntity> findByBuildExternalId(String buildExternalId) {
        return notificationRepository.findByBuild_ExternalIdOrderBySentAtDesc(buildExternalId);
    }

    private int dispatch(
            String buildExternalId,
            String jobExternalId,
            NotificationEventType eventType,
            int resolvedFailureCount) {
        if (!platformConfigurationService.isNotificationEnabled()) {
            log.debug("Notifications disabled — skipping event={} buildExternalId={}", eventType, buildExternalId);
            return 0;
        }

        JobEntity job = jobRepository.findByExternalId(jobExternalId).orElse(null);
        if (job == null) {
            log.warn("Cannot dispatch notification — job not found: {}", jobExternalId);
            return 0;
        }

        BuildEntity build = buildRepository.findByExternalId(buildExternalId).orElse(null);
        if (build == null) {
            log.warn("Cannot dispatch notification — build not found: {}", buildExternalId);
            return 0;
        }

        if (notificationRepository.existsByBuildIdAndNotificationType(build.getId(), eventType.name())) {
            log.debug("Notification already sent — skipping duplicate: buildExternalId={}, event={}",
                    buildExternalId, eventType);
            return 0;
        }

        FailureEntity failure = failureRepository.findByBuildId(build.getId()).orElse(null);
        NotificationContext context = buildContext(job, build, failure, resolvedFailureCount);
        List<NotificationRuleEntity> rules =
                notificationRuleRepository.findByEventTypeAndEnabledTrue(eventType.name());

        if (rules.isEmpty()) {
            log.debug("No enabled notification rules for event={}", eventType);
            return 0;
        }

        String recipient = resolveRecipient(job, failure);
        int sentCount = 0;

        for (NotificationRuleEntity rule : rules) {
            if (!NotificationChannel.EMAIL.name().equalsIgnoreCase(rule.getChannel())) {
                log.debug("Unsupported notification channel skipped: {}", rule.getChannel());
                continue;
            }

            NotificationTemplateRenderer.RenderedNotification rendered =
                    templateRenderer.render(rule.getTemplateName(), context);

            NotificationMessage message = new NotificationMessage(
                    NotificationChannel.EMAIL,
                    recipient,
                    rendered.subject(),
                    rendered.body(),
                    eventType
            );

            try {
                notificationSender.send(message);
                persistNotification(build, failure, message);
                sentCount++;
            } catch (Exception ex) {
                log.error("Failed to send notification: event={}, buildExternalId={}, recipient={}",
                        eventType, buildExternalId, recipient, ex);
            }
        }

        notificationCycleTracker.add(sentCount);
        return sentCount;
    }

    private NotificationContext buildContext(
            JobEntity job,
            BuildEntity build,
            FailureEntity failure,
            int resolvedFailureCount) {
        TeamEntity team = job.getTeam();
        return new NotificationContext(
                job.getName(),
                job.getExternalId(),
                build.getExternalId(),
                build.getBuildNumber(),
                build.getBuildUrl(),
                build.getBranch(),
                failure != null ? failure.getCategory().name() : null,
                failure != null ? failure.getRootCause() : null,
                failure != null ? failure.getSuggestedFix() : null,
                failure != null ? failure.getPossibleOwner() : null,
                failure != null ? failure.getLogSnippet() : null,
                team != null ? team.getName() : null,
                team != null ? team.getEmail() : null,
                resolvedFailureCount
        );
    }

    private String resolveRecipient(JobEntity job, FailureEntity failure) {
        if (failure != null && failure.getPossibleOwner() != null && !failure.getPossibleOwner().isBlank()) {
            var developer = developerRepository.findByUsername(failure.getPossibleOwner());
            if (developer.isPresent()) {
                return developer.get().getEmail();
            }
        }

        if (job.getTeam() != null && job.getTeam().getEmail() != null && !job.getTeam().getEmail().isBlank()) {
            return job.getTeam().getEmail();
        }

        return DEFAULT_RECIPIENT;
    }

    private void persistNotification(BuildEntity build, FailureEntity failure, NotificationMessage message) {
        NotificationEntity entity = new NotificationEntity();
        entity.setBuild(build);
        entity.setFailure(failure);
        entity.setChannel(message.channel().name());
        entity.setRecipient(message.recipient());
        entity.setSubject(message.subject());
        entity.setBody(message.body());
        entity.setNotificationType(message.eventType().name());
        entity.setSentAt(Instant.now());
        entity.setStatus("SENT");
        notificationRepository.save(entity);
    }
}
