package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.audit.AuditEventRequest;
import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.api.audit.AuditRecorder;
import com.cognizant.eop.audit.AuditDetailsBuilder;
import com.cognizant.eop.core.dto.CreateTeamRequest;
import com.cognizant.eop.core.dto.TeamResponse;
import com.cognizant.eop.core.service.OrganizationAdminService;
import com.cognizant.eop.security.auth.SecurityContextAccessor;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/teams")
public class TeamAdminController {

    private final OrganizationAdminService organizationAdminService;
    private final AuditRecorder auditRecorder;

    public TeamAdminController(OrganizationAdminService organizationAdminService, AuditRecorder auditRecorder) {
        this.organizationAdminService = organizationAdminService;
        this.auditRecorder = auditRecorder;
    }

    @PostMapping
    public ResponseEntity<TeamResponse> createTeam(@Valid @RequestBody CreateTeamRequest request) {
        TeamResponse team = organizationAdminService.createTeam(request);
        auditRecorder.record(new AuditEventRequest(
                AuditEventType.TEAM_CREATED,
                "team",
                String.valueOf(team.id()),
                SecurityContextAccessor.currentUsernameOrSystem(),
                AuditDetailsBuilder.create()
                        .put("teamName", team.name())
                        .put("groupId", team.groupId())
                        .build()
        ));
        return ResponseEntity.status(HttpStatus.CREATED).body(team);
    }
}
