package com.cognizant.eop.core.config;

import com.cognizant.eop.security.config.SecurityProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableConfigurationProperties(EopSecurityProperties.class)
public class SecurityBeansConfig {

    @Bean
    SecurityProperties securityProperties(EopSecurityProperties properties) {
        return new SecurityProperties(
                properties.enabled(),
                properties.jwtSecret(),
                properties.jwtExpirationMs()
        );
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}

@ConfigurationProperties(prefix = "eop.security")
record EopSecurityProperties(
        boolean enabled,
        String jwtSecret,
        long jwtExpirationMs
) {
    EopSecurityProperties {
        if (jwtExpirationMs <= 0) {
            jwtExpirationMs = 86_400_000L;
        }
        if (jwtSecret == null || jwtSecret.isBlank()) {
            jwtSecret = "test-secret-key-at-least-32-characters-long";
        }
    }
}
