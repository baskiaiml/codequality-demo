package com.cognizant.eop.core.service;

public class TeamDisabledException extends RuntimeException {

    public TeamDisabledException(Long teamId) {
        super("Team is disabled and cannot be assigned jobs: " + teamId);
    }
}
