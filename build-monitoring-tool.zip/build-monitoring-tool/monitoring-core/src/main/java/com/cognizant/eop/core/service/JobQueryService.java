package com.cognizant.eop.core.service;

import com.cognizant.eop.core.dto.JobSummaryResponse;
import com.cognizant.eop.core.dto.LatestBuildSummary;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.repository.spec.EntitySpecs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class JobQueryService {

    private final JobRepository jobRepository;
    private final BuildRepository buildRepository;

    public JobQueryService(JobRepository jobRepository, BuildRepository buildRepository) {
        this.jobRepository = jobRepository;
        this.buildRepository = buildRepository;
    }

    @Transactional(readOnly = true)
    public PageResponse<JobSummaryResponse> findJobs(
            Pageable pageable,
            Long teamId,
            Long groupId,
            Boolean enabled,
            Boolean pollingEnabled) {
        Specification<JobEntity> spec = Specification.allOf(
                EntitySpecs.jobHasTeamId(teamId),
                EntitySpecs.jobHasGroupId(groupId),
                EntitySpecs.jobIsEnabled(enabled),
                EntitySpecs.jobIsPollingEnabled(pollingEnabled)
        );

        Page<JobSummaryResponse> page = jobRepository.findAll(spec, pageable)
                .map(job -> JobSummaryResponse.from(job, resolveLatestBuild(job)));
        return PageResponse.from(page);
    }

    @Transactional(readOnly = true)
    public JobSummaryResponse findByExternalId(String externalId) {
        JobEntity job = jobRepository.findByExternalId(externalId)
                .orElseThrow(() -> new JobNotFoundException(externalId));
        return JobSummaryResponse.from(job, resolveLatestBuild(job));
    }

    private LatestBuildSummary resolveLatestBuild(JobEntity job) {
        return buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId())
                .map(this::toLatestBuildSummary)
                .orElse(null);
    }

    private LatestBuildSummary toLatestBuildSummary(BuildEntity build) {
        return new LatestBuildSummary(
                build.getExternalId(),
                build.getBuildNumber(),
                build.getStatus().name(),
                build.getStartedAt(),
                build.getDurationMs()
        );
    }
}
