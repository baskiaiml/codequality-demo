package com.cognizant.eop.core.dto;

import com.cognizant.eop.api.security.UserRole;
import jakarta.validation.constraints.NotBlank;

public record LoginRequest(
        @NotBlank String username,
        @NotBlank String password
) {
}
