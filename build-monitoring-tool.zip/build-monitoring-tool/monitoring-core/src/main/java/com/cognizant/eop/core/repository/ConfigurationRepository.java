package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.ConfigurationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConfigurationRepository extends JpaRepository<ConfigurationEntity, Long> {

    Optional<ConfigurationEntity> findByConfigKey(String configKey);
}
