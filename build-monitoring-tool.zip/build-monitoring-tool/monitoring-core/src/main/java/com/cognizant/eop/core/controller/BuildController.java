package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.core.dto.BuildDetailResponse;
import com.cognizant.eop.core.dto.BuildLogResponse;
import com.cognizant.eop.core.dto.BuildSummaryResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.service.BuildQueryService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/v1/builds")
public class BuildController {

    private final BuildQueryService buildQueryService;

    public BuildController(BuildQueryService buildQueryService) {
        this.buildQueryService = buildQueryService;
    }

    @GetMapping("/running")
    public ResponseEntity<List<BuildSummaryResponse>> listRunningBuilds() {
        return ResponseEntity.ok(buildQueryService.findRunningBuilds());
    }

    @GetMapping
    public ResponseEntity<PageResponse<BuildSummaryResponse>> listBuilds(
            @PageableDefault(size = 20, sort = "startedAt", direction = Sort.Direction.DESC) Pageable pageable,
            @RequestParam(required = false) BuildStatus status,
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        return ResponseEntity.ok(buildQueryService.findBuilds(pageable, status, teamId, from, to));
    }

    @GetMapping("/{buildId}")
    public ResponseEntity<BuildDetailResponse> getBuild(@PathVariable String buildId) {
        return ResponseEntity.ok(buildQueryService.findByExternalId(buildId));
    }

    @GetMapping("/{buildId}/log")
    public ResponseEntity<BuildLogResponse> getBuildLog(@PathVariable String buildId) {
        return ResponseEntity.ok(buildQueryService.getBuildLog(buildId));
    }
}
