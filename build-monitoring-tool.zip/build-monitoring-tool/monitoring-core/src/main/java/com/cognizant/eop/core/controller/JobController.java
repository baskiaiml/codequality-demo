package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.JobSummaryResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.service.BuildChangeResult;
import com.cognizant.eop.core.service.JobBuildProcessingService;
import com.cognizant.eop.core.service.JobQueryService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/jobs")
public class JobController {

    private final JobQueryService jobQueryService;
    private final JobBuildProcessingService jobBuildProcessingService;

    public JobController(JobQueryService jobQueryService, JobBuildProcessingService jobBuildProcessingService) {
        this.jobQueryService = jobQueryService;
        this.jobBuildProcessingService = jobBuildProcessingService;
    }

    @GetMapping
    public ResponseEntity<PageResponse<JobSummaryResponse>> listJobs(
            @PageableDefault(size = 20, sort = "name") Pageable pageable,
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) Long groupId,
            @RequestParam(required = false) Boolean enabled,
            @RequestParam(required = false) Boolean pollingEnabled) {
        return ResponseEntity.ok(jobQueryService.findJobs(pageable, teamId, groupId, enabled, pollingEnabled));
    }

    @GetMapping("/{externalId}")
    public ResponseEntity<JobSummaryResponse> getJob(@PathVariable String externalId) {
        return ResponseEntity.ok(jobQueryService.findByExternalId(externalId));
    }

    @PostMapping("/{externalId}/process-builds")
    public ResponseEntity<List<BuildChangeResponse>> processBuilds(@PathVariable String externalId) {
        return ResponseEntity.ok(jobBuildProcessingService.processBuilds(externalId).stream()
                .map(BuildChangeResponse::from)
                .toList());
    }

    public record BuildChangeResponse(
            String changeType,
            int buildNumber,
            String status,
            boolean requiresFailureProcessing,
            boolean requiresRecoveryNotification
    ) {
        static BuildChangeResponse from(BuildChangeResult result) {
            return new BuildChangeResponse(
                    result.changeType().name(),
                    result.currentBuild().buildNumber(),
                    result.currentBuild().status().name(),
                    result.requiresFailureProcessing(),
                    result.requiresRecoveryNotification()
            );
        }
    }
}
