package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.BuildCommitEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BuildCommitRepository extends JpaRepository<BuildCommitEntity, Long> {

    @Query("SELECT c FROM BuildCommitEntity c WHERE c.build.id = :buildId")
    List<BuildCommitEntity> findByBuildId(@Param("buildId") Long buildId);

    @Modifying
    @Query("DELETE FROM BuildCommitEntity c WHERE c.build.id = :buildId")
    void deleteByBuildId(@Param("buildId") Long buildId);
}
