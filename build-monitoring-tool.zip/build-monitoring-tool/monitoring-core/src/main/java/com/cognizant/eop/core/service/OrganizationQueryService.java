package com.cognizant.eop.core.service;

import com.cognizant.eop.core.dto.GroupResponse;
import com.cognizant.eop.core.dto.TeamResponse;
import com.cognizant.eop.core.entity.GroupEntity;
import com.cognizant.eop.core.entity.TeamEntity;
import com.cognizant.eop.core.repository.GroupRepository;
import com.cognizant.eop.core.repository.JobRepository;
import com.cognizant.eop.core.repository.TeamRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OrganizationQueryService {

    private final GroupRepository groupRepository;
    private final TeamRepository teamRepository;
    private final JobRepository jobRepository;

    public OrganizationQueryService(
            GroupRepository groupRepository,
            TeamRepository teamRepository,
            JobRepository jobRepository) {
        this.groupRepository = groupRepository;
        this.teamRepository = teamRepository;
        this.jobRepository = jobRepository;
    }

    @Transactional(readOnly = true)
    public List<GroupResponse> findAllGroups() {
        return groupRepository.findAll().stream()
                .map(this::toGroupResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<GroupResponse> findGroupsWithMonitoredJobs() {
        return groupRepository.findWithMonitoredJobs().stream()
                .map(this::toGroupResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TeamResponse> findAllTeams() {
        return teamRepository.findAll().stream()
                .map(this::toTeamResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TeamResponse> findTeamsWithMonitoredJobs() {
        return teamRepository.findWithMonitoredJobs().stream()
                .map(this::toTeamResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public GroupEntity requireGroup(Long groupId) {
        return groupRepository.findById(groupId)
                .orElseThrow(() -> new GroupNotFoundException(groupId));
    }

    @Transactional(readOnly = true)
    public TeamEntity requireTeam(Long teamId) {
        return teamRepository.findById(teamId)
                .orElseThrow(() -> new TeamNotFoundException(teamId));
    }

    private GroupResponse toGroupResponse(GroupEntity group) {
        int teamCount = teamRepository.findByGroupId(group.getId()).size();
        return GroupResponse.from(group, teamCount);
    }

    private TeamResponse toTeamResponse(TeamEntity team) {
        int jobCount = (int) jobRepository.findByTeamId(team.getId()).stream()
                .filter(MonitoredJobRules::isMonitored)
                .count();
        return TeamResponse.from(team, jobCount);
    }
}
