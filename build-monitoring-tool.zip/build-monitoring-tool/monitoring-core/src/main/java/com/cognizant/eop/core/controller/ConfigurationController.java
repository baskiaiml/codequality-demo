package com.cognizant.eop.core.controller;

import com.cognizant.eop.core.dto.ConfigurationResponse;
import com.cognizant.eop.core.dto.ConfigurationUpdateRequest;
import com.cognizant.eop.core.service.ConfigurationAdminService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/config")
public class ConfigurationController {

    private final ConfigurationAdminService configurationAdminService;

    public ConfigurationController(ConfigurationAdminService configurationAdminService) {
        this.configurationAdminService = configurationAdminService;
    }

    @GetMapping
    public ResponseEntity<List<ConfigurationResponse>> listConfiguration() {
        return ResponseEntity.ok(configurationAdminService.findAll());
    }

    @PutMapping("/{configKey}")
    public ResponseEntity<ConfigurationResponse> updateConfiguration(
            @PathVariable String configKey,
            @Valid @RequestBody ConfigurationUpdateRequest request) {
        return ResponseEntity.ok(configurationAdminService.update(configKey, request));
    }
}
