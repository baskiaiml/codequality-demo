package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.TeamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface TeamRepository extends JpaRepository<TeamEntity, Long> {

    Optional<TeamEntity> findByName(String name);

    List<TeamEntity> findByEnabledTrue();

    List<TeamEntity> findByGroupId(Long groupId);

    @Query("""
            SELECT DISTINCT t FROM TeamEntity t
            JOIN t.jobs j
            WHERE j.enabled = true AND j.pollingEnabled = true
            ORDER BY t.name
            """)
    List<TeamEntity> findWithMonitoredJobs();
}
