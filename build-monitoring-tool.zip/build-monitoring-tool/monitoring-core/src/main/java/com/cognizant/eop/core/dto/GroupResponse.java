package com.cognizant.eop.core.dto;

import com.cognizant.eop.core.entity.GroupEntity;

public record GroupResponse(
        Long id,
        String name,
        String description,
        int teamCount
) {
    public static GroupResponse from(GroupEntity entity, int teamCount) {
        return new GroupResponse(
                entity.getId(),
                entity.getName(),
                entity.getDescription(),
                teamCount
        );
    }
}
