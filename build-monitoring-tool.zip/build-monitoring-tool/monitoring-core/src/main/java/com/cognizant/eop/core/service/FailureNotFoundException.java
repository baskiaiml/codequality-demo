package com.cognizant.eop.core.service;

public class FailureNotFoundException extends RuntimeException {

    public FailureNotFoundException(Long failureId) {
        super("Failure not found with id: " + failureId);
    }
}
