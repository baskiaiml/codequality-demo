package com.cognizant.eop.core.repository;

import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.core.entity.BuildEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface BuildRepository extends JpaRepository<BuildEntity, Long>, JpaSpecificationExecutor<BuildEntity> {

    Optional<BuildEntity> findByExternalId(String externalId);

    Optional<BuildEntity> findTopByJobIdOrderByBuildNumberDesc(Long jobId);

    List<BuildEntity> findByJobIdOrderByBuildNumberDesc(Long jobId);

    List<BuildEntity> findByStatus(BuildStatus status);
}
