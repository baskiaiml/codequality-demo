package com.cognizant.eop.core.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(name = "build_commit")
@Getter
@Setter
@NoArgsConstructor
public class BuildCommitEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "build_id", nullable = false)
    private BuildEntity build;

    @Column(name = "commit_hash", nullable = false, length = 64)
    private String commitHash;

    @Column(length = 255)
    private String author;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Column(name = "timestamp")
    private Instant timestamp;
}
