package com.cognizant.eop.core.service;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildStatus;
import org.springframework.stereotype.Component;

/**
 * Detects changes between the last known persisted build and a build fetched from the provider.
 * Handles running, cancelled, queued, successful, failed builds, and recoveries.
 */
@Component
public class BuildChangeDetector {

    /**
     * Compares the current provider build against the last known build for a job.
     *
     * @param lastKnown the most recent build stored in the database (null on first poll)
     * @param current   the latest build from the provider (null if no builds exist)
     * @return structured change result describing what changed
     */
    public BuildChangeResult detect(Build lastKnown, Build current) {
        if (current == null) {
            return new BuildChangeResult(BuildChangeType.UNCHANGED, lastKnown, null);
        }

        if (lastKnown == null) {
            return resultForNewBuild(null, current);
        }

        if (current.id().equals(lastKnown.id())) {
            return detectSameBuildChange(lastKnown, current);
        }

        if (current.buildNumber() > lastKnown.buildNumber()) {
            return resultForNewBuild(lastKnown, current);
        }

        return new BuildChangeResult(BuildChangeType.UNCHANGED, lastKnown, current);
    }

    private BuildChangeResult detectSameBuildChange(Build lastKnown, Build current) {
        if (lastKnown.status() == current.status()) {
            return new BuildChangeResult(BuildChangeType.UNCHANGED, lastKnown, current);
        }

        BuildChangeType changeType = resolveStatusChangeType(lastKnown, current);
        return new BuildChangeResult(changeType, lastKnown, current);
    }

    private BuildChangeResult resultForNewBuild(Build lastKnown, Build current) {
        if (lastKnown != null && lastKnown.isFailed() && current.status() == BuildStatus.SUCCESS) {
            return new BuildChangeResult(BuildChangeType.RECOVERY, lastKnown, current);
        }

        if (current.isFailed()) {
            return new BuildChangeResult(BuildChangeType.FAILURE, lastKnown, current);
        }

        return new BuildChangeResult(BuildChangeType.NEW_BUILD, lastKnown, current);
    }

    private BuildChangeType resolveStatusChangeType(Build lastKnown, Build current) {
        if (current.isFailed()) {
            return BuildChangeType.FAILURE;
        }

        if (lastKnown.isFailed() && current.status() == BuildStatus.SUCCESS) {
            return BuildChangeType.RECOVERY;
        }

        return BuildChangeType.STATUS_CHANGED;
    }
}
