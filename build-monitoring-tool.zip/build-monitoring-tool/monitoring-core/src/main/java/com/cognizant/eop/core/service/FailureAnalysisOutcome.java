package com.cognizant.eop.core.service;

/**
 * Outcome of analyzing and persisting a build failure.
 */
public enum FailureAnalysisOutcome {
    CREATED,
    UNCHANGED,
    UPDATED
}
