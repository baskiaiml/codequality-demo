package com.cognizant.eop.core.dto;

import com.cognizant.eop.api.security.UserRole;

public record LoginResponse(
        String token,
        long expiresInMs,
        UserProfileResponse user
) {
}
