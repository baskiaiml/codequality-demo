package com.cognizant.eop.core.repository;

import com.cognizant.eop.api.audit.AuditEventType;
import com.cognizant.eop.core.entity.AuditEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AuditEventRepository extends JpaRepository<AuditEventEntity, Long>, JpaSpecificationExecutor<AuditEventEntity> {

    long countByEventType(AuditEventType eventType);
}
