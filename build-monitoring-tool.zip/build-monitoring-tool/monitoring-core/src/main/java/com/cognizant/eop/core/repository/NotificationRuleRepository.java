package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.NotificationRuleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRuleRepository extends JpaRepository<NotificationRuleEntity, Long> {

    List<NotificationRuleEntity> findByEventTypeAndEnabledTrue(String eventType);
}
