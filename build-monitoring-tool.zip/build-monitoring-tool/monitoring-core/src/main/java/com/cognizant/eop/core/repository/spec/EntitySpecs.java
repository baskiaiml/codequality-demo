package com.cognizant.eop.core.repository.spec;

import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.core.entity.AuditEventEntity;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import org.springframework.data.jpa.domain.Specification;

import java.time.Instant;

public final class EntitySpecs {

    private EntitySpecs() {
    }

    public static Specification<JobEntity> jobHasTeamId(Long teamId) {
        return (root, query, cb) -> teamId == null ? cb.conjunction() : cb.equal(root.get("team").get("id"), teamId);
    }

    public static Specification<JobEntity> jobHasGroupId(Long groupId) {
        return (root, query, cb) -> groupId == null ? cb.conjunction() : cb.equal(root.get("team").get("group").get("id"), groupId);
    }

    public static Specification<JobEntity> jobIsEnabled(Boolean enabled) {
        return (root, query, cb) -> enabled == null ? cb.conjunction() : cb.equal(root.get("enabled"), enabled);
    }

    public static Specification<JobEntity> jobIsPollingEnabled(Boolean pollingEnabled) {
        return (root, query, cb) -> pollingEnabled == null ? cb.conjunction() : cb.equal(root.get("pollingEnabled"), pollingEnabled);
    }

    public static Specification<BuildEntity> buildHasStatus(BuildStatus status) {
        return (root, query, cb) -> status == null ? cb.conjunction() : cb.equal(root.get("status"), status);
    }

    public static Specification<BuildEntity> buildHasTeamId(Long teamId) {
        return (root, query, cb) -> teamId == null ? cb.conjunction() : cb.equal(root.get("job").get("team").get("id"), teamId);
    }

    public static Specification<BuildEntity> buildStartedAfter(Instant from) {
        return (root, query, cb) -> from == null ? cb.conjunction() : cb.greaterThanOrEqualTo(root.get("startedAt"), from);
    }

    public static Specification<BuildEntity> buildStartedBefore(Instant to) {
        return (root, query, cb) -> to == null ? cb.conjunction() : cb.lessThanOrEqualTo(root.get("startedAt"), to);
    }

    public static Specification<FailureEntity> failureHasCategory(FailureCategory category) {
        return (root, query, cb) -> category == null ? cb.conjunction() : cb.equal(root.get("category"), category);
    }

    public static Specification<FailureEntity> failureIsResolved(Boolean resolved) {
        return (root, query, cb) -> resolved == null ? cb.conjunction() : cb.equal(root.get("resolved"), resolved);
    }

    public static Specification<FailureEntity> failureHasTeamId(Long teamId) {
        return (root, query, cb) -> teamId == null ? cb.conjunction()
                : cb.equal(root.get("build").get("job").get("team").get("id"), teamId);
    }

    public static Specification<FailureEntity> failureCreatedAfter(Instant from) {
        return (root, query, cb) -> from == null ? cb.conjunction() : cb.greaterThanOrEqualTo(root.get("createdAt"), from);
    }

    public static Specification<FailureEntity> failureCreatedBefore(Instant to) {
        return (root, query, cb) -> to == null ? cb.conjunction() : cb.lessThanOrEqualTo(root.get("createdAt"), to);
    }

    public static Specification<FailureEntity> failureForMonitoredJobs() {
        return (root, query, cb) -> cb.and(
                cb.isTrue(root.get("build").get("job").get("enabled")),
                cb.isTrue(root.get("build").get("job").get("pollingEnabled"))
        );
    }

    public static Specification<AuditEventEntity> auditEvents(String eventType, Instant from, Instant to) {
        return Specification.where(auditHasEventType(eventType))
                .and(auditCreatedAfter(from))
                .and(auditCreatedBefore(to));
    }

    public static Specification<AuditEventEntity> auditHasEventType(String eventType) {
        return (root, query, cb) -> eventType == null || eventType.isBlank()
                ? cb.conjunction()
                : cb.equal(root.get("eventType"), com.cognizant.eop.api.audit.AuditEventType.valueOf(eventType));
    }

    public static Specification<AuditEventEntity> auditCreatedAfter(Instant from) {
        return (root, query, cb) -> from == null ? cb.conjunction() : cb.greaterThanOrEqualTo(root.get("createdAt"), from);
    }

    public static Specification<AuditEventEntity> auditCreatedBefore(Instant to) {
        return (root, query, cb) -> to == null ? cb.conjunction() : cb.lessThanOrEqualTo(root.get("createdAt"), to);
    }
}
