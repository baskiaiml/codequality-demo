package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.service.BuildChangeResult;
import com.cognizant.eop.core.service.BuildChangeType;
import com.cognizant.eop.core.service.BuildPersistenceService;
import com.cognizant.eop.core.service.JobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Orchestrates a full build monitoring cycle across all polling-enabled jobs.
 */
@Service
public class BuildMonitoringOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(BuildMonitoringOrchestrator.class);

    private final JobService jobService;
    private final BuildPersistenceService buildPersistenceService;
    private final BuildChangePostProcessor buildChangePostProcessor;
    private final NotificationCycleTracker notificationCycleTracker;
    private final AtomicReference<MonitoringCycleSummary> lastCycleSummary = new AtomicReference<>();

    public BuildMonitoringOrchestrator(
            JobService jobService,
            BuildPersistenceService buildPersistenceService,
            BuildChangePostProcessor buildChangePostProcessor,
            NotificationCycleTracker notificationCycleTracker) {
        this.jobService = jobService;
        this.buildPersistenceService = buildPersistenceService;
        this.buildChangePostProcessor = buildChangePostProcessor;
        this.notificationCycleTracker = notificationCycleTracker;
    }

    /**
     * Executes one complete monitoring cycle for all polling-enabled jobs.
     */
    public MonitoringCycleSummary executeMonitoringCycle() {
        Instant startTime = Instant.now();
        log.info("Scheduler cycle started at {}", startTime);

        notificationCycleTracker.reset();
        MonitoringCycleSummary.Builder summary = MonitoringCycleSummary.builder(startTime);
        List<JobEntity> jobs = jobService.findAllPollingEnabled();
        summary.jobsChecked(jobs.size());

        for (JobEntity job : jobs) {
            try {
                processJob(job, summary);
            } catch (Exception ex) {
                summary.incrementErrors();
                log.error("Failed to process job during monitoring cycle: jobExternalId={}",
                        job.getExternalId(), ex);
            }
        }

        MonitoringCycleSummary result = summary.build();
        MonitoringCycleSummary withNotifications = new MonitoringCycleSummary(
                result.startTime(),
                result.endTime(),
                result.jobsChecked(),
                result.newBuilds(),
                result.failures(),
                result.recoveries(),
                notificationCycleTracker.getCount(),
                result.errors(),
                result.durationMs()
        );
        lastCycleSummary.set(withNotifications);

        log.info(
                "Scheduler cycle completed: jobsChecked={}, newBuilds={}, failures={}, recoveries={}, "
                        + "notifications={}, errors={}, durationMs={}",
                result.jobsChecked(),
                result.newBuilds(),
                result.failures(),
                result.recoveries(),
                withNotifications.notifications(),
                result.errors(),
                result.durationMs()
        );

        return withNotifications;
    }

    /**
     * Returns the summary of the most recently completed monitoring cycle.
     */
    public MonitoringCycleSummary getLastCycleSummary() {
        return lastCycleSummary.get();
    }

    private void processJob(JobEntity job, MonitoringCycleSummary.Builder summary) {
        List<BuildChangeResult> changes = buildPersistenceService.processJob(job.getExternalId());

        for (BuildChangeResult change : changes) {
            if (!change.hasChanged()) {
                continue;
            }

            recordChangeMetrics(change, summary);
            dispatchPostProcessing(change, job.getExternalId());
        }
    }

    private void recordChangeMetrics(BuildChangeResult change, MonitoringCycleSummary.Builder summary) {
        switch (change.changeType()) {
            case NEW_BUILD, STATUS_CHANGED -> summary.incrementNewBuilds();
            case FAILURE -> {
                summary.incrementNewBuilds();
                summary.incrementFailures();
            }
            case RECOVERY -> {
                summary.incrementNewBuilds();
                summary.incrementRecoveries();
            }
            default -> { /* UNCHANGED handled by caller */ }
        }
    }

    private void dispatchPostProcessing(BuildChangeResult change, String jobExternalId) {
        buildChangePostProcessor.process(change, jobExternalId);
    }
}
