package com.cognizant.eop.core.repository;

import com.cognizant.eop.core.entity.NotificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<NotificationEntity, Long> {

    boolean existsByBuildIdAndNotificationType(Long buildId, String notificationType);

    List<NotificationEntity> findByBuild_ExternalIdOrderBySentAtDesc(String buildExternalId);
}
