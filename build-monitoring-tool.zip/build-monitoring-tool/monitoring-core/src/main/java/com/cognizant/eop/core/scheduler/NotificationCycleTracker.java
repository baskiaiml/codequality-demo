package com.cognizant.eop.core.scheduler;

import org.springframework.stereotype.Component;

/**
 * Tracks notifications sent during the current monitoring cycle.
 */
@Component
public class NotificationCycleTracker {

    private int count;

    public void reset() {
        count = 0;
    }

    public void add(int sentCount) {
        if (sentCount > 0) {
            count += sentCount;
        }
    }

    public int getCount() {
        return count;
    }
}
