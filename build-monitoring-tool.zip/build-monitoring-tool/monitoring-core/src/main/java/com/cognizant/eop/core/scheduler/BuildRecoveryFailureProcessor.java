package com.cognizant.eop.core.scheduler;

import com.cognizant.eop.core.service.BuildChangeResult;
import com.cognizant.eop.core.service.FailureAnalysisService;
import com.cognizant.eop.core.service.NotificationDispatchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Marks unresolved failures as resolved and sends recovery notifications.
 */
@Component
public class BuildRecoveryFailureProcessor implements BuildRecoveryProcessor {

    private static final Logger log = LoggerFactory.getLogger(BuildRecoveryFailureProcessor.class);

    private final FailureAnalysisService failureAnalysisService;
    private final NotificationDispatchService notificationDispatchService;

    public BuildRecoveryFailureProcessor(
            FailureAnalysisService failureAnalysisService,
            NotificationDispatchService notificationDispatchService) {
        this.failureAnalysisService = failureAnalysisService;
        this.notificationDispatchService = notificationDispatchService;
    }

    @Override
    public void processRecovery(BuildChangeResult change, String jobExternalId) {
        if (change.currentBuild() == null) {
            return;
        }

        int resolvedCount = failureAnalysisService.markJobFailuresResolved(jobExternalId);
        log.info("Build recovery processed: jobExternalId={}, buildNumber={}, failuresResolved={}",
                jobExternalId,
                change.currentBuild().buildNumber(),
                resolvedCount);

        if (resolvedCount > 0) {
            notificationDispatchService.dispatchBuildRecovery(
                    change.currentBuild().id(),
                    jobExternalId,
                    resolvedCount);
        }
    }
}
