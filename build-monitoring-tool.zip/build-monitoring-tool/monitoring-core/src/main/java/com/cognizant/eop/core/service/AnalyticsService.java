package com.cognizant.eop.core.service;

import com.cognizant.eop.analytics.engine.EngineeringMetricsCalculator;
import com.cognizant.eop.analytics.engine.ReleaseReadinessCalculator;
import com.cognizant.eop.analytics.engine.TopFailuresAggregator;
import com.cognizant.eop.analytics.engine.TrendCalculator;
import com.cognizant.eop.analytics.model.BuildMetricSnapshot;
import com.cognizant.eop.analytics.model.FailureMetricSnapshot;
import com.cognizant.eop.analytics.model.JobLatestStatusSnapshot;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.core.dto.AnalyticsSummaryResponse;
import com.cognizant.eop.core.dto.AnalyticsTrendsResponse;
import com.cognizant.eop.core.dto.ReleaseReadinessResponse;
import com.cognizant.eop.core.dto.TopFailuresResponse;
import com.cognizant.eop.core.entity.BuildEntity;
import com.cognizant.eop.core.entity.FailureEntity;
import com.cognizant.eop.core.entity.JobEntity;
import com.cognizant.eop.core.repository.BuildRepository;
import com.cognizant.eop.core.repository.FailureRepository;
import com.cognizant.eop.core.repository.JobRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;

@Service
public class AnalyticsService {

    private final BuildRepository buildRepository;
    private final FailureRepository failureRepository;
    private final JobRepository jobRepository;

    public AnalyticsService(
            BuildRepository buildRepository,
            FailureRepository failureRepository,
            JobRepository jobRepository) {
        this.buildRepository = buildRepository;
        this.failureRepository = failureRepository;
        this.jobRepository = jobRepository;
    }

    @Transactional(readOnly = true)
    public AnalyticsSummaryResponse getSummary(Long teamId, Long groupId, Instant from, Instant to) {
        List<BuildMetricSnapshot> builds = loadBuildSnapshots(teamId, groupId, from, to);
        List<FailureMetricSnapshot> failures = loadFailureSnapshots(teamId, groupId, from, to);
        return AnalyticsSummaryResponse.from(EngineeringMetricsCalculator.compute(builds, failures));
    }

    @Transactional(readOnly = true)
    public AnalyticsTrendsResponse getTrends(int days, Long teamId, Long groupId) {
        LocalDate to = LocalDate.now(ZoneOffset.UTC);
        LocalDate from = to.minusDays(Math.max(days, 1) - 1L);
        Instant fromInstant = from.atStartOfDay().toInstant(ZoneOffset.UTC);

        List<BuildMetricSnapshot> builds = loadBuildSnapshots(teamId, groupId, fromInstant, null);
        List<TrendCalculator.TrendDataPoint> points =
                TrendCalculator.computeDailyTrends(builds, from, to);
        return AnalyticsTrendsResponse.from(from, to, points);
    }

    @Transactional(readOnly = true)
    public TopFailuresResponse getTopFailures(int limit, Long teamId, Long groupId, Instant from, Instant to) {
        List<FailureMetricSnapshot> failures = loadFailureSnapshots(teamId, groupId, from, to);
        return TopFailuresResponse.from(TopFailuresAggregator.aggregate(failures, Math.max(limit, 1)));
    }

    @Transactional(readOnly = true)
    public ReleaseReadinessResponse getReleaseReadiness(Long teamId, Long groupId) {
        List<JobLatestStatusSnapshot> jobs = loadJobLatestStatuses(teamId, groupId);
        List<BuildMetricSnapshot> builds = loadBuildSnapshots(teamId, groupId, null, null);
        List<FailureMetricSnapshot> failures = loadFailureSnapshots(teamId, groupId, null, null);

        EngineeringMetricsCalculator.EngineeringMetrics metrics =
                EngineeringMetricsCalculator.compute(builds, failures);

        long outstandingFailures = failures.stream().filter(f -> !f.resolved()).count();
        ReleaseReadinessCalculator.ReleaseReadinessScore score = ReleaseReadinessCalculator.compute(
                jobs,
                outstandingFailures,
                metrics.successRatePercent()
        );
        return ReleaseReadinessResponse.from(score);
    }

    private List<BuildMetricSnapshot> loadBuildSnapshots(
            Long teamId,
            Long groupId,
            Instant from,
            Instant to) {
        return buildRepository.findAll().stream()
                .filter(build -> matchesTeam(build, teamId, groupId))
                .filter(build -> isWithinRange(build.getStartedAt(), from, to))
                .map(this::toBuildSnapshot)
                .toList();
    }

    private List<FailureMetricSnapshot> loadFailureSnapshots(
            Long teamId,
            Long groupId,
            Instant from,
            Instant to) {
        return failureRepository.findAll().stream()
                .filter(failure -> matchesTeam(failure.getBuild(), teamId, groupId))
                .filter(failure -> isWithinRange(failure.getCreatedAt(), from, to))
                .map(this::toFailureSnapshot)
                .toList();
    }

    private List<JobLatestStatusSnapshot> loadJobLatestStatuses(Long teamId, Long groupId) {
        return jobRepository.findAll().stream()
                .filter(job -> matchesTeamFilter(job, teamId, groupId))
                .map(job -> {
                    BuildStatus latestStatus = buildRepository.findTopByJobIdOrderByBuildNumberDesc(job.getId())
                            .map(BuildEntity::getStatus)
                            .orElse(BuildStatus.UNKNOWN);
                    return new JobLatestStatusSnapshot(
                            job.getExternalId(),
                            job.getName(),
                            job.getTeam() != null ? job.getTeam().getName() : null,
                            latestStatus
                    );
                })
                .toList();
    }

    private boolean matchesTeam(BuildEntity build, Long teamId, Long groupId) {
        if (build.getJob() == null) {
            return false;
        }
        return matchesTeamFilter(build.getJob(), teamId, groupId);
    }

    private boolean matchesTeamFilter(JobEntity job, Long teamId, Long groupId) {
        if (!MonitoredJobRules.isMonitored(job)) {
            return false;
        }
        if (teamId != null) {
            if (job.getTeam() == null || !teamId.equals(job.getTeam().getId())) {
                return false;
            }
        }
        if (groupId != null) {
            if (job.getTeam() == null || job.getTeam().getGroup() == null
                    || !groupId.equals(job.getTeam().getGroup().getId())) {
                return false;
            }
        }
        return true;
    }

    private boolean isWithinRange(Instant value, Instant from, Instant to) {
        if (value == null) {
            return from == null && to == null;
        }
        if (from != null && value.isBefore(from)) {
            return false;
        }
        if (to != null && value.isAfter(to)) {
            return false;
        }
        return true;
    }

    private BuildMetricSnapshot toBuildSnapshot(BuildEntity build) {
        return new BuildMetricSnapshot(
                build.getExternalId(),
                build.getJob().getExternalId(),
                build.getJob().getName(),
                build.getJob().getTeam() != null ? build.getJob().getTeam().getName() : null,
                build.getStatus(),
                build.getStartedAt(),
                build.getDurationMs()
        );
    }

    private FailureMetricSnapshot toFailureSnapshot(FailureEntity failure) {
        BuildEntity build = failure.getBuild();
        return new FailureMetricSnapshot(
                failure.getId(),
                build.getExternalId(),
                build.getJob().getExternalId(),
                build.getJob().getName(),
                build.getJob().getTeam() != null ? build.getJob().getTeam().getName() : null,
                failure.getCategory(),
                failure.isResolved(),
                failure.getCreatedAt(),
                failure.getResolvedAt()
        );
    }
}
