package com.cognizant.eop.core.controller;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.core.dto.FailureDetailResponse;
import com.cognizant.eop.core.dto.FailureSummaryResponse;
import com.cognizant.eop.core.dto.page.PageResponse;
import com.cognizant.eop.core.service.FailureQueryService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/failures")
public class FailureController {

    private final FailureQueryService failureQueryService;

    public FailureController(FailureQueryService failureQueryService) {
        this.failureQueryService = failureQueryService;
    }

    @GetMapping
    public ResponseEntity<PageResponse<FailureSummaryResponse>> listFailures(
            @PageableDefault(size = 20, sort = "createdAt") Pageable pageable,
            @RequestParam(required = false) FailureCategory category,
            @RequestParam(required = false) Boolean resolved,
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        return ResponseEntity.ok(failureQueryService.findFailures(pageable, category, resolved, teamId, from, to));
    }

    @GetMapping("/{failureId}")
    public ResponseEntity<FailureDetailResponse> getFailure(@PathVariable Long failureId) {
        return ResponseEntity.ok(failureQueryService.findById(failureId));
    }
}
