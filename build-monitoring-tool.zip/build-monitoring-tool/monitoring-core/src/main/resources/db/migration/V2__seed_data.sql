-- V2: Seed data for development

INSERT INTO "group" (name, description) VALUES
    ('Front Office', 'Front office development teams'),
    ('Middle Office', 'Middle office development teams'),
    ('Back Office', 'Back office development teams'),
    ('Framework', 'Framework and platform teams');

INSERT INTO team (name, group_id, email) VALUES
    ('Alpha Team', 1, 'alpha-team@titan.internal'),
    ('Beta Team', 1, 'beta-team@titan.internal'),
    ('Gamma Team', 2, 'gamma-team@titan.internal'),
    ('Delta Team', 3, 'delta-team@titan.internal'),
    ('Epsilon Team', 4, 'epsilon-team@titan.internal');

INSERT INTO developer (username, display_name, email, team_id) VALUES
    ('jsmith', 'John Smith', 'jsmith@titan.internal', 1),
    ('mjones', 'Mary Jones', 'mjones@titan.internal', 1),
    ('alee', 'Alice Lee', 'alee@titan.internal', 2),
    ('rkumar', 'Raj Kumar', 'rkumar@titan.internal', 3),
    ('schen', 'Sarah Chen', 'schen@titan.internal', 4),
    ('dpatel', 'Dev Patel', 'dpatel@titan.internal', 5);

INSERT INTO configuration (config_key, config_value, description) VALUES
    ('polling.interval.ms', '300000', 'Scheduler polling interval in milliseconds'),
    ('notification.enabled', 'true', 'Global notification toggle'),
    ('ai.confidence.threshold', '50', 'Minimum confidence score for failure classification');

INSERT INTO notification_rule (name, event_type, channel, template_name) VALUES
    ('First Failure Alert', 'BUILD_FAILURE', 'EMAIL', 'failure-notification'),
    ('Recovery Notification', 'BUILD_RECOVERY', 'EMAIL', 'recovery-notification'),
    ('Root Cause Changed', 'ROOT_CAUSE_CHANGED', 'EMAIL', 'root-cause-changed');
