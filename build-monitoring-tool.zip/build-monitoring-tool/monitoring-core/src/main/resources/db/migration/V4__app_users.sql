-- V4: Application users for RBAC authentication

CREATE TABLE app_user (
    id            BIGSERIAL PRIMARY KEY,
    username      VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name  VARCHAR(200) NOT NULL,
    email         VARCHAR(255) NOT NULL,
    role          VARCHAR(50) NOT NULL,
    team_id       BIGINT REFERENCES team(id),
    enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMPTZ
);

CREATE INDEX idx_app_user_role ON app_user(role);
CREATE INDEX idx_app_user_team_id ON app_user(team_id);

-- BCrypt hash for password: "password"
INSERT INTO app_user (username, password_hash, display_name, email, role, team_id) VALUES
    ('admin', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@titan.internal', 'ADMINISTRATOR', NULL),
    ('manager', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Operations Manager', 'manager@titan.internal', 'MANAGER', NULL),
    ('jsmith', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Smith', 'jsmith@titan.internal', 'DEVELOPER', 1),
    ('viewer', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Read Only User', 'viewer@titan.internal', 'VIEWER', NULL);
