-- V3: Seed mock CI/CD jobs linked to teams

INSERT INTO job (external_id, name, team_id, branch, build_type, enabled, polling_enabled) VALUES
    ('job-fo-alpha-instream', 'Titan :: FrontOffice :: Alpha Team :: Instream Build', 1, 'fo/alpha/instream', 'Titan_FrontOffice_Alpha_Instream', true, true),
    ('job-fo-beta-staging', 'Titan :: FrontOffice :: Beta Team :: Staging Build', 2, 'fo/beta/staging', 'Titan_FrontOffice_Beta_Staging', true, true),
    ('job-mo-gamma-instream', 'Titan :: MiddleOffice :: Gamma Team :: Instream Build', 3, 'mo/gamma/instream', 'Titan_MiddleOffice_Gamma_Instream', true, true),
    ('job-bo-delta-master', 'Titan :: BackOffice :: Delta Team :: Master Build', 4, 'bo/delta/master', 'Titan_BackOffice_Delta_Master', true, true),
    ('job-fw-epsilon-instream', 'Titan :: Framework :: Epsilon Team :: Instream Build', 5, 'fw/epsilon/instream', 'Titan_Framework_Epsilon_Instream', true, true),
    ('job-fo-alpha-integration', 'Titan :: FrontOffice :: Alpha Team :: Integration Tests', 1, 'fo/alpha/instream', 'Titan_FrontOffice_Alpha_Integration', true, true);
