-- V5: Remove development seed demo data while preserving user-created teams and TeamCity jobs.

-- Demo build data linked to mock job external IDs
DELETE FROM notification
WHERE build_id IN (
        SELECT b.id FROM build b
        JOIN job j ON b.job_id = j.id
        WHERE j.external_id LIKE 'job-%'
    )
   OR failure_id IN (
        SELECT f.id FROM failure f
        JOIN build b ON f.build_id = b.id
        JOIN job j ON b.job_id = j.id
        WHERE j.external_id LIKE 'job-%'
    );

DELETE FROM failure
WHERE build_id IN (
        SELECT b.id FROM build b
        JOIN job j ON b.job_id = j.id
        WHERE j.external_id LIKE 'job-%'
    );

DELETE FROM build_commit
WHERE build_id IN (
        SELECT b.id FROM build b
        JOIN job j ON b.job_id = j.id
        WHERE j.external_id LIKE 'job-%'
    );

DELETE FROM build
WHERE job_id IN (SELECT id FROM job WHERE external_id LIKE 'job-%');

DELETE FROM job WHERE external_id LIKE 'job-%';

-- Seed developers (demo only)
DELETE FROM developer;

UPDATE app_user SET team_id = NULL
WHERE team_id IN (
        SELECT id FROM team
        WHERE name IN ('Alpha Team', 'Beta Team', 'Gamma Team', 'Delta Team', 'Epsilon Team')
    );

-- Seed teams only when they have no remaining jobs
DELETE FROM team
WHERE name IN ('Alpha Team', 'Beta Team', 'Gamma Team', 'Delta Team', 'Epsilon Team')
  AND id NOT IN (SELECT DISTINCT team_id FROM job WHERE team_id IS NOT NULL);

-- Seed groups only when they no longer contain teams
DELETE FROM "group"
WHERE name IN ('Front Office', 'Middle Office', 'Back Office', 'Framework')
  AND id NOT IN (SELECT DISTINCT group_id FROM team);

-- Ensure at least one group exists for admin team creation
INSERT INTO "group" (name, description)
SELECT 'Default', 'Default group for TeamCity-monitored teams'
WHERE NOT EXISTS (SELECT 1 FROM "group");
