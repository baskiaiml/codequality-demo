-- V1: Core schema for EOP platform

CREATE TABLE "group" (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(500),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE team (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    group_id    BIGINT NOT NULL REFERENCES "group"(id),
    email       VARCHAR(255),
    enabled     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_team_group_id ON team(group_id);

CREATE TABLE developer (
    id           BIGSERIAL PRIMARY KEY,
    username     VARCHAR(100) NOT NULL UNIQUE,
    display_name VARCHAR(200) NOT NULL,
    email        VARCHAR(255) NOT NULL,
    team_id      BIGINT NOT NULL REFERENCES team(id),
    enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_developer_team_id ON developer(team_id);

CREATE TABLE job (
    id              BIGSERIAL PRIMARY KEY,
    external_id     VARCHAR(255) NOT NULL UNIQUE,
    name            VARCHAR(500) NOT NULL,
    team_id         BIGINT REFERENCES team(id),
    branch          VARCHAR(255),
    build_type      VARCHAR(100),
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    polling_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_job_team_id ON job(team_id);
CREATE INDEX idx_job_enabled ON job(enabled);

CREATE TABLE build (
    id           BIGSERIAL PRIMARY KEY,
    external_id  VARCHAR(255) NOT NULL UNIQUE,
    job_id       BIGINT NOT NULL REFERENCES job(id),
    build_number INTEGER NOT NULL,
    status       VARCHAR(50) NOT NULL,
    branch       VARCHAR(255),
    started_at   TIMESTAMPTZ,
    finished_at  TIMESTAMPTZ,
    duration_ms  BIGINT,
    triggered_by VARCHAR(255),
    build_url    VARCHAR(1000),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (job_id, build_number)
);

CREATE INDEX idx_build_job_id ON build(job_id);
CREATE INDEX idx_build_status ON build(status);
CREATE INDEX idx_build_started_at ON build(started_at);
CREATE INDEX idx_build_job_status ON build(job_id, status);

CREATE TABLE build_commit (
    id          BIGSERIAL PRIMARY KEY,
    build_id    BIGINT NOT NULL REFERENCES build(id),
    commit_hash VARCHAR(64) NOT NULL,
    author      VARCHAR(255),
    message     TEXT,
    timestamp   TIMESTAMPTZ
);

CREATE INDEX idx_build_commit_build_id ON build_commit(build_id);

CREATE TABLE failure (
    id                BIGSERIAL PRIMARY KEY,
    build_id          BIGINT NOT NULL UNIQUE REFERENCES build(id),
    category          VARCHAR(100) NOT NULL,
    confidence_score  DECIMAL(5,2),
    root_cause        TEXT,
    suggested_fix     TEXT,
    affected_module   VARCHAR(255),
    possible_owner    VARCHAR(255),
    relevant_classes  TEXT,
    sql_objects       TEXT,
    log_snippet       TEXT,
    recommendation    TEXT,
    developer_impact  VARCHAR(500),
    severity          VARCHAR(50),
    resolved          BOOLEAN NOT NULL DEFAULT FALSE,
    resolved_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_failure_category ON failure(category);
CREATE INDEX idx_failure_resolved ON failure(resolved);

CREATE TABLE notification (
    id                BIGSERIAL PRIMARY KEY,
    build_id          BIGINT REFERENCES build(id),
    failure_id        BIGINT REFERENCES failure(id),
    channel           VARCHAR(50) NOT NULL,
    recipient         VARCHAR(500) NOT NULL,
    subject           VARCHAR(500),
    body              TEXT,
    notification_type VARCHAR(50) NOT NULL,
    sent_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status            VARCHAR(50) NOT NULL DEFAULT 'SENT'
);

CREATE INDEX idx_notification_build_id ON notification(build_id);
CREATE INDEX idx_notification_type ON notification(notification_type);

CREATE TABLE configuration (
    id           BIGSERIAL PRIMARY KEY,
    config_key   VARCHAR(255) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    description  VARCHAR(500),
    updated_by   VARCHAR(255),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE notification_rule (
    id            BIGSERIAL PRIMARY KEY,
    name          VARCHAR(255) NOT NULL,
    event_type    VARCHAR(50) NOT NULL,
    channel       VARCHAR(50) NOT NULL,
    template_name VARCHAR(255),
    enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE email_group (
    id         BIGSERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL UNIQUE,
    addresses  TEXT NOT NULL,
    team_id    BIGINT REFERENCES team(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_event (
    id          BIGSERIAL PRIMARY KEY,
    event_type  VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100),
    entity_id   VARCHAR(255),
    actor       VARCHAR(255) NOT NULL,
    details     JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_event_type ON audit_event(event_type);
CREATE INDEX idx_audit_created_at ON audit_event(created_at);

CREATE TABLE analytics_snapshot (
    id            BIGSERIAL PRIMARY KEY,
    snapshot_date DATE NOT NULL,
    metric_name   VARCHAR(100) NOT NULL,
    metric_value  DECIMAL(15,4) NOT NULL,
    dimensions    JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (snapshot_date, metric_name, dimensions)
);

CREATE INDEX idx_analytics_date_metric ON analytics_snapshot(snapshot_date, metric_name);
