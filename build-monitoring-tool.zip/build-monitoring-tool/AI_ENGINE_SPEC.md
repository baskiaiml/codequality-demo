# AI Engine Specification

## Overview

The AI module provides build failure analysis using a **fully local, rule-based engine**. No external API calls. No internet dependency. The architecture supports future LLM implementations via the `AIAnalyzer` interface and Spring Profiles.

---

## Architecture

```
BuildLog
  │
  ▼
┌─────────────────┐
│  Log Preprocessor│  Normalize, strip timestamps, extract error blocks
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Pattern Matcher  │  Match against knowledge base patterns
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Rule Engine     │  Apply decision tree rules
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Confidence Scorer│  Calculate confidence from match quality
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Recommendation   │  Generate fix suggestions from knowledge base
│ Engine           │
└────────┬────────┘
         │
         ▼
    AIAnalysis
```

---

## Interface

```java
public interface AIAnalyzer {
    AIAnalysis analyze(BuildLog buildLog);
}
```

### AIAnalysis Output

| Field | Type | Description |
|---|---|---|
| failureType | FailureCategory | Classification enum |
| confidenceScore | BigDecimal | 0.00–100.00 |
| rootCause | String | Human-readable root cause |
| suggestedFix | String | Actionable fix recommendation |
| affectedModule | String | Module or package affected |
| possibleOwner | String | Developer likely responsible |
| relevantClasses | List<String> | Java classes involved |
| sqlObjects | List<String> | SQL tables/procedures involved |
| logSnippet | String | Relevant excerpt from build log |
| recommendation | String | Broader recommendation |
| developerImpact | String | Impact description for developers |
| severity | Severity | CRITICAL, HIGH, MEDIUM, LOW |

---

## Knowledge Base Format

Patterns stored as YAML files in `monitoring-ai/src/main/resources/knowledge-base/`.

### Pattern File Structure

```yaml
category: COMPILATION_ERROR
displayName: "Compilation Error"
defaultSeverity: HIGH
patterns:
  - id: compilation-cannot-find-symbol
    regex: "error: cannot find symbol\\s+symbol:\\s+class\\s+(\\w+)"
    confidence: 95
    rootCauseTemplate: "Class {0} no longer exists or is not on the classpath"
    suggestedFixTemplate: "Verify that {0} exists and is properly imported"
    extractGroups: [1]
    classExtractor: "symbol:\\s+class\\s+(\\w+)"

  - id: compilation-incompatible-types
    regex: "error: incompatible types:"
    confidence: 90
    rootCauseTemplate: "Type mismatch in assignment or method call"
    suggestedFixTemplate: "Check variable types and method return types"

recommendations:
  - condition: "confidence >= 90"
    message: "High confidence match. Apply suggested fix directly."
  - condition: "confidence < 70"
    message: "Low confidence. Manual investigation recommended."
```

### Pattern Categories

| File | Category |
|---|---|
| `compilation-patterns.yaml` | Compilation Error |
| `junit-patterns.yaml` | JUnit Failure |
| `merge-conflict-patterns.yaml` | Merge Conflict |
| `liquibase-patterns.yaml` | Liquibase Failure |
| `oracle-patterns.yaml` | Oracle SQL Failure |
| `gradle-patterns.yaml` | Gradle Failure |
| `maven-patterns.yaml` | Maven Failure |
| `docker-patterns.yaml` | Docker Failure |
| `git-patterns.yaml` | Git Failure |
| `linux-patterns.yaml` | Infrastructure Failure |
| `kubernetes-patterns.yaml` | Infrastructure Failure |
| `dependency-patterns.yaml` | Dependency Failure |
| `timeout-patterns.yaml` | Timeout |
| `environment-patterns.yaml` | Environment Failure |
| `infrastructure-patterns.yaml` | Infrastructure Failure |

---

## Confidence Scoring

Confidence is calculated from multiple signals:

| Signal | Weight | Description |
|---|---|---|
| Pattern match quality | 40% | Exact regex match vs partial |
| Multiple pattern agreement | 25% | Multiple patterns match same category |
| Context validation | 20% | Surrounding log lines support classification |
| Historical accuracy | 15% | Past accuracy of this pattern (future) |

Formula:

```
confidence = (patternScore * 0.40) + (agreementScore * 0.25)
           + (contextScore * 0.20) + (historicalScore * 0.15)
```

Minimum confidence threshold: configurable (default 50%). Below threshold → `UNKNOWN_FAILURE`.

---

## Decision Tree

```
Build Log Received
  │
  ├─ Contains "merge conflict" → MERGE_CONFLICT
  ├─ Contains "Tests run:" + "Failures:" → JUNIT_FAILURE
  ├─ Contains "liquibase" + "ERROR" → LIQUIBASE_FAILURE
  ├─ Contains "ORA-" → ORACLE_SQL_FAILURE
  ├─ Contains "BUILD FAILED" (Maven) → MAVEN_FAILURE
  ├─ Contains "BUILD FAILED" (Gradle) → GRADLE_FAILURE
  ├─ Contains "error:" (Java compiler) → COMPILATION_ERROR
  ├─ Contains "docker" + "error" → DOCKER_FAILURE
  ├─ Contains "timeout" / "timed out" → TIMEOUT
  ├─ Contains "git" + "error"/"fatal" → GIT_FAILURE
  ├─ Contains "Connection refused" / "Network" → NETWORK_FAILURE
  ├─ Contains "deploy" + "failed" → DEPLOYMENT_FAILURE
  └─ No match → UNKNOWN_FAILURE
```

Decision tree provides first-pass classification. Pattern matcher refines with detailed analysis.

---

## Log Preprocessing

1. Strip ANSI color codes
2. Normalize line endings
3. Remove timestamp prefixes (configurable pattern)
4. Extract error blocks (lines between "error", "ERROR", "FAILED" markers)
5. Deduplicate repeated lines (Maven/Gradle re-output)
6. Truncate to configurable max length (default 50,000 chars)

---

## Extensibility

Adding a new failure type requires **only**:

1. Create a new YAML pattern file in `knowledge-base/`
2. Add the category to the `FailureCategory` enum
3. No Java code changes required

Future LLM implementations (`ClaudeAnalyzer`, `OpenAIAnalyzer`) implement the same `AIAnalyzer` interface and can leverage the knowledge base for prompt context.

---

## Spring Profile Switching

```yaml
# application-dev.yml
eop:
  ai:
    analyzer: rule-based

# application-production.yml (future)
eop:
  ai:
    analyzer: claude
    api-key: ${CLAUDE_API_KEY}
```

```java
@Configuration
public class AIAnalyzerConfig {
    @Bean
    @ConditionalOnProperty(name = "eop.ai.analyzer", havingValue = "rule-based")
    AIAnalyzer ruleBasedAnalyzer(KnowledgeBaseLoader loader) {
        return new RuleBasedAnalyzer(loader);
    }
}
```
