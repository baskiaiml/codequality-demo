# UI/UX Guidelines

## Design System

### Framework

- **Material UI (MUI) v6** — component library
- **AG Grid Community** — data tables with sorting, filtering, pagination
- **React Query** — server state management and caching
- **React Router** — client-side routing

### Theme

- Light and dark mode support via MUI theme toggle
- Primary color: enterprise blue (`#1565C0`)
- Error color: `#D32F2F`
- Success color: `#2E7D32`
- Warning color: `#ED6C02`
- Responsive breakpoints following MUI defaults

---

## Navigation Structure

```
┌─────────────────────────────────────────────────────┐
│  EOP Logo    Global │ Groups │ Teams │ Failures │ ⚙ │
├─────────────────────────────────────────────────────┤
│                                                      │
│  [Dashboard Content Area]                            │
│                                                      │
└─────────────────────────────────────────────────────┘
```

### Primary Navigation

| Nav Item | Route | Description |
|---|---|---|
| Global Dashboard | `/` | Organization-wide build health |
| Groups | `/groups` | Group-level views (Front/Middle/Back/Framework) |
| Teams | `/teams` | Team-level dashboards |
| Failures | `/failures` | Active and historical failures |
| Running Builds | `/running` | Currently executing builds |
| Analytics | `/analytics` | Metrics, trends, reports |
| Release Readiness | `/release-readiness` | Release health score |
| Admin | `/admin` | Configuration management (Admin role) |

---

## Dashboard Layouts

### Global Dashboard

```
┌────────────┬────────────┬────────────┬────────────┐
│ Total Jobs │  Running   │  Failed    │  Success % │
│    247     │     12     │     8      │   94.2%    │
├────────────┴────────────┴────────────┴────────────┤
│  Build Status by Group (bar chart)               │
├──────────────────────┬───────────────────────────┤
│  Recent Failures     │  Running Builds           │
│  (AG Grid table)     │  (AG Grid table)          │
├──────────────────────┴───────────────────────────┤
│  Failure Categories (pie chart)                   │
└──────────────────────────────────────────────────┘
```

### Job Dashboard

- Job metadata (name, team, branch, last build)
- Build history timeline
- Latest failure analysis with root cause and suggested fix
- Build duration trend chart

### Failure Dashboard

- Filterable AG Grid: category, team, severity, date range
- Expandable rows showing AI analysis details
- Log snippet viewer with syntax highlighting
- Suggested fix panel

### Release Readiness Dashboard

```
┌─────────────────────────────────────────────────┐
│  Release Readiness Score: 87/100  [████████░░]  │
├────────────┬────────────┬────────────┬───────────┤
│ Build      │ Build      │ Outstanding│ Blocked   │
│ Status ✓   │ Stability  │ Failures   │ Builds    │
│            │ 94.2%      │ 3          │ 1         │
├────────────┴────────────┴────────────┴───────────┤
│  Environment Readiness │ Deployment Readiness   │
└─────────────────────────────────────────────────┘
```

---

## Component Patterns

### Status Indicators

| Status | Color | Icon |
|---|---|---|
| SUCCESS | Green | CheckCircle |
| FAILURE | Red | Error |
| RUNNING | Blue (animated) | Sync |
| QUEUED | Grey | HourglassEmpty |
| CANCELLED | Orange | Cancel |

### AG Grid Configuration

- Default page size: 20
- Server-side pagination for large datasets
- Column filters enabled
- Export to CSV on analytics tables
- Row click navigates to detail view

### Cards

- Use MUI Card for summary metrics
- Include trend indicator (up/down arrow with percentage)
- Clickable cards navigate to filtered detail views

---

## Responsive Design

- **Desktop (>1200px)**: Full dashboard layout with side-by-side panels
- **Tablet (768–1200px)**: Stacked panels, collapsible navigation
- **Mobile (<768px)**: Single-column layout, bottom navigation bar

---

## Accessibility

- WCAG 2.1 AA compliance
- All interactive elements keyboard-accessible
- Color is never the sole indicator of status (always paired with icon/text)
- ARIA labels on all data grids and charts

---

## Frontend Project Structure

```
monitoring-ui/
├── public/
├── src/
│   ├── api/              # React Query hooks and API client
│   ├── components/       # Shared UI components
│   │   ├── common/       # Buttons, cards, status badges
│   │   ├── layout/       # AppBar, Sidebar, PageLayout
│   │   └── charts/       # Chart wrappers
│   ├── features/         # Feature-specific pages
│   │   ├── dashboard/
│   │   ├── failures/
│   │   ├── teams/
│   │   ├── analytics/
│   │   ├── release-readiness/
│   │   └── admin/
│   ├── hooks/            # Custom React hooks
│   ├── theme/            # MUI theme configuration
│   ├── types/            # TypeScript interfaces
│   ├── utils/            # Formatting, constants
│   ├── App.tsx
│   └── main.tsx
├── package.json
└── tsconfig.json
```
