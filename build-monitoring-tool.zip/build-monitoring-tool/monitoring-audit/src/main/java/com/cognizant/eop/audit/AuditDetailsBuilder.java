package com.cognizant.eop.audit;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Fluent builder for audit event detail maps.
 */
public final class AuditDetailsBuilder {

    private final Map<String, Object> details = new LinkedHashMap<>();

    private AuditDetailsBuilder() {
    }

    public static AuditDetailsBuilder create() {
        return new AuditDetailsBuilder();
    }

    public AuditDetailsBuilder put(String key, Object value) {
        if (value != null) {
            details.put(key, value);
        }
        return this;
    }

    public Map<String, Object> build() {
        return Map.copyOf(details);
    }
}
