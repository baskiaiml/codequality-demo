package com.cognizant.eop.audit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AuditDetailsBuilderTest {

    @Test
    void build_omitsNullValues() {
        var details = AuditDetailsBuilder.create()
                .put("key", "value")
                .put("ignored", null)
                .build();

        assertEquals(1, details.size());
        assertEquals("value", details.get("key"));
        assertTrue(details.containsKey("key"));
    }
}
