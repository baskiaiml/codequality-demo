# Enterprise Engineering Operations Platform (EOP)

Centralized build monitoring and engineering operations platform for the Titan enterprise application.

## Prerequisites

- Java 21
- Maven 3.9+
- Docker & Docker Compose

## Quick Start

### 1. Start PostgreSQL

```bash
docker compose up -d
```

### 2. Build the project

```bash
mvn clean install
```

### 3. Run the application

```bash
mvn spring-boot:run -pl monitoring-core
```

### 4. Verify

```bash
curl http://localhost:8080/api/v1/health
curl http://localhost:8080/api/v1/provider/jobs
curl http://localhost:8080/api/v1/provider/running-builds
```

OpenAPI documentation: http://localhost:8080/swagger-ui.html

### 5. Authenticate (Iteration 9+)

Security is enabled by default. Demo users (password for all: `password`):

| Username | Role |
|---|---|
| admin | Administrator |
| manager | Manager |
| jsmith | Developer (Alpha Team) |
| viewer | Viewer |

```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password"}'

# Use the returned token on subsequent requests:
curl http://localhost:8080/api/v1/dashboard/global \
  -H "Authorization: Bearer <token>"
```

To disable security locally (open API): set `eop.security.enabled: false` in `application.yml`.

### 6. Run the React UI (Iteration 10+)

In a second terminal:

```bash
cd monitoring-ui
npm install
npm run dev
```

Open http://localhost:5173 and sign in with a demo user (e.g. `admin` / `password`).

The Vite dev server proxies `/api` to `http://localhost:8080`. Ensure the backend is running and PostgreSQL is up.

```bash
# Production build
cd monitoring-ui
npm run build
```

## Monitoring Jobs & TeamCity Integration

### Development (mock provider)

Jobs are stored in PostgreSQL and polled by the scheduler when `enabled=true` and `polling_enabled=true`.

1. Insert a job (or extend `V3__seed_mock_jobs.sql`)
2. Add matching entries in `monitoring-provider/src/main/resources/mock-data/teamcity-data.json`
3. Restart the app and trigger polling:

```bash
curl -X POST http://localhost:8080/api/v1/jobs/{externalId}/process-builds \
  -H "Authorization: Bearer <token>"
```

### Production (TeamCity)

Switch the provider and supply credentials:

```yaml
eop:
  provider:
    type: teamcity
    teamcity:
      base-url: https://teamcity.yourcompany.internal
      token: ${TEAMCITY_TOKEN}
```

Or run with the `teamcity` profile:

```bash
mvn spring-boot:run -pl monitoring-core -Dspring-boot.run.profiles=teamcity
```

Set `TEAMCITY_TOKEN` (Bearer token) or `TEAMCITY_USERNAME` / `TEAMCITY_PASSWORD` for basic auth.

**Sync jobs from TeamCity** (admin only):

```bash
curl -X POST http://localhost:8080/api/v1/admin/jobs/sync \
  -H "Authorization: Bearer <admin-token>"
```

This imports build configurations into the `job` table using the **build type ID** as `external_id`. Synced jobs are **not monitored** until an admin assigns them to a team.

### Admin workflow (teams & monitored jobs)

Only **ADMINISTRATOR** users can manage teams and monitoring. Teams must exist before build jobs can be monitored. Teams cannot be removed once created.

1. **Create a team** (requires an existing group):

```bash
curl -X POST http://localhost:8080/api/v1/admin/teams \
  -H "Authorization: Bearer <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{"groupId":1,"name":"Ops Team","email":"ops@example.com"}'
```

2. **Sync jobs from the provider** (optional; discovers build types):

```bash
curl -X POST http://localhost:8080/api/v1/admin/jobs/sync \
  -H "Authorization: Bearer <admin-token>"
```

3. **Add a job to monitoring** (requires `teamId`):

```bash
curl -X POST http://localhost:8080/api/v1/admin/jobs \
  -H "Authorization: Bearer <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{"teamId":1,"externalId":"Titan_FrontOffice_Alpha_Instream"}'
```

4. **Remove a job from monitoring**:

```bash
curl -X DELETE http://localhost:8080/api/v1/admin/jobs/Titan_FrontOffice_Alpha_Instream \
  -H "Authorization: Bearer <admin-token>"
```

In the React UI, open **Admin → Teams** or **Admin → Monitored Jobs** (login as `admin` / `password`).

**TeamCity REST mapping:**

| EOP | TeamCity |
|-----|----------|
| `job.external_id` | Build type ID (e.g. `Titan_FrontOffice_Alpha_Instream`) |
| `build.external_id` | Build internal ID |
| `getBuildLog` | `/downloadBuildLog.html?buildId=...` |

## Project Structure

```
eop-parent/
├── monitoring-api/          Shared domain models and port interfaces
├── monitoring-provider/     BuildProvider implementations (Mock, TeamCity)
├── monitoring-parser/       Build log parsing and knowledge base
├── monitoring-ai/           Rule-based AI analysis engine
├── monitoring-notification/ Notification engine (Iteration 6)
├── monitoring-analytics/    Engineering metrics and release readiness
├── monitoring-security/     Spring Security RBAC (Iteration 9)
├── monitoring-audit/        Audit trail (Iteration 9)
├── monitoring-ui/         React dashboards (Iteration 10)
└── monitoring-core/         Spring Boot app, scheduler, REST API
```

## Architecture Documents

| Document | Description |
|---|---|
| [PROJECT_CONSTITUTION.md](PROJECT_CONSTITUTION.md) | Authoritative project principles |
| [SYSTEM_ARCHITECTURE.md](SYSTEM_ARCHITECTURE.md) | Module interactions and deployment |
| [DATABASE_DESIGN.md](DATABASE_DESIGN.md) | Schema design and indexing |
| [API_STANDARDS.md](API_STANDARDS.md) | REST conventions and error handling |
| [UI_UX_GUIDELINES.md](UI_UX_GUIDELINES.md) | Dashboard layouts and design system |
| [AI_ENGINE_SPEC.md](AI_ENGINE_SPEC.md) | AI parser and knowledge base format |
| [CODING_STANDARDS.md](CODING_STANDARDS.md) | Naming, testing, review checklist |

## Development Profile

The application runs with `MockBuildProvider` by default, reading from JSON files in `monitoring-provider/src/main/resources/mock-data/`. No TeamCity connection required.

Mock data includes: successful builds, compilation failures, JUnit failures, SQL failures, merge conflicts, running builds, cancelled builds, and queued builds.

## Running Tests

```bash
# All tests
mvn test

# Unit tests only (MockBuildProvider)
mvn test -pl monitoring-provider

# Integration tests (requires Docker for Testcontainers)
mvn test -pl monitoring-core
```

## Iteration Plan

| Iteration | Scope | Status |
|---|---|---|
| 1 | Project foundation, docs, BuildProvider abstraction, MockBuildProvider | Complete |
| 2 | Database entities, repositories, domain services, build persistence | Complete |
| 3 | Build monitoring scheduler and orchestrator | Complete |
| 4 | Log parser and knowledge base | Complete |
| 5 | Rule-based AI analyzer | Complete |
| 6 | Notification engine | Complete |
| 7 | REST API (jobs, builds, failures, dashboards) | Complete |
| 8 | Analytics and release readiness | Complete |
| 9 | Security and audit | Complete |
| 10 | React frontend dashboards | Complete |
