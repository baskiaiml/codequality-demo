# Database Design

## Overview

PostgreSQL with Flyway migrations. Normalized schema with appropriate indexes for query patterns used by dashboards and analytics.

---

## Entity Relationship Diagram

```
┌──────────┐       ┌──────────┐       ┌──────────┐
│  "group"  │──1:N─│   team   │──1:N─│ developer│
└──────────┘       └────┬─────┘       └──────────┘
                        │
                       1:N
                        │
                   ┌────▼─────┐       ┌──────────┐
                   │   job    │──1:N─│  build   │
                   └──────────┘       └────┬─────┘
                                           │
                              ┌────────────┼────────────┐
                              │            │            │
                         ┌────▼────┐ ┌────▼────┐ ┌────▼────────┐
                         │ failure │ │notific- │ │build_commit │
                         │         │ │  ation  │ │             │
                         └─────────┘ └─────────┘ └─────────────┘

┌──────────────┐  ┌──────────────────┐  ┌───────────────┐
│configuration │  │notification_rule │  │  audit_event  │
└──────────────┘  └──────────────────┘  └───────────────┘

┌──────────────┐  ┌──────────────────┐
│ email_group  │  │  analytics_snap  │
└──────────────┘  └──────────────────┘
```

---

## Table Definitions

### group

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| name | VARCHAR(100) | NOT NULL, UNIQUE |
| description | VARCHAR(500) | |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |
| updated_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Values: Front Office, Middle Office, Back Office, Framework

### team

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| name | VARCHAR(100) | NOT NULL, UNIQUE |
| group_id | BIGINT | FK → group(id) |
| email | VARCHAR(255) | |
| enabled | BOOLEAN | NOT NULL, DEFAULT TRUE |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |
| updated_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Index: `idx_team_group_id`

### developer

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| username | VARCHAR(100) | NOT NULL, UNIQUE |
| display_name | VARCHAR(200) | NOT NULL |
| email | VARCHAR(255) | NOT NULL |
| team_id | BIGINT | FK → team(id) |
| enabled | BOOLEAN | NOT NULL, DEFAULT TRUE |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Index: `idx_developer_team_id`

### job

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| external_id | VARCHAR(255) | NOT NULL, UNIQUE |
| name | VARCHAR(500) | NOT NULL |
| team_id | BIGINT | FK → team(id) |
| branch | VARCHAR(255) | |
| build_type | VARCHAR(100) | |
| enabled | BOOLEAN | NOT NULL, DEFAULT TRUE |
| polling_enabled | BOOLEAN | NOT NULL, DEFAULT TRUE |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |
| updated_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Indexes: `idx_job_team_id`, `idx_job_enabled`

### build

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| external_id | VARCHAR(255) | NOT NULL, UNIQUE |
| job_id | BIGINT | FK → job(id), NOT NULL |
| build_number | INTEGER | NOT NULL |
| status | VARCHAR(50) | NOT NULL |
| branch | VARCHAR(255) | |
| started_at | TIMESTAMPTZ | |
| finished_at | TIMESTAMPTZ | |
| duration_ms | BIGINT | |
| triggered_by | VARCHAR(255) | |
| build_url | VARCHAR(1000) | |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Indexes: `idx_build_job_id`, `idx_build_status`, `idx_build_started_at`, `idx_build_job_status`

Unique: `(job_id, build_number)`

### build_commit

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| build_id | BIGINT | FK → build(id), NOT NULL |
| commit_hash | VARCHAR(64) | NOT NULL |
| author | VARCHAR(255) | |
| message | TEXT | |
| timestamp | TIMESTAMPTZ | |

Index: `idx_build_commit_build_id`

### failure

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| build_id | BIGINT | FK → build(id), NOT NULL, UNIQUE |
| category | VARCHAR(100) | NOT NULL |
| confidence_score | DECIMAL(5,2) | |
| root_cause | TEXT | |
| suggested_fix | TEXT | |
| affected_module | VARCHAR(255) | |
| possible_owner | VARCHAR(255) | |
| relevant_classes | TEXT | |
| sql_objects | TEXT | |
| log_snippet | TEXT | |
| recommendation | TEXT | |
| developer_impact | VARCHAR(500) | |
| severity | VARCHAR(50) | |
| resolved | BOOLEAN | NOT NULL, DEFAULT FALSE |
| resolved_at | TIMESTAMPTZ | |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Indexes: `idx_failure_category`, `idx_failure_resolved`, `idx_failure_build_id`

### notification

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| build_id | BIGINT | FK → build(id) |
| failure_id | BIGINT | FK → failure(id) |
| channel | VARCHAR(50) | NOT NULL |
| recipient | VARCHAR(500) | NOT NULL |
| subject | VARCHAR(500) | |
| body | TEXT | |
| notification_type | VARCHAR(50) | NOT NULL |
| sent_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |
| status | VARCHAR(50) | NOT NULL, DEFAULT 'SENT' |

Indexes: `idx_notification_build_id`, `idx_notification_type`

### configuration

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| config_key | VARCHAR(255) | NOT NULL, UNIQUE |
| config_value | TEXT | NOT NULL |
| description | VARCHAR(500) | |
| updated_by | VARCHAR(255) | |
| updated_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Default keys: `polling.interval.ms`, `notification.enabled`, `ai.confidence.threshold`

### notification_rule

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| name | VARCHAR(255) | NOT NULL |
| event_type | VARCHAR(50) | NOT NULL |
| channel | VARCHAR(50) | NOT NULL |
| template_name | VARCHAR(255) | |
| enabled | BOOLEAN | NOT NULL, DEFAULT TRUE |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

### email_group

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| name | VARCHAR(255) | NOT NULL, UNIQUE |
| addresses | TEXT | NOT NULL |
| team_id | BIGINT | FK → team(id) |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

### audit_event

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| event_type | VARCHAR(100) | NOT NULL |
| entity_type | VARCHAR(100) | |
| entity_id | VARCHAR(255) | |
| actor | VARCHAR(255) | NOT NULL |
| details | JSONB | |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Index: `idx_audit_event_type`, `idx_audit_created_at`

### analytics_snapshot

| Column | Type | Constraints |
|---|---|---|
| id | BIGSERIAL | PK |
| snapshot_date | DATE | NOT NULL |
| metric_name | VARCHAR(100) | NOT NULL |
| metric_value | DECIMAL(15,4) | NOT NULL |
| dimensions | JSONB | |
| created_at | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() |

Index: `idx_analytics_date_metric`, unique `(snapshot_date, metric_name, dimensions)`

---

## Indexing Strategy

- **Dashboard queries**: Composite indexes on `(job_id, status)` and `(team_id)` via joins
- **Time-range analytics**: Index on `build.started_at`, `analytics_snapshot.snapshot_date`
- **Failure lookups**: Index on `failure.category`, `failure.resolved`
- **Audit trail**: Index on `audit_event.created_at` for time-range queries

---

## Migration Strategy

- Flyway versioned migrations in `monitoring-core/src/main/resources/db/migration/`
- Naming: `V{version}__{description}.sql`
- Seed data migration for groups, teams, and sample configuration
- Never modify existing migrations; always add new ones
