import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiFetch } from './client';
import type {
  AnalyticsSummary,
  AnalyticsTrends,
  ConfigurationEntry,
  FailureDetail,
  FailureSummary,
  GlobalDashboard,
  Group,
  GroupDashboard,
  JobSummary,
  LoginResponse,
  PageResponse,
  ProviderBuild,
  ReleaseReadiness,
  Team,
  TeamDashboard,
  TopFailures,
  UserProfile,
} from '../types/api';

export function useLogin() {
  return useMutation({
    mutationFn: (credentials: { username: string; password: string }) =>
      apiFetch<LoginResponse>('/api/v1/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }),
  });
}

export function useCurrentUser(enabled = true) {
  return useQuery({
    queryKey: ['auth', 'me'],
    queryFn: () => apiFetch<UserProfile>('/api/v1/auth/me'),
    enabled,
    retry: false,
  });
}

export function useGlobalDashboard() {
  return useQuery({
    queryKey: ['dashboard', 'global'],
    queryFn: () => apiFetch<GlobalDashboard>('/api/v1/dashboard/global'),
  });
}

export function useGroups(all = false) {
  return useQuery({
    queryKey: ['groups', { all }],
    queryFn: () => apiFetch<Group[]>(`/api/v1/groups${all ? '?all=true' : ''}`),
  });
}

export function useGroupDashboard(groupId: number) {
  return useQuery({
    queryKey: ['dashboard', 'group', groupId],
    queryFn: () => apiFetch<GroupDashboard>(`/api/v1/dashboard/group/${groupId}`),
    enabled: groupId > 0,
  });
}

export function useTeams(all = false) {
  return useQuery({
    queryKey: ['teams', { all }],
    queryFn: () => apiFetch<Team[]>(`/api/v1/teams${all ? '?all=true' : ''}`),
  });
}

export function useTeamDashboard(teamId: number) {
  return useQuery({
    queryKey: ['dashboard', 'team', teamId],
    queryFn: () => apiFetch<TeamDashboard>(`/api/v1/teams/${teamId}/dashboard`),
    enabled: teamId > 0,
  });
}

export function useFailures(params: Record<string, string | number | boolean | undefined> = {}) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      search.set(key, String(value));
    }
  });
  const query = search.toString();

  return useQuery({
    queryKey: ['failures', params],
    queryFn: () =>
      apiFetch<PageResponse<FailureSummary>>(`/api/v1/failures${query ? `?${query}` : ''}`),
  });
}

export function useFailure(failureId: number) {
  return useQuery({
    queryKey: ['failures', failureId],
    queryFn: () => apiFetch<FailureDetail>(`/api/v1/failures/${failureId}`),
    enabled: failureId > 0,
  });
}

export function useRunningBuilds() {
  return useQuery({
    queryKey: ['running-builds'],
    queryFn: () => apiFetch<ProviderBuild[]>('/api/v1/provider/running-builds'),
  });
}

export function useAnalyticsSummary() {
  return useQuery({
    queryKey: ['analytics', 'summary'],
    queryFn: () => apiFetch<AnalyticsSummary>('/api/v1/analytics/summary'),
  });
}

export function useAnalyticsTrends(days = 30) {
  return useQuery({
    queryKey: ['analytics', 'trends', days],
    queryFn: () => apiFetch<AnalyticsTrends>(`/api/v1/analytics/trends?days=${days}`),
  });
}

export function useTopFailures(limit = 5) {
  return useQuery({
    queryKey: ['analytics', 'top-failures', limit],
    queryFn: () => apiFetch<TopFailures>(`/api/v1/analytics/top-failures?limit=${limit}`),
  });
}

export function useReleaseReadiness() {
  return useQuery({
    queryKey: ['release-readiness'],
    queryFn: () => apiFetch<ReleaseReadiness>('/api/v1/dashboard/release-readiness'),
  });
}

export function useConfiguration() {
  return useQuery({
    queryKey: ['admin', 'config'],
    queryFn: () => apiFetch<ConfigurationEntry[]>('/api/v1/admin/config'),
  });
}

export function useUpdateConfiguration() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ key, value }: { key: string; value: string }) =>
      apiFetch<ConfigurationEntry>(`/api/v1/admin/config/${encodeURIComponent(key)}`, {
        method: 'PUT',
        body: JSON.stringify({ configValue: value }),
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin', 'config'] }),
  });
}

export function useCreateTeam() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: { groupId: number; name: string; email?: string }) =>
      apiFetch<Team>('/api/v1/admin/teams', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
    },
  });
}

export function useJobs(params: Record<string, string | number | boolean | undefined> = {}) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      search.set(key, String(value));
    }
  });
  search.set('size', '100');
  const query = search.toString();

  return useQuery({
    queryKey: ['jobs', params],
    queryFn: () => apiFetch<PageResponse<JobSummary>>(`/api/v1/jobs?${query}`),
  });
}

export function useMonitorJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: { teamId: number; externalId: string }) =>
      apiFetch<JobSummary>('/api/v1/admin/jobs', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs'] });
      queryClient.invalidateQueries({ queryKey: ['teams'] });
    },
  });
}

export function useRemoveMonitoredJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (externalId: string) =>
      apiFetch<JobSummary>(`/api/v1/admin/jobs/${encodeURIComponent(externalId)}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs'] });
      queryClient.invalidateQueries({ queryKey: ['teams'] });
    },
  });
}

export function useSyncJobsFromProvider() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiFetch<{ jobsSynced: number }>('/api/v1/admin/jobs/sync', {
        method: 'POST',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs'] });
    },
  });
}
