import CancelIcon from '@mui/icons-material/Cancel';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import SyncIcon from '@mui/icons-material/Sync';
import { Chip, type ChipProps } from '@mui/material';

const STATUS_CONFIG: Record<
  string,
  { color: ChipProps['color']; icon: React.ReactElement; label: string }
> = {
  SUCCESS: { color: 'success', icon: <CheckCircleIcon />, label: 'Success' },
  FAILURE: { color: 'error', icon: <ErrorIcon />, label: 'Failure' },
  RUNNING: { color: 'info', icon: <SyncIcon />, label: 'Running' },
  QUEUED: { color: 'default', icon: <HourglassEmptyIcon />, label: 'Queued' },
  CANCELLED: { color: 'warning', icon: <CancelIcon />, label: 'Cancelled' },
};

export function StatusBadge({ status }: { status: string }) {
  const config = STATUS_CONFIG[status] ?? {
    color: 'default' as const,
    icon: <HourglassEmptyIcon />,
    label: status,
  };

  return (
    <Chip
      size="small"
      color={config.color}
      icon={config.icon}
      label={config.label}
      aria-label={`Build status: ${config.label}`}
    />
  );
}
