import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AdminPage } from '../../features/admin/AdminPage';

export function AdminRoute() {
  const { user } = useAuth();
  if (user?.role !== 'ADMINISTRATOR') {
    return <Navigate to="/" replace />;
  }
  return <AdminPage />;
}
