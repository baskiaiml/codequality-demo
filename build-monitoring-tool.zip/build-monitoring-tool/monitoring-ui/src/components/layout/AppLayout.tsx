import DarkModeIcon from '@mui/icons-material/DarkMode';
import LightModeIcon from '@mui/icons-material/LightMode';
import LogoutIcon from '@mui/icons-material/Logout';
import {
  AppBar,
  Box,
  Button,
  Container,
  IconButton,
  Stack,
  Toolbar,
  Typography,
} from '@mui/material';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useThemeMode } from '../../theme/ThemeModeProvider';
import type { UserRole } from '../../types/api';

const NAV_ITEMS: Array<{ to: string; label: string; roles?: UserRole[] }> = [
  { to: '/', label: 'Global' },
  { to: '/groups', label: 'Groups' },
  { to: '/teams', label: 'Teams' },
  { to: '/failures', label: 'Failures' },
  { to: '/running', label: 'Running' },
  { to: '/analytics', label: 'Analytics' },
  { to: '/release-readiness', label: 'Release' },
  { to: '/admin', label: 'Admin', roles: ['ADMINISTRATOR'] },
];

export function AppLayout() {
  const { user, logout } = useAuth();
  const { mode, toggleMode } = useThemeMode();
  const navigate = useNavigate();

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <AppBar position="sticky" elevation={1}>
        <Toolbar sx={{ gap: 2, flexWrap: 'wrap' }}>
          <Typography variant="h6" sx={{ fontWeight: 700, mr: 2 }}>
            EOP
          </Typography>
          <Stack direction="row" spacing={0.5} sx={{ flexGrow: 1, flexWrap: 'wrap' }}>
            {NAV_ITEMS.filter(
              (item) => !item.roles || (user && item.roles.includes(user.role)),
            ).map((item) => (
              <Button
                key={item.to}
                component={NavLink}
                to={item.to}
                end={item.to === '/'}
                sx={{
                  color: 'inherit',
                  borderRadius: 0,
                  px: 1.5,
                  fontWeight: 500,
                  borderBottom: '2px solid transparent',
                  '&.active': {
                    fontWeight: 700,
                    borderBottomColor: '#fff',
                  },
                }}
              >
                {item.label}
              </Button>
            ))}
          </Stack>
          <Typography variant="body2">{user?.displayName}</Typography>
          <IconButton color="inherit" onClick={toggleMode} aria-label="Toggle theme">
            {mode === 'light' ? <DarkModeIcon /> : <LightModeIcon />}
          </IconButton>
          <IconButton
            color="inherit"
            onClick={() => {
              logout();
              navigate('/login');
            }}
            aria-label="Logout"
          >
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Container maxWidth="xl" sx={{ py: 3, flexGrow: 1 }}>
        <Outlet />
      </Container>
    </Box>
  );
}
