export type UserRole = 'ADMINISTRATOR' | 'MANAGER' | 'DEVELOPER' | 'VIEWER';

export interface UserProfile {
  username: string;
  displayName: string;
  email: string;
  role: UserRole;
  teamId: number | null;
}

export interface LoginResponse {
  token: string;
  expiresInMs: number;
  user: UserProfile;
}

export interface PageMetadata {
  number: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface PageResponse<T> {
  content: T[];
  page: PageMetadata;
}

export interface FailureSummary {
  id: number;
  buildExternalId: string;
  jobExternalId: string;
  jobName: string;
  category: string;
  severity: string | null;
  resolved: boolean;
  possibleOwner: string | null;
  analyzedAt: string;
}

export interface FailureDetail extends FailureSummary {
  teamId: number | null;
  teamName: string | null;
  confidenceScore: number | null;
  rootCause: string | null;
  suggestedFix: string | null;
  affectedModule: string | null;
  relevantClasses: string[];
  sqlObjects: string[];
  logSnippet: string | null;
  recommendation: string | null;
  developerImpact: string | null;
  resolvedAt: string | null;
}

export interface BuildSummary {
  id: number;
  externalId: string;
  jobExternalId: string;
  jobName: string;
  buildNumber: number;
  status: string;
  branch: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  durationMs: number | null;
  triggeredBy: string | null;
  buildUrl: string | null;
}

export interface ProviderBuild {
  id: string;
  jobId: string;
  buildNumber: number;
  status: string;
  branch: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  durationMs: number;
  triggeredBy: string | null;
  buildUrl: string | null;
}

export interface GroupStatusSummary {
  groupId: number;
  groupName: string;
  jobCount: number;
  activeFailures: number;
  successRatePercent: number;
}

export interface GlobalDashboard {
  totalJobs: number;
  runningBuilds: number;
  activeFailures: number;
  successRatePercent: number;
  recentFailures: FailureSummary[];
  runningBuildSummaries: BuildSummary[];
  failuresByCategory: Record<string, number>;
  groupSummaries: GroupStatusSummary[];
}

export interface Group {
  id: number;
  name: string;
  description: string | null;
  teamCount: number;
}

export interface GroupDashboard {
  groupId: number;
  groupName: string;
  teamCount: number;
  jobCount: number;
  activeFailures: number;
  successRatePercent: number;
  teams: TeamStatusSummary[];
}

export interface TeamStatusSummary {
  teamId: number;
  teamName: string;
  jobCount: number;
  activeFailures: number;
  successRatePercent: number;
}

export interface Team {
  id: number;
  name: string;
  groupId: number;
  groupName: string;
  email: string | null;
  enabled: boolean;
  jobCount: number;
}

export interface LatestBuildSummary {
  externalId: string;
  buildNumber: number;
  status: string;
  startedAt: string | null;
  durationMs: number | null;
}

export interface JobSummary {
  id: number;
  externalId: string;
  name: string;
  branch: string | null;
  buildType: string | null;
  enabled: boolean;
  pollingEnabled: boolean;
  teamId: number | null;
  teamName: string | null;
  latestBuild: LatestBuildSummary | null;
}

export interface TeamDashboard {
  teamId: number;
  teamName: string;
  groupName: string;
  email: string | null;
  jobCount: number;
  activeFailures: number;
  successRatePercent: number;
  jobs: JobSummary[];
  recentFailures: FailureSummary[];
}

export interface AnalyticsSummary {
  totalBuilds: number;
  successCount: number;
  failureCount: number;
  successRatePercent: number;
  mttrMinutes: number | null;
  mtbfHours: number | null;
  activeFailures: number;
  resolvedFailures: number;
  averageBuildDurationMs: number | null;
}

export interface TrendPoint {
  date: string;
  successCount: number;
  failureCount: number;
  successRatePercent: number;
}

export interface AnalyticsTrends {
  fromDate: string;
  toDate: string;
  dataPoints: TrendPoint[];
}

export interface RankingEntry {
  name: string;
  count: number;
}

export interface TopFailures {
  topFailingJobs: RankingEntry[];
  topFailingTeams: RankingEntry[];
  topFailureCategories: RankingEntry[];
}

export interface ReleaseReadiness {
  score: number;
  buildStatusScore: number;
  buildStabilityScore: number;
  outstandingFailures: number;
  blockedBuilds: number;
  environmentReadiness: number;
  deploymentReadiness: number;
}

export interface ConfigurationEntry {
  id: number;
  configKey: string;
  configValue: string;
  description: string | null;
}
