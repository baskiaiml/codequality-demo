import { createTheme, type PaletteMode } from '@mui/material/styles';

export function createAppTheme(mode: PaletteMode) {
  return createTheme({
    palette: {
      mode,
      primary: { main: '#1565C0' },
      error: { main: '#D32F2F' },
      success: { main: '#2E7D32' },
      warning: { main: '#ED6C02' },
      background: mode === 'light' ? { default: '#f4f6f8' } : { default: '#121212' },
    },
    typography: {
      fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
      h4: { fontWeight: 700 },
      h5: { fontWeight: 600 },
    },
    shape: { borderRadius: 10 },
    components: {
      MuiCard: {
        defaultProps: { elevation: 0 },
        styleOverrides: {
          root: {
            border: '1px solid',
            borderColor: mode === 'light' ? '#e0e0e0' : '#333',
          },
        },
      },
    },
  });
}
