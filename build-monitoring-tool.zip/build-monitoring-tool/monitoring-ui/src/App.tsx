import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AppLayout } from './components/layout/AppLayout';
import { ProtectedRoute } from './components/layout/ProtectedRoute';
import { ThemeModeProvider } from './theme/ThemeModeProvider';
import { LoginPage } from './features/auth/LoginPage';
import { GlobalDashboardPage } from './features/dashboard/GlobalDashboardPage';
import { GroupsPage } from './features/groups/GroupsPage';
import { GroupDetailPage } from './features/groups/GroupDetailPage';
import { TeamsPage } from './features/teams/TeamsPage';
import { TeamDetailPage } from './features/teams/TeamDetailPage';
import { FailuresPage } from './features/failures/FailuresPage';
import { FailureDetailPage } from './features/failures/FailureDetailPage';
import { RunningBuildsPage } from './features/running/RunningBuildsPage';
import { AnalyticsPage } from './features/analytics/AnalyticsPage';
import { ReleaseReadinessPage } from './features/release-readiness/ReleaseReadinessPage';
import { AdminRoute } from './components/layout/AdminRoute';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeModeProvider>
        <AuthProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route element={<ProtectedRoute />}>
                <Route element={<AppLayout />}>
                  <Route index element={<GlobalDashboardPage />} />
                  <Route path="groups" element={<GroupsPage />} />
                  <Route path="groups/:groupId" element={<GroupDetailPage />} />
                  <Route path="teams" element={<TeamsPage />} />
                  <Route path="teams/:teamId" element={<TeamDetailPage />} />
                  <Route path="failures" element={<FailuresPage />} />
                  <Route path="failures/:failureId" element={<FailureDetailPage />} />
                  <Route path="running" element={<RunningBuildsPage />} />
                  <Route path="analytics" element={<AnalyticsPage />} />
                  <Route path="release-readiness" element={<ReleaseReadinessPage />} />
                  <Route path="admin" element={<AdminRoute />} />
                </Route>
              </Route>
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </ThemeModeProvider>
    </QueryClientProvider>
  );
}
