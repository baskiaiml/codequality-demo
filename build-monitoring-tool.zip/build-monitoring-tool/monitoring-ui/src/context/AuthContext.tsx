import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { clearAuth, getStoredToken, getStoredUser, storeAuth } from '../api/client';
import { useCurrentUser, useLogin } from '../api/hooks';
import type { UserProfile } from '../types/api';

interface AuthContextValue {
  user: UserProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [user, setUser] = useState<UserProfile | null>(() => getStoredUser());
  const loginMutation = useLogin();
  const { isLoading } = useCurrentUser(!!token && !user);

  const login = useCallback(
    async (username: string, password: string) => {
      const response = await loginMutation.mutateAsync({ username, password });
      storeAuth(response.token, response.user);
      setToken(response.token);
      setUser(response.user);
    },
    [loginMutation],
  );

  const logout = useCallback(() => {
    clearAuth();
    setToken(null);
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      token,
      isAuthenticated: !!token,
      isLoading: isLoading && !!token && !user,
      login,
      logout,
    }),
    [user, token, isLoading, login, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
