import { Box, Grid, LinearProgress, Typography } from '@mui/material';
import { useReleaseReadiness } from '../../api/hooks';
import { MetricCard } from '../../components/common/MetricCard';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import { formatPercent } from '../../utils/format';

export function ReleaseReadinessPage() {
  const { data, isLoading, error } = useReleaseReadiness();

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load release readiness" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Release Readiness
      </Typography>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" gutterBottom>
          Score: {data.score.toFixed(1)} / 100
        </Typography>
        <LinearProgress
          variant="determinate"
          value={Math.min(data.score, 100)}
          sx={{ height: 12, borderRadius: 6 }}
          aria-label="Release readiness score"
        />
      </Box>
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Build Status" value={formatPercent(data.buildStatusScore)} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Build Stability" value={formatPercent(data.buildStabilityScore)} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Outstanding Failures" value={data.outstandingFailures} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Blocked Builds" value={data.blockedBuilds} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6 }}>
          <MetricCard title="Environment Readiness" value={formatPercent(data.environmentReadiness)} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6 }}>
          <MetricCard title="Deployment Readiness" value={formatPercent(data.deploymentReadiness)} />
        </Grid>
      </Grid>
    </Box>
  );
}
