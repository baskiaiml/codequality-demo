import { Box, Grid, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTeamDashboard } from '../../api/hooks';
import { MetricCard } from '../../components/common/MetricCard';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import { StatusBadge } from '../../components/common/StatusBadge';
import type { FailureSummary, JobSummary } from '../../types/api';
import { formatCategory, formatDateTime, formatPercent } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

export function TeamDetailPage() {
  const { teamId = '0' } = useParams();
  const navigate = useNavigate();
  const { data, isLoading, error } = useTeamDashboard(Number(teamId));

  const jobColumns = useMemo<ColDef<JobSummary>[]>(
    () => [
      { field: 'name', headerName: 'Job', flex: 1 },
      { field: 'branch', headerName: 'Branch' },
      {
        field: 'latestBuild.status',
        headerName: 'Latest Status',
        valueGetter: (p) => p.data?.latestBuild?.status ?? '—',
        cellRenderer: (params: { value: string }) =>
          params.value && params.value !== '—' ? <StatusBadge status={params.value} /> : '—',
      },
    ],
    [],
  );

  const failureColumns = useMemo<ColDef<FailureSummary>[]>(
    () => [
      { field: 'jobName', headerName: 'Job', flex: 1 },
      { field: 'category', headerName: 'Category', valueFormatter: (p) => formatCategory(p.value) },
      {
        field: 'analyzedAt',
        headerName: 'Analyzed',
        valueFormatter: (p) => formatDateTime(p.value),
      },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load team dashboard" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {data.teamName}
      </Typography>
      <Typography variant="body2" color="text.secondary" gutterBottom>
        {data.groupName} · {data.email ?? 'No email'}
      </Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <MetricCard title="Jobs" value={data.jobCount} />
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <MetricCard title="Active Failures" value={data.activeFailures} />
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <MetricCard title="Success Rate" value={formatPercent(data.successRatePercent)} />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Typography variant="h6" gutterBottom>
            Jobs
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 320 }}>
            <AgGridReact rowData={data.jobs} columnDefs={jobColumns} domLayout="autoHeight" suppressCellFocus />
          </Box>
        </Grid>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Typography variant="h6" gutterBottom>
            Recent Failures
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 320 }}>
            <AgGridReact
              rowData={data.recentFailures}
              columnDefs={failureColumns}
              domLayout="autoHeight"
              onRowClicked={(event) => navigate(`/failures/${event.data?.id}`)}
              suppressCellFocus
            />
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
