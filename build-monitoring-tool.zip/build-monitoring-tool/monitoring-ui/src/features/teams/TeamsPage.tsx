import { Box, Card, CardActionArea, CardContent, Chip, Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useTeams } from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';

export function TeamsPage() {
  const navigate = useNavigate();
  const { data, isLoading, error } = useTeams();

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load teams" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Teams
      </Typography>
      <Grid container spacing={2}>
        {data.map((team) => (
          <Grid key={team.id} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card>
              <CardActionArea onClick={() => navigate(`/teams/${team.id}`)}>
                <CardContent>
                  <Typography variant="h6">{team.name}</Typography>
                  <Chip size="small" label={team.groupName} sx={{ my: 1 }} />
                  <Typography variant="body2" color="text.secondary">
                    {team.email ?? 'No team email'}
                  </Typography>
                  <Typography variant="caption">{team.jobCount} jobs</Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
