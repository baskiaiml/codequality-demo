import { Box, Grid, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo } from 'react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useAnalyticsSummary, useAnalyticsTrends, useTopFailures } from '../../api/hooks';
import { MetricCard } from '../../components/common/MetricCard';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import type { RankingEntry } from '../../types/api';
import { formatDuration, formatPercent } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

export function AnalyticsPage() {
  const summary = useAnalyticsSummary();
  const trends = useAnalyticsTrends(30);
  const topFailures = useTopFailures(5);

  const rankingColumns = useMemo<ColDef<RankingEntry>[]>(
    () => [
      { field: 'name', headerName: 'Name', flex: 1 },
      { field: 'count', headerName: 'Count' },
    ],
    [],
  );

  if (summary.isLoading || trends.isLoading || topFailures.isLoading) return <LoadingState />;
  if (summary.error || trends.error || topFailures.error || !summary.data || !trends.data || !topFailures.data) {
    return <ErrorState message="Failed to load analytics" />;
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Analytics
      </Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Total Builds" value={summary.data.totalBuilds} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Success Rate" value={formatPercent(summary.data.successRatePercent)} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="MTTR"
            value={summary.data.mttrMinutes != null ? `${summary.data.mttrMinutes.toFixed(1)} min` : '—'}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="Avg Duration"
            value={formatDuration(summary.data.averageBuildDurationMs)}
          />
        </Grid>
      </Grid>

      <Typography variant="h6" gutterBottom>
        Build Trends (30 days)
      </Typography>
      <Box sx={{ height: 320, mb: 3 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={trends.data.dataPoints}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="successCount" stroke="#2E7D32" name="Success" />
            <Line type="monotone" dataKey="failureCount" stroke="#D32F2F" name="Failure" />
          </LineChart>
        </ResponsiveContainer>
      </Box>

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, md: 4 }}>
          <Typography variant="h6" gutterBottom>
            Top Failing Jobs
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 260 }}>
            <AgGridReact
              rowData={topFailures.data.topFailingJobs}
              columnDefs={rankingColumns}
              domLayout="autoHeight"
              suppressCellFocus
            />
          </Box>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Typography variant="h6" gutterBottom>
            Top Failing Teams
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 260 }}>
            <AgGridReact
              rowData={topFailures.data.topFailingTeams}
              columnDefs={rankingColumns}
              domLayout="autoHeight"
              suppressCellFocus
            />
          </Box>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Typography variant="h6" gutterBottom>
            Top Categories
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 260 }}>
            <AgGridReact
              rowData={topFailures.data.topFailureCategories}
              columnDefs={rankingColumns}
              domLayout="autoHeight"
              suppressCellFocus
            />
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
