import { Box, FormControlLabel, Stack, Switch, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFailures } from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import type { FailureSummary } from '../../types/api';
import { formatCategory, formatDateTime } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

export function FailuresPage() {
  const navigate = useNavigate();
  const [resolved, setResolved] = useState<boolean | undefined>(false);
  const { data, isLoading, error } = useFailures({ resolved, size: 50, sort: 'createdAt,desc' });

  const columns = useMemo<ColDef<FailureSummary>[]>(
    () => [
      { field: 'jobName', headerName: 'Job', flex: 1.2 },
      { field: 'category', headerName: 'Category', valueFormatter: (p) => formatCategory(p.value) },
      { field: 'severity', headerName: 'Severity' },
      { field: 'possibleOwner', headerName: 'Owner' },
      { field: 'resolved', headerName: 'Resolved' },
      {
        field: 'analyzedAt',
        headerName: 'Analyzed',
        valueFormatter: (p) => formatDateTime(p.value),
      },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load failures" />;

  return (
    <Box>
      <Stack direction="row" sx={{ justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h4">Failures</Typography>
        <FormControlLabel
          control={
            <Switch
              checked={resolved === undefined}
              onChange={(e) => setResolved(e.target.checked ? undefined : false)}
            />
          }
          label="Include resolved"
        />
      </Stack>
      <Box className="ag-theme-quartz" sx={{ height: 560 }}>
        <AgGridReact
          rowData={data.content}
          columnDefs={columns}
          pagination
          paginationPageSize={20}
          onRowClicked={(event) => navigate(`/failures/${event.data?.id}`)}
          suppressCellFocus
        />
      </Box>
    </Box>
  );
}
