import { Box, Card, CardContent, Chip, Grid, Typography } from '@mui/material';
import { useParams } from 'react-router-dom';
import { useFailure } from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import { formatCategory, formatDateTime } from '../../utils/format';

export function FailureDetailPage() {
  const { failureId = '0' } = useParams();
  const { data, isLoading, error } = useFailure(Number(failureId));

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load failure details" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Failure #{data.id}
      </Typography>
      <Typography variant="subtitle1" color="text.secondary" gutterBottom>
        {data.jobName} · {formatCategory(data.category)}
      </Typography>
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Analysis
              </Typography>
              <Chip label={data.resolved ? 'Resolved' : 'Active'} color={data.resolved ? 'success' : 'error'} sx={{ mb: 2 }} />
              <Typography variant="body2" gutterBottom>
                <strong>Confidence:</strong> {data.confidenceScore ?? '—'}
              </Typography>
              <Typography variant="body2" gutterBottom>
                <strong>Root cause:</strong> {data.rootCause ?? '—'}
              </Typography>
              <Typography variant="body2" gutterBottom>
                <strong>Suggested fix:</strong> {data.suggestedFix ?? '—'}
              </Typography>
              <Typography variant="body2" gutterBottom>
                <strong>Recommendation:</strong> {data.recommendation ?? '—'}
              </Typography>
              <Typography variant="body2">
                <strong>Analyzed:</strong> {formatDateTime(data.analyzedAt)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Log Snippet
              </Typography>
              <Box
                component="pre"
                sx={{
                  bgcolor: 'background.default',
                  p: 2,
                  borderRadius: 1,
                  overflow: 'auto',
                  maxHeight: 360,
                  fontSize: 12,
                  whiteSpace: 'pre-wrap',
                }}
              >
                {data.logSnippet ?? 'No log snippet available.'}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
