import { Box, Card, CardActionArea, CardContent, Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useGroups } from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';

export function GroupsPage() {
  const navigate = useNavigate();
  const { data, isLoading, error } = useGroups();

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load groups" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Groups
      </Typography>
      <Grid container spacing={2}>
        {data.map((group) => (
          <Grid key={group.id} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card>
              <CardActionArea onClick={() => navigate(`/groups/${group.id}`)}>
                <CardContent>
                  <Typography variant="h6">{group.name}</Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {group.description ?? 'No description'}
                  </Typography>
                  <Typography variant="caption">{group.teamCount} teams</Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
