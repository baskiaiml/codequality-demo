import { Box, Grid, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useGroupDashboard } from '../../api/hooks';
import { MetricCard } from '../../components/common/MetricCard';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import type { TeamStatusSummary } from '../../types/api';
import { formatPercent } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

export function GroupDetailPage() {
  const { groupId = '0' } = useParams();
  const navigate = useNavigate();
  const { data, isLoading, error } = useGroupDashboard(Number(groupId));

  const columns = useMemo<ColDef<TeamStatusSummary>[]>(
    () => [
      { field: 'teamName', headerName: 'Team', flex: 1 },
      { field: 'jobCount', headerName: 'Jobs' },
      { field: 'activeFailures', headerName: 'Active Failures' },
      {
        field: 'successRatePercent',
        headerName: 'Success %',
        valueFormatter: (p) => formatPercent(p.value),
      },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load group dashboard" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {data.groupName}
      </Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Teams" value={data.teamCount} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Jobs" value={data.jobCount} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Active Failures" value={data.activeFailures} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Success Rate" value={formatPercent(data.successRatePercent)} />
        </Grid>
      </Grid>
      <Typography variant="h6" gutterBottom>
        Teams
      </Typography>
      <Box className="ag-theme-quartz" sx={{ height: 360 }}>
        <AgGridReact
          rowData={data.teams}
          columnDefs={columns}
          domLayout="autoHeight"
          onRowClicked={(event) => navigate(`/teams/${event.data?.teamId}`)}
          suppressCellFocus
        />
      </Box>
    </Box>
  );
}
