import { Box, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo } from 'react';
import { useRunningBuilds } from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import { StatusBadge } from '../../components/common/StatusBadge';
import type { ProviderBuild } from '../../types/api';
import { formatDateTime, formatDuration } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

export function RunningBuildsPage() {
  const { data, isLoading, error } = useRunningBuilds();

  const columns = useMemo<ColDef<ProviderBuild>[]>(
    () => [
      { field: 'jobId', headerName: 'Job ID', flex: 1 },
      { field: 'buildNumber', headerName: 'Build #' },
      {
        field: 'status',
        headerName: 'Status',
        cellRenderer: (params: { value: string }) => <StatusBadge status={params.value} />,
      },
      { field: 'branch', headerName: 'Branch' },
      { field: 'triggeredBy', headerName: 'Triggered By' },
      {
        field: 'startedAt',
        headerName: 'Started',
        valueFormatter: (p) => formatDateTime(p.value),
      },
      {
        field: 'durationMs',
        headerName: 'Duration',
        valueFormatter: (p) => formatDuration(p.value),
      },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load running builds" />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Running Builds
      </Typography>
      <Box className="ag-theme-quartz" sx={{ height: 560 }}>
        <AgGridReact rowData={data} columnDefs={columns} pagination paginationPageSize={20} suppressCellFocus />
      </Box>
    </Box>
  );
}
