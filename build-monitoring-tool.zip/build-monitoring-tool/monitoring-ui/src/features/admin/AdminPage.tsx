import {
  Alert,
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef, ICellRendererParams } from 'ag-grid-community';
import { useMemo, useState } from 'react';
import {
  useConfiguration,
  useCreateTeam,
  useGroups,
  useJobs,
  useMonitorJob,
  useRemoveMonitoredJob,
  useSyncJobsFromProvider,
  useTeams,
  useUpdateConfiguration,
} from '../../api/hooks';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import type { ConfigurationEntry, JobSummary, Team } from '../../types/api';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

function ConfigurationPanel() {
  const { data, isLoading, error } = useConfiguration();
  const updateConfig = useUpdateConfiguration();
  const [selected, setSelected] = useState<ConfigurationEntry | null>(null);
  const [value, setValue] = useState('');

  const columns = useMemo<ColDef<ConfigurationEntry>[]>(
    () => [
      { field: 'configKey', headerName: 'Key', flex: 1 },
      { field: 'configValue', headerName: 'Value', flex: 1 },
      { field: 'description', headerName: 'Description', flex: 1.2 },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load configuration" />;

  return (
    <Box>
      <Box className="ag-theme-quartz" sx={{ height: 360, mb: 3 }}>
        <AgGridReact
          rowData={data}
          columnDefs={columns}
          onRowClicked={(event) => {
            setSelected(event.data ?? null);
            setValue(event.data?.configValue ?? '');
          }}
          suppressCellFocus
        />
      </Box>
      {selected && (
        <Stack spacing={2} sx={{ maxWidth: 640 }}>
          <Typography variant="h6">Edit {selected.configKey}</Typography>
          <TextField
            label="Value"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            fullWidth
            multiline
            minRows={2}
          />
          {updateConfig.isError && <Alert severity="error">Update failed</Alert>}
          {updateConfig.isSuccess && <Alert severity="success">Configuration updated</Alert>}
          <Button
            variant="contained"
            disabled={updateConfig.isPending}
            onClick={() => updateConfig.mutate({ key: selected.configKey, value })}
          >
            Save
          </Button>
        </Stack>
      )}
    </Box>
  );
}

function TeamsPanel() {
  const { data: groups, isLoading: groupsLoading } = useGroups(true);
  const { data: teams, isLoading: teamsLoading, error } = useTeams(true);
  const createTeam = useCreateTeam();
  const [groupId, setGroupId] = useState<number>(0);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const columns = useMemo<ColDef<Team>[]>(
    () => [
      { field: 'name', headerName: 'Team', flex: 1 },
      { field: 'groupName', headerName: 'Group', flex: 1 },
      { field: 'email', headerName: 'Email', flex: 1.2 },
      { field: 'jobCount', headerName: 'Jobs', width: 100 },
      {
        field: 'enabled',
        headerName: 'Enabled',
        width: 110,
        valueFormatter: (params) => (params.value ? 'Yes' : 'No'),
      },
    ],
    [],
  );

  if (groupsLoading || teamsLoading) return <LoadingState />;
  if (error || !teams || !groups) return <ErrorState message="Failed to load teams" />;

  return (
    <Stack spacing={3}>
      <Typography variant="body2" color="text.secondary">
        Create teams before adding build jobs. Teams cannot be removed once created.
      </Typography>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ maxWidth: 960 }}>
        <FormControl fullWidth>
          <InputLabel id="group-select-label">Group</InputLabel>
          <Select
            labelId="group-select-label"
            label="Group"
            value={groupId || ''}
            onChange={(e) => setGroupId(Number(e.target.value))}
          >
            {groups.map((group) => (
              <MenuItem key={group.id} value={group.id}>
                {group.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <TextField label="Team name" value={name} onChange={(e) => setName(e.target.value)} fullWidth />
        <TextField
          label="Email (optional)"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
        />
        <Button
          variant="contained"
          disabled={!groupId || !name.trim() || createTeam.isPending}
          onClick={() =>
            createTeam.mutate(
              { groupId, name: name.trim(), email: email.trim() || undefined },
              {
                onSuccess: () => {
                  setName('');
                  setEmail('');
                },
              },
            )
          }
          sx={{ minWidth: 140 }}
        >
          Add Team
        </Button>
      </Stack>
      {createTeam.isError && <Alert severity="error">Failed to create team</Alert>}
      {createTeam.isSuccess && <Alert severity="success">Team created</Alert>}
      <Box className="ag-theme-quartz" sx={{ height: 360 }}>
        <AgGridReact rowData={teams} columnDefs={columns} suppressCellFocus />
      </Box>
    </Stack>
  );
}

function MonitoredJobsPanel() {
  const { data: teams, isLoading: teamsLoading } = useTeams(true);
  const { data: monitoredJobs, isLoading: monitoredLoading } = useJobs({ pollingEnabled: true });
  const { data: availableJobs, isLoading: availableLoading } = useJobs({ pollingEnabled: false });
  const monitorJob = useMonitorJob();
  const removeJob = useRemoveMonitoredJob();
  const syncJobs = useSyncJobsFromProvider();
  const [teamId, setTeamId] = useState<number>(0);
  const [externalId, setExternalId] = useState('');

  const monitoredColumns = useMemo<ColDef<JobSummary>[]>(
    () => [
      { field: 'name', headerName: 'Job', flex: 1 },
      { field: 'externalId', headerName: 'External ID', flex: 1 },
      { field: 'teamName', headerName: 'Team', flex: 1 },
      {
        headerName: 'Actions',
        width: 140,
        cellRenderer: (params: ICellRendererParams<JobSummary>) => (
          <Button
            size="small"
            color="error"
            disabled={removeJob.isPending}
            onClick={() => params.data && removeJob.mutate(params.data.externalId)}
          >
            Remove
          </Button>
        ),
      },
    ],
    [removeJob.isPending],
  );

  const availableColumns = useMemo<ColDef<JobSummary>[]>(
    () => [
      { field: 'name', headerName: 'Job', flex: 1 },
      { field: 'externalId', headerName: 'External ID', flex: 1 },
      { field: 'buildType', headerName: 'Build Type', flex: 1 },
    ],
    [],
  );

  if (teamsLoading || monitoredLoading || availableLoading) return <LoadingState />;
  if (!teams) return <ErrorState message="Failed to load teams" />;

  const hasTeams = teams.length > 0;

  return (
    <Stack spacing={3}>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ alignItems: { md: 'center' } }}>
        <Typography variant="body2" color="text.secondary" sx={{ flexGrow: 1 }}>
          Select a team, then add a build job to monitoring. Sync from TeamCity/mock provider to
          discover available jobs first.
        </Typography>
        <Button variant="outlined" disabled={syncJobs.isPending} onClick={() => syncJobs.mutate()}>
          Sync Jobs from Provider
        </Button>
      </Stack>
      {syncJobs.isSuccess && (
        <Alert severity="success">Synced {syncJobs.data?.jobsSynced ?? 0} jobs from provider</Alert>
      )}
      {syncJobs.isError && <Alert severity="error">Provider sync failed</Alert>}
      {!hasTeams && (
        <Alert severity="warning">Create at least one team before adding build jobs.</Alert>
      )}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ maxWidth: 960 }}>
        <FormControl fullWidth disabled={!hasTeams}>
          <InputLabel id="team-select-label">Team</InputLabel>
          <Select
            labelId="team-select-label"
            label="Team"
            value={teamId || ''}
            onChange={(e) => setTeamId(Number(e.target.value))}
          >
            {teams.map((team) => (
              <MenuItem key={team.id} value={team.id}>
                {team.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl fullWidth disabled={!hasTeams}>
          <InputLabel id="job-select-label">Build job</InputLabel>
          <Select
            labelId="job-select-label"
            label="Build job"
            value={externalId}
            onChange={(e) => setExternalId(String(e.target.value))}
          >
            {(availableJobs?.content ?? []).map((job) => (
              <MenuItem key={job.externalId} value={job.externalId}>
                {job.name} ({job.externalId})
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          variant="contained"
          disabled={!teamId || !externalId || monitorJob.isPending}
          onClick={() =>
            monitorJob.mutate(
              { teamId, externalId },
              {
                onSuccess: () => setExternalId(''),
              },
            )
          }
          sx={{ minWidth: 160 }}
        >
          Add to Monitoring
        </Button>
      </Stack>
      {monitorJob.isError && <Alert severity="error">Failed to add job to monitoring</Alert>}
      {monitorJob.isSuccess && <Alert severity="success">Job added to monitoring</Alert>}
      {removeJob.isError && <Alert severity="error">Failed to remove job from monitoring</Alert>}
      <Typography variant="h6">Monitored Jobs</Typography>
      <Box className="ag-theme-quartz" sx={{ height: 280 }}>
        <AgGridReact
          rowData={monitoredJobs?.content ?? []}
          columnDefs={monitoredColumns}
          suppressCellFocus
        />
      </Box>
      <Typography variant="h6">Available Jobs (not monitored)</Typography>
      <Box className="ag-theme-quartz" sx={{ height: 240 }}>
        <AgGridReact
          rowData={availableJobs?.content ?? []}
          columnDefs={availableColumns}
          suppressCellFocus
        />
      </Box>
    </Stack>
  );
}

export function AdminPage() {
  const [tab, setTab] = useState(0);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Administration
      </Typography>
      <Tabs value={tab} onChange={(_, value) => setTab(value)} sx={{ mb: 3 }}>
        <Tab label="Configuration" />
        <Tab label="Teams" />
        <Tab label="Monitored Jobs" />
      </Tabs>
      {tab === 0 && <ConfigurationPanel />}
      {tab === 1 && <TeamsPanel />}
      {tab === 2 && <MonitoredJobsPanel />}
    </Box>
  );
}
