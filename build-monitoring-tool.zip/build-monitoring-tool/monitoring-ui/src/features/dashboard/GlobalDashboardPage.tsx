import { Box, Grid, Typography } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useGlobalDashboard } from '../../api/hooks';
import { MetricCard } from '../../components/common/MetricCard';
import { ErrorState, LoadingState } from '../../components/common/PageStates';
import { StatusBadge } from '../../components/common/StatusBadge';
import type { BuildSummary, FailureSummary } from '../../types/api';
import { formatCategory, formatDateTime, formatPercent } from '../../utils/format';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

const PIE_COLORS = ['#1565C0', '#D32F2F', '#ED6C02', '#2E7D32', '#7B1FA2', '#455A64'];

export function GlobalDashboardPage() {
  const navigate = useNavigate();
  const { data, isLoading, error } = useGlobalDashboard();

  const failureColumns = useMemo<ColDef<FailureSummary>[]>(
    () => [
      { field: 'jobName', headerName: 'Job', flex: 1 },
      { field: 'category', headerName: 'Category', valueFormatter: (p) => formatCategory(p.value) },
      { field: 'severity', headerName: 'Severity' },
      {
        field: 'analyzedAt',
        headerName: 'Analyzed',
        valueFormatter: (p) => formatDateTime(p.value),
      },
    ],
    [],
  );

  const runningColumns = useMemo<ColDef<BuildSummary>[]>(
    () => [
      { field: 'jobName', headerName: 'Job', flex: 1 },
      { field: 'buildNumber', headerName: 'Build #' },
      {
        field: 'status',
        headerName: 'Status',
        cellRenderer: (params: { value: string }) => <StatusBadge status={params.value} />,
      },
      {
        field: 'startedAt',
        headerName: 'Started',
        valueFormatter: (p) => formatDateTime(p.value),
      },
    ],
    [],
  );

  if (isLoading) return <LoadingState />;
  if (error || !data) return <ErrorState message="Failed to load global dashboard" />;

  const categoryData = Object.entries(data.failuresByCategory).map(([name, value]) => ({
    name: formatCategory(name),
    value,
  }));

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Global Dashboard
      </Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Total Jobs" value={data.totalJobs} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Running Builds" value={data.runningBuilds} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Active Failures" value={data.activeFailures} />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard title="Success Rate" value={formatPercent(data.successRatePercent)} />
        </Grid>
      </Grid>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 7 }}>
          <Typography variant="h6" gutterBottom>
            Build Status by Group
          </Typography>
          <Box sx={{ height: 280 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.groupSummaries}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="groupName" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="successRatePercent" fill="#1565C0" name="Success %" />
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </Grid>
        <Grid size={{ xs: 12, lg: 5 }}>
          <Typography variant="h6" gutterBottom>
            Failure Categories
          </Typography>
          <Box sx={{ height: 280 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={categoryData} dataKey="value" nameKey="name" outerRadius={100} label>
                  {categoryData.map((entry, index) => (
                    <Cell key={entry.name} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Box>
        </Grid>
      </Grid>

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Typography variant="h6" gutterBottom>
            Recent Failures
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 320 }}>
            <AgGridReact
              rowData={data.recentFailures}
              columnDefs={failureColumns}
              domLayout="autoHeight"
              onRowClicked={(event) => navigate(`/failures/${event.data?.id}`)}
              suppressCellFocus
            />
          </Box>
        </Grid>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Typography variant="h6" gutterBottom>
            Running Builds
          </Typography>
          <Box className="ag-theme-quartz" sx={{ height: 320 }}>
            <AgGridReact
              rowData={data.runningBuildSummaries}
              columnDefs={runningColumns}
              domLayout="autoHeight"
              suppressCellFocus
            />
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
