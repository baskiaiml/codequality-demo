package com.cognizant.eop.api.audit;

/**
 * Canonical audit event types for configuration and security actions.
 */
public enum AuditEventType {
    USER_LOGIN,
    USER_LOGIN_FAILED,
    CONFIG_UPDATED,
    SCHEDULER_TRIGGERED,
    JOB_SYNC,
    JOB_MONITORING_ENABLED,
    JOB_MONITORING_DISABLED,
    TEAM_CREATED,
    NOTIFICATION_RULE_VIEWED
}
