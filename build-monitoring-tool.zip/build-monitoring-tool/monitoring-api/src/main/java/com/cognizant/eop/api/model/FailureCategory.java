package com.cognizant.eop.api.model;

/**
 * Classification categories for build failures.
 * The architecture supports unlimited future classifiers via knowledge base patterns.
 */
public enum FailureCategory {
    COMPILATION_ERROR,
    MERGE_CONFLICT,
    JUNIT_FAILURE,
    INTEGRATION_TEST_FAILURE,
    LIQUIBASE_FAILURE,
    ORACLE_SQL_FAILURE,
    GRADLE_FAILURE,
    MAVEN_FAILURE,
    DOCKER_FAILURE,
    DEPLOYMENT_FAILURE,
    GIT_FAILURE,
    INFRASTRUCTURE_FAILURE,
    ENVIRONMENT_FAILURE,
    NETWORK_FAILURE,
    TIMEOUT,
    UNKNOWN_FAILURE
}
