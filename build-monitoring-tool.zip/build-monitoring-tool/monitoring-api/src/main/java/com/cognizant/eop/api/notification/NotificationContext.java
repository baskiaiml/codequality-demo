package com.cognizant.eop.api.notification;

/**
 * Context data available when rendering notification templates.
 */
public record NotificationContext(
        String jobName,
        String jobExternalId,
        String buildExternalId,
        int buildNumber,
        String buildUrl,
        String branch,
        String failureCategory,
        String rootCause,
        String suggestedFix,
        String possibleOwner,
        String logSnippet,
        String teamName,
        String teamEmail,
        int resolvedFailureCount
) {}
