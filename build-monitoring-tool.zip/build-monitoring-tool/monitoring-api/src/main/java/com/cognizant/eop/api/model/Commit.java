package com.cognizant.eop.api.model;

import java.time.Instant;

/**
 * Represents a source control commit associated with a build.
 *
 * @param hash      commit hash
 * @param author    commit author username
 * @param message   commit message
 * @param timestamp when the commit was created
 */
public record Commit(
        String hash,
        String author,
        String message,
        Instant timestamp
) {}
