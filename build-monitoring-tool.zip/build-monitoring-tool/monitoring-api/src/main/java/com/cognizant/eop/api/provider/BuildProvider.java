package com.cognizant.eop.api.provider;

import com.cognizant.eop.api.model.Build;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.Commit;
import com.cognizant.eop.api.model.Job;

import java.util.List;

/**
 * Port interface for CI/CD build system integration.
 * All build system access must go through this abstraction.
 * Implementations: {@code MockBuildProvider} (development), {@code TeamCityBuildProvider} (production).
 */
public interface BuildProvider {

    /**
     * Returns all configured jobs available for monitoring.
     */
    List<Job> getConfiguredJobs();

    /**
     * Returns the most recent build for the given job.
     *
     * @param jobId the job identifier
     * @return the latest build, or {@code null} if no builds exist
     */
    Build getLatestBuild(String jobId);

    /**
     * Returns build history for the given job, ordered by build number descending.
     *
     * @param jobId the job identifier
     * @return list of builds (may be empty)
     */
    List<Build> getBuildHistory(String jobId);

    /**
     * Returns the console log output for the given build.
     *
     * @param buildId the build identifier
     * @return the build log content
     */
    BuildLog getBuildLog(String buildId);

    /**
     * Returns source control changes included in the given build.
     *
     * @param buildId the build identifier
     * @return list of commits (may be empty)
     */
    List<Commit> getChanges(String buildId);

    /**
     * Returns all currently running builds across all jobs.
     */
    List<Build> getRunningBuilds();
}
