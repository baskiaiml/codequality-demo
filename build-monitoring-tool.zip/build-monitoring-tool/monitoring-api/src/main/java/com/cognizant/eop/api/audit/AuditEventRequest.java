package com.cognizant.eop.api.audit;

import java.util.Map;

/**
 * Immutable audit event payload passed to {@link AuditRecorder}.
 */
public record AuditEventRequest(
        AuditEventType eventType,
        String entityType,
        String entityId,
        String actor,
        Map<String, Object> details
) {
}
