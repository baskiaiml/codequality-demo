package com.cognizant.eop.api.model;

import java.time.Instant;

/**
 * Represents a single CI/CD build execution.
 *
 * @param id          unique identifier in the provider system
 * @param jobId       reference to the parent job
 * @param buildNumber sequential build number within the job
 * @param status      current build status
 * @param branch      branch that triggered the build
 * @param startedAt   when the build started (null if queued)
 * @param finishedAt  when the build finished (null if running/queued)
 * @param durationMs  total build duration in milliseconds
 * @param triggeredBy username of the person who triggered the build
 * @param buildUrl    URL to view the build in the CI/CD system
 */
public record Build(
        String id,
        String jobId,
        int buildNumber,
        BuildStatus status,
        String branch,
        Instant startedAt,
        Instant finishedAt,
        long durationMs,
        String triggeredBy,
        String buildUrl
) {
    public boolean isFinished() {
        return status == BuildStatus.SUCCESS
                || status == BuildStatus.FAILURE
                || status == BuildStatus.CANCELLED;
    }

    public boolean isFailed() {
        return status == BuildStatus.FAILURE;
    }

    public boolean isRunning() {
        return status == BuildStatus.RUNNING;
    }
}
