package com.cognizant.eop.api.model;

/**
 * Represents the lifecycle status of a CI/CD build.
 */
public enum BuildStatus {
    SUCCESS,
    FAILURE,
    RUNNING,
    QUEUED,
    CANCELLED,
    UNKNOWN
}
