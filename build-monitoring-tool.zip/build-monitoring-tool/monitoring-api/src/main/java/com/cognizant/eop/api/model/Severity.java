package com.cognizant.eop.api.model;

/**
 * Severity levels for classified build failures.
 */
public enum Severity {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW
}
