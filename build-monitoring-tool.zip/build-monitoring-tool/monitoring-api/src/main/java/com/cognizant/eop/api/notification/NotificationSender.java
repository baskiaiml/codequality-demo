package com.cognizant.eop.api.notification;

/**
 * Port interface for sending notifications through a specific channel.
 */
public interface NotificationSender {

    NotificationChannel channel();

    void send(NotificationMessage message);
}
