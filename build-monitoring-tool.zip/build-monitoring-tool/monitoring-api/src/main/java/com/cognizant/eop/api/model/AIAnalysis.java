package com.cognizant.eop.api.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * Result of AI-powered build failure analysis.
 *
 * @param failureType      classified failure category
 * @param confidenceScore  confidence level (0.00–100.00)
 * @param rootCause        human-readable root cause description
 * @param suggestedFix     actionable fix recommendation
 * @param affectedModule   module or package affected by the failure
 * @param possibleOwner    developer likely responsible
 * @param relevantClasses  Java classes involved in the failure
 * @param sqlObjects       SQL tables or procedures involved
 * @param logSnippet       relevant excerpt from the build log
 * @param recommendation   broader recommendation for the team
 * @param developerImpact  description of impact on developers
 * @param severity         estimated severity of the failure
 */
public record AIAnalysis(
        FailureCategory failureType,
        BigDecimal confidenceScore,
        String rootCause,
        String suggestedFix,
        String affectedModule,
        String possibleOwner,
        List<String> relevantClasses,
        List<String> sqlObjects,
        String logSnippet,
        String recommendation,
        String developerImpact,
        Severity severity
) {}
