package com.cognizant.eop.api.notification;

/**
 * Renders notification templates into subject/body pairs.
 */
public interface NotificationTemplateRenderer {

    RenderedNotification render(String templateName, NotificationContext context);

    record RenderedNotification(String subject, String body) {}
}
