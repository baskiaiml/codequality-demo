package com.cognizant.eop.api.notification;

/**
 * Delivery channel for notifications.
 */
public enum NotificationChannel {
    EMAIL
}
