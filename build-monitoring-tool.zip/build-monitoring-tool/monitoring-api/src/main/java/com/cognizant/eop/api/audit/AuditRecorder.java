package com.cognizant.eop.api.audit;

/**
 * Port for persisting audit trail entries.
 */
public interface AuditRecorder {

    void record(AuditEventRequest event);
}
