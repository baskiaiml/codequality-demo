package com.cognizant.eop.api.model;

/**
 * Represents the console output log of a CI/CD build.
 *
 * @param buildId unique identifier of the build this log belongs to
 * @param content raw log content
 */
public record BuildLog(
        String buildId,
        String content
) {}
