package com.cognizant.eop.api.notification;

/**
 * Types of events that trigger notifications.
 */
public enum NotificationEventType {
    BUILD_FAILURE,
    BUILD_RECOVERY,
    ROOT_CAUSE_CHANGED
}
