package com.cognizant.eop.api.notification;

/**
 * Outbound notification message ready to send.
 */
public record NotificationMessage(
        NotificationChannel channel,
        String recipient,
        String subject,
        String body,
        NotificationEventType eventType
) {}
