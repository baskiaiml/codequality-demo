package com.cognizant.eop.api.model;

import java.time.Instant;

/**
 * Represents a configured CI/CD job in the build system.
 *
 * @param id          unique identifier in the provider system
 * @param name        human-readable job name
 * @param buildTypeId provider-specific build type identifier
 * @param branch      default branch monitored by this job
 * @param enabled     whether the job is active for polling
 */
public record Job(
        String id,
        String name,
        String buildTypeId,
        String branch,
        boolean enabled
) {}
