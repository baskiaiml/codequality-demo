package com.cognizant.eop.api.security;

/**
 * Platform roles aligned with {@code PROJECT_CONSTITUTION.md}.
 */
public enum UserRole {
    ADMINISTRATOR,
    MANAGER,
    DEVELOPER,
    VIEWER
}
