package com.cognizant.eop.api.analyzer;

import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.api.model.BuildLog;

/**
 * Port interface for AI-powered build failure analysis.
 * Implementations: {@code RuleBasedAnalyzer} (default), future LLM-based analyzers.
 */
public interface AIAnalyzer {

    /**
     * Analyzes a build log and returns a structured failure analysis.
     *
     * @param buildLog the build console output to analyze
     * @return structured analysis with classification, root cause, and recommendations
     */
    AIAnalysis analyze(BuildLog buildLog);
}
