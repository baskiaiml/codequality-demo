package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.BuildMetricSnapshot;
import com.cognizant.eop.analytics.model.FailureMetricSnapshot;
import com.cognizant.eop.api.model.BuildStatus;
import com.cognizant.eop.api.model.FailureCategory;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class EngineeringMetricsCalculatorTest {

    @Test
    void compute_calculatesSuccessRateAndMttr() {
        Instant now = Instant.parse("2026-06-29T10:00:00Z");

        List<BuildMetricSnapshot> builds = List.of(
                snapshot("build-1", BuildStatus.SUCCESS, now, 1000L),
                snapshot("build-2", BuildStatus.FAILURE, now, 2000L),
                snapshot("build-3", BuildStatus.SUCCESS, now, 3000L)
        );

        List<FailureMetricSnapshot> failures = List.of(
                failure(1L, now.minus(120, ChronoUnit.MINUTES), now.minus(60, ChronoUnit.MINUTES), true),
                failure(2L, now.minus(30, ChronoUnit.MINUTES), null, false)
        );

        EngineeringMetricsCalculator.EngineeringMetrics metrics =
                EngineeringMetricsCalculator.compute(builds, failures);

        assertEquals(3, metrics.totalBuilds());
        assertEquals(2, metrics.successCount());
        assertEquals(1, metrics.failureCount());
        assertEquals(66.7, metrics.successRatePercent());
        assertEquals(60.0, metrics.mttrMinutes());
        assertNotNull(metrics.mtbfHours());
        assertEquals(1, metrics.activeFailures());
        assertEquals(1, metrics.resolvedFailures());
        assertEquals(2000.0, metrics.averageBuildDurationMs());
    }

    @Test
    void compute_returnsNullMttrWhenNoResolvedFailures() {
        EngineeringMetricsCalculator.EngineeringMetrics metrics = EngineeringMetricsCalculator.compute(
                List.of(snapshot("build-1", BuildStatus.FAILURE, Instant.now(), 1000L)),
                List.of(failure(1L, Instant.now(), null, false))
        );

        assertNull(metrics.mttrMinutes());
        assertNull(metrics.mtbfHours());
    }

    private BuildMetricSnapshot snapshot(String id, BuildStatus status, Instant startedAt, Long durationMs) {
        return new BuildMetricSnapshot(id, "job-1", "Job One", "Alpha Team", status, startedAt, durationMs);
    }

    private FailureMetricSnapshot failure(Long id, Instant createdAt, Instant resolvedAt, boolean resolved) {
        return new FailureMetricSnapshot(
                id, "build-" + id, "job-1", "Job One", "Alpha Team",
                FailureCategory.COMPILATION_ERROR, resolved, createdAt, resolvedAt
        );
    }
}
