package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.JobLatestStatusSnapshot;
import com.cognizant.eop.api.model.BuildStatus;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReleaseReadinessCalculatorTest {

    @Test
    void compute_balancesPassingJobsAndStability() {
        List<JobLatestStatusSnapshot> jobs = List.of(
                new JobLatestStatusSnapshot("job-1", "Job 1", "Alpha", BuildStatus.SUCCESS),
                new JobLatestStatusSnapshot("job-2", "Job 2", "Beta", BuildStatus.SUCCESS),
                new JobLatestStatusSnapshot("job-3", "Job 3", "Gamma", BuildStatus.FAILURE)
        );

        ReleaseReadinessCalculator.ReleaseReadinessScore score =
                ReleaseReadinessCalculator.compute(jobs, 1, 75.0);

        assertTrue(score.score() > 0);
        assertEquals(66.7, score.buildStatusScore());
        assertEquals(75.0, score.buildStabilityScore());
        assertEquals(1, score.outstandingFailures());
        assertEquals(1, score.blockedBuilds());
    }
}
