package com.cognizant.eop.analytics.model;

import com.cognizant.eop.api.model.BuildStatus;

import java.time.Instant;

public record BuildMetricSnapshot(
        String buildExternalId,
        String jobExternalId,
        String jobName,
        String teamName,
        BuildStatus status,
        Instant startedAt,
        Long durationMs
) {}
