package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.FailureMetricSnapshot;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class TopFailuresAggregator {

    private TopFailuresAggregator() {
    }

    public static TopFailuresResult aggregate(List<FailureMetricSnapshot> failures, int limit) {
        return new TopFailuresResult(
                topByJob(failures, limit),
                topByTeam(failures, limit),
                topByCategory(failures, limit)
        );
    }

    private static List<RankingEntry> topByJob(List<FailureMetricSnapshot> failures, int limit) {
        return failures.stream()
                .collect(Collectors.groupingBy(FailureMetricSnapshot::jobName, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(limit)
                .map(entry -> new RankingEntry(entry.getKey(), entry.getValue()))
                .toList();
    }

    private static List<RankingEntry> topByTeam(List<FailureMetricSnapshot> failures, int limit) {
        Map<String, Long> counts = new LinkedHashMap<>();
        for (FailureMetricSnapshot failure : failures) {
            String team = failure.teamName() == null || failure.teamName().isBlank()
                    ? "Unassigned"
                    : failure.teamName();
            counts.merge(team, 1L, Long::sum);
        }
        return counts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(limit)
                .map(entry -> new RankingEntry(entry.getKey(), entry.getValue()))
                .toList();
    }

    private static List<RankingEntry> topByCategory(List<FailureMetricSnapshot> failures, int limit) {
        return failures.stream()
                .collect(Collectors.groupingBy(f -> f.category().name(), Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(limit)
                .map(entry -> new RankingEntry(entry.getKey(), entry.getValue()))
                .toList();
    }

    public record RankingEntry(String name, long count) {}

    public record TopFailuresResult(
            List<RankingEntry> topFailingJobs,
            List<RankingEntry> topFailingTeams,
            List<RankingEntry> topFailureCategories
    ) {}
}
