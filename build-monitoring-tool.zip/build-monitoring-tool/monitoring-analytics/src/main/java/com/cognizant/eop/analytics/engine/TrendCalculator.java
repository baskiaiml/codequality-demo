package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.BuildMetricSnapshot;
import com.cognizant.eop.api.model.BuildStatus;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TrendCalculator {

    private TrendCalculator() {
    }

    public static List<TrendDataPoint> computeDailyTrends(List<BuildMetricSnapshot> builds, LocalDate from, LocalDate to) {
        Map<LocalDate, int[]> countsByDate = new LinkedHashMap<>();

        LocalDate cursor = from;
        while (!cursor.isAfter(to)) {
            countsByDate.put(cursor, new int[] {0, 0});
            cursor = cursor.plusDays(1);
        }

        for (BuildMetricSnapshot build : builds) {
            if (build.startedAt() == null) {
                continue;
            }
            LocalDate date = build.startedAt().atZone(ZoneOffset.UTC).toLocalDate();
            if (date.isBefore(from) || date.isAfter(to)) {
                continue;
            }
            int[] counts = countsByDate.computeIfAbsent(date, ignored -> new int[] {0, 0});
            if (build.status() == BuildStatus.SUCCESS) {
                counts[0]++;
            } else if (build.status() == BuildStatus.FAILURE) {
                counts[1]++;
            }
        }

        List<TrendDataPoint> points = new ArrayList<>();
        countsByDate.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    int successes = entry.getValue()[0];
                    int failures = entry.getValue()[1];
                    int total = successes + failures;
                    double successRate = total == 0 ? 0.0 : round(successes * 100.0 / total);
                    points.add(new TrendDataPoint(entry.getKey(), successes, failures, successRate));
                });
        return points;
    }

    private static double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    public record TrendDataPoint(
            LocalDate date,
            int successCount,
            int failureCount,
            double successRatePercent
    ) {}
}
