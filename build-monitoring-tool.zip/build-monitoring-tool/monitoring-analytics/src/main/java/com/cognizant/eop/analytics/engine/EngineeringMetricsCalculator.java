package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.BuildMetricSnapshot;
import com.cognizant.eop.analytics.model.FailureMetricSnapshot;
import com.cognizant.eop.api.model.BuildStatus;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.OptionalDouble;

public final class EngineeringMetricsCalculator {

    private EngineeringMetricsCalculator() {
    }

    public static EngineeringMetrics compute(List<BuildMetricSnapshot> builds, List<FailureMetricSnapshot> failures) {
        long totalBuilds = builds.size();
        long successCount = builds.stream().filter(b -> b.status() == BuildStatus.SUCCESS).count();
        long failureCount = builds.stream().filter(b -> b.status() == BuildStatus.FAILURE).count();

        double successRate = totalBuilds == 0 ? 0.0 : round(successCount * 100.0 / totalBuilds);

        long activeFailures = failures.stream().filter(f -> !f.resolved()).count();
        long resolvedFailures = failures.stream().filter(FailureMetricSnapshot::resolved).count();

        OptionalDouble averageOptional = builds.stream()
                .filter(b -> b.durationMs() != null && b.durationMs() > 0)
                .mapToLong(BuildMetricSnapshot::durationMs)
                .average();
        Double averageBuildDurationMs = averageOptional.isPresent()
                ? round(averageOptional.getAsDouble())
                : null;

        return new EngineeringMetrics(
                totalBuilds,
                successCount,
                failureCount,
                successRate,
                calculateMttrMinutes(failures),
                calculateMtbfHours(failures),
                activeFailures,
                resolvedFailures,
                averageBuildDurationMs
        );
    }

    private static Double calculateMttrMinutes(List<FailureMetricSnapshot> failures) {
        List<Long> recoveryMinutes = failures.stream()
                .filter(FailureMetricSnapshot::resolved)
                .filter(f -> f.createdAt() != null && f.resolvedAt() != null)
                .map(f -> Duration.between(f.createdAt(), f.resolvedAt()).toMinutes())
                .filter(minutes -> minutes >= 0)
                .toList();

        if (recoveryMinutes.isEmpty()) {
            return null;
        }
        return round(recoveryMinutes.stream().mapToLong(Long::longValue).average().orElse(0));
    }

    private static Double calculateMtbfHours(List<FailureMetricSnapshot> failures) {
        List<Instant> failureTimes = failures.stream()
                .map(FailureMetricSnapshot::createdAt)
                .filter(time -> time != null)
                .sorted()
                .toList();

        if (failureTimes.size() < 2) {
            return null;
        }

        long totalMinutes = 0;
        for (int i = 1; i < failureTimes.size(); i++) {
            totalMinutes += Duration.between(failureTimes.get(i - 1), failureTimes.get(i)).toMinutes();
        }

        return round(totalMinutes / 60.0 / (failureTimes.size() - 1));
    }

    private static double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    public record EngineeringMetrics(
            long totalBuilds,
            long successCount,
            long failureCount,
            double successRatePercent,
            Double mttrMinutes,
            Double mtbfHours,
            long activeFailures,
            long resolvedFailures,
            Double averageBuildDurationMs
    ) {}
}
