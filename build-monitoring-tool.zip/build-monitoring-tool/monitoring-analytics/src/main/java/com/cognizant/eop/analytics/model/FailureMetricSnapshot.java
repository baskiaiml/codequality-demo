package com.cognizant.eop.analytics.model;

import com.cognizant.eop.api.model.FailureCategory;

import java.time.Instant;

public record FailureMetricSnapshot(
        Long failureId,
        String buildExternalId,
        String jobExternalId,
        String jobName,
        String teamName,
        FailureCategory category,
        boolean resolved,
        Instant createdAt,
        Instant resolvedAt
) {}
