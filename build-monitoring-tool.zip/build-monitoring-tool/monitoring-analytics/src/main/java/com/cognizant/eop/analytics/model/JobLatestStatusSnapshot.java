package com.cognizant.eop.analytics.model;

import com.cognizant.eop.api.model.BuildStatus;

public record JobLatestStatusSnapshot(
        String jobExternalId,
        String jobName,
        String teamName,
        BuildStatus latestStatus
) {}
