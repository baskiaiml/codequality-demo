package com.cognizant.eop.analytics.engine;

import com.cognizant.eop.analytics.model.JobLatestStatusSnapshot;
import com.cognizant.eop.api.model.BuildStatus;

import java.util.List;

public final class ReleaseReadinessCalculator {

    private ReleaseReadinessCalculator() {
    }

    public static ReleaseReadinessScore compute(
            List<JobLatestStatusSnapshot> jobs,
            long outstandingFailures,
            double buildStabilityPercent) {

        long totalJobs = jobs.size();
        long jobsPassing = jobs.stream().filter(j -> j.latestStatus() == BuildStatus.SUCCESS).count();
        long blockedBuilds = jobs.stream().filter(j -> j.latestStatus() == BuildStatus.FAILURE).count();

        double buildStatusScore = totalJobs == 0 ? 0.0 : round(jobsPassing * 100.0 / totalJobs);
        double stabilityScore = round(buildStabilityPercent);

        double failurePenalty = Math.min(100.0, outstandingFailures * 12.0);
        double blockedPenalty = totalJobs == 0 ? 0.0 : Math.min(100.0, blockedBuilds * 100.0 / totalJobs);

        double environmentReadiness = round(Math.max(0.0, 100.0 - failurePenalty));
        double deploymentReadiness = round(Math.max(0.0, 100.0 - blockedPenalty));

        double overallScore = round(
                buildStatusScore * 0.30
                        + stabilityScore * 0.30
                        + environmentReadiness * 0.20
                        + deploymentReadiness * 0.20
        );

        return new ReleaseReadinessScore(
                overallScore,
                buildStatusScore,
                stabilityScore,
                outstandingFailures,
                blockedBuilds,
                environmentReadiness,
                deploymentReadiness
        );
    }

    private static double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    public record ReleaseReadinessScore(
            double score,
            double buildStatusScore,
            double buildStabilityScore,
            long outstandingFailures,
            long blockedBuilds,
            double environmentReadiness,
            double deploymentReadiness
    ) {}
}
