param(
    [string]$BaseUrl = $env:EOP_PROVIDER_TEAMCITY_BASE_URL,
    [string]$Token = $env:TEAMCITY_TOKEN
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($BaseUrl)) {
    Write-Host "ERROR: Set EOP_PROVIDER_TEAMCITY_BASE_URL (e.g. https://your-instance.teamcity.com)" -ForegroundColor Red
    exit 1
}

if ([string]::IsNullOrWhiteSpace($Token)) {
    Write-Host "ERROR: Set TEAMCITY_TOKEN (TeamCity profile -> Access Tokens)" -ForegroundColor Red
    exit 1
}

$BaseUrl = $BaseUrl.TrimEnd("/")
$headers = @{
    Authorization = "Bearer $Token"
    Accept        = "application/json"
}

function Invoke-TeamCityGet {
    param([string]$Path)
    $uri = "$BaseUrl/app/rest$Path"
    Write-Host "GET $uri"
    try {
        return Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
    }
    catch {
        $status = $_.Exception.Response.StatusCode.value__
        Write-Host "FAILED ($status): $uri" -ForegroundColor Red
        throw
    }
}

Write-Host "`n=== TeamCity connectivity check ===" -ForegroundColor Cyan
Write-Host "Server: $BaseUrl`n"

$server = Invoke-TeamCityGet "/server"
Write-Host "Server version : $($server.version)"
Write-Host "Server versionMajor : $($server.versionMajor)"

$buildTypes = Invoke-TeamCityGet "/buildTypes?fields=buildType(id,name,projectName,paused)&locator=count:20"
$count = if ($buildTypes.buildType) { @($buildTypes.buildType).Count } else { 0 }
Write-Host "Build types found: $count"

if ($count -gt 0) {
    Write-Host "`nSample build types (use 'id' as EOP externalId):"
    $buildTypes.buildType | Select-Object -First 5 | ForEach-Object {
        Write-Host "  - $($_.id)  ($($_.projectName) :: $($_.name))"
    }
}
else {
    Write-Host "`nNo build configurations yet. In TeamCity Cloud, create a project and run at least one build." -ForegroundColor Yellow
}

$running = Invoke-TeamCityGet "/builds?locator=running:true,count:5&fields=build(id,number,buildType(id))"
$runningCount = if ($running.build) { @($running.build).Count } else { 0 }
Write-Host "`nRunning builds: $runningCount"

Write-Host "`nTeamCity REST API is reachable. You can start EOP with the teamcity profile." -ForegroundColor Green
