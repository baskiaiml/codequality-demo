package com.cognizant.eop.notification.template;

import com.cognizant.eop.api.notification.NotificationContext;
import com.cognizant.eop.api.notification.NotificationTemplateRenderer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Loads templates from classpath and substitutes {@code ${variable}} placeholders.
 */
public class ClasspathNotificationTemplateRenderer implements NotificationTemplateRenderer {

    private static final String TEMPLATE_PATH_PREFIX = "templates/";
    private static final String SUBJECT_PREFIX = "Subject: ";

    private final Map<String, String> templateCache = new ConcurrentHashMap<>();

    @Override
    public RenderedNotification render(String templateName, NotificationContext context) {
        String rawTemplate = loadTemplate(templateName);
        String rendered = substitute(rawTemplate, toVariables(context));

        int newlineIndex = rendered.indexOf('\n');
        if (newlineIndex < 0 || !rendered.startsWith(SUBJECT_PREFIX)) {
            throw new IllegalStateException("Template must start with 'Subject: ' line: " + templateName);
        }

        String subject = rendered.substring(SUBJECT_PREFIX.length(), newlineIndex).trim();
        String body = rendered.substring(newlineIndex + 1).trim();
        return new RenderedNotification(subject, body);
    }

    private Map<String, String> toVariables(NotificationContext context) {
        Map<String, String> variables = new HashMap<>();
        variables.put("jobName", nullToEmpty(context.jobName()));
        variables.put("jobExternalId", nullToEmpty(context.jobExternalId()));
        variables.put("buildExternalId", nullToEmpty(context.buildExternalId()));
        variables.put("buildNumber", String.valueOf(context.buildNumber()));
        variables.put("buildUrl", nullToEmpty(context.buildUrl()));
        variables.put("branch", nullToEmpty(context.branch()));
        variables.put("failureCategory", nullToEmpty(context.failureCategory()));
        variables.put("rootCause", nullToEmpty(context.rootCause()));
        variables.put("suggestedFix", nullToEmpty(context.suggestedFix()));
        variables.put("possibleOwner", nullToEmpty(context.possibleOwner()));
        variables.put("logSnippet", nullToEmpty(context.logSnippet()));
        variables.put("teamName", nullToEmpty(context.teamName()));
        variables.put("teamEmail", nullToEmpty(context.teamEmail()));
        variables.put("resolvedFailureCount", String.valueOf(context.resolvedFailureCount()));
        return variables;
    }

    private String substitute(String template, Map<String, String> variables) {
        String result = template;
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            result = result.replace("${" + entry.getKey() + "}", entry.getValue());
        }
        return result;
    }

    private String loadTemplate(String templateName) {
        return templateCache.computeIfAbsent(templateName, name -> {
            String path = TEMPLATE_PATH_PREFIX + name + ".txt";
            try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(path)) {
                if (inputStream == null) {
                    throw new IllegalArgumentException("Notification template not found: " + path);
                }
                return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException ex) {
                throw new IllegalStateException("Failed to load notification template: " + path, ex);
            }
        });
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
