package com.cognizant.eop.notification.sender;

import com.cognizant.eop.api.notification.NotificationChannel;
import com.cognizant.eop.api.notification.NotificationMessage;
import com.cognizant.eop.api.notification.NotificationSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Logs notifications instead of sending email. Default for local development.
 */
public class LoggingNotificationSender implements NotificationSender {

    private static final Logger log = LoggerFactory.getLogger(LoggingNotificationSender.class);

    @Override
    public NotificationChannel channel() {
        return NotificationChannel.EMAIL;
    }

    @Override
    public void send(NotificationMessage message) {
        log.info(
                "NOTIFICATION [{}] event={} to={} subject={}\n{}",
                message.channel(),
                message.eventType(),
                message.recipient(),
                message.subject(),
                message.body()
        );
    }
}
