package com.cognizant.eop.notification.template;

import com.cognizant.eop.api.notification.NotificationContext;
import com.cognizant.eop.api.notification.NotificationTemplateRenderer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class ClasspathNotificationTemplateRendererTest {

    private final NotificationTemplateRenderer renderer = new ClasspathNotificationTemplateRenderer();

    @Test
    void render_failureNotification_substitutesVariables() {
        NotificationContext context = new NotificationContext(
                "Alpha Instream Build",
                "job-fo-alpha-instream",
                "build-1001",
                1523,
                "http://build/1001",
                "fo/alpha/instream",
                "COMPILATION_ERROR",
                "Cannot find symbol CustomerDTO",
                "Replace CustomerDTO with CustomerSummaryDTO",
                "jsmith",
                "error: CustomerDTO",
                "Alpha Team",
                "alpha-team@titan.internal",
                0
        );

        NotificationTemplateRenderer.RenderedNotification rendered =
                renderer.render("failure-notification", context);

        assertTrue(rendered.subject().contains("Alpha Instream Build"));
        assertTrue(rendered.subject().contains("#1523"));
        assertTrue(rendered.body().contains("COMPILATION_ERROR"));
        assertTrue(rendered.body().contains("CustomerDTO"));
        assertTrue(rendered.body().contains("jsmith"));
    }
}
