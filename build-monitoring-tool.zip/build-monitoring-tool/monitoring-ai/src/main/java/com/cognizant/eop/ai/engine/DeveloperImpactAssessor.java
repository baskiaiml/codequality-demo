package com.cognizant.eop.ai.engine;

import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.api.model.Severity;

/**
 * Generates developer impact descriptions based on failure classification.
 */
public class DeveloperImpactAssessor {

    /**
     * Returns a human-readable description of the impact on developers.
     */
    public String assess(FailureCategory category, Severity severity) {
        String baseImpact = switch (category) {
            case COMPILATION_ERROR -> "Blocks compilation for all developers merging to this branch";
            case JUNIT_FAILURE, INTEGRATION_TEST_FAILURE ->
                    "Failing tests must be fixed before the build can proceed to staging";
            case MERGE_CONFLICT -> "Blocks all merges until conflicts are resolved";
            case LIQUIBASE_FAILURE, ORACLE_SQL_FAILURE ->
                    "Database migration failure may block deployments to downstream environments";
            case MAVEN_FAILURE, GRADLE_FAILURE -> "Build tool failure blocks the entire pipeline";
            case DOCKER_FAILURE -> "Container build failure blocks deployment stages";
            case GIT_FAILURE -> "Source control failure prevents code checkout and build";
            case DEPLOYMENT_FAILURE -> "Deployment stage failure blocks release to target environment";
            case INFRASTRUCTURE_FAILURE, ENVIRONMENT_FAILURE, NETWORK_FAILURE ->
                    "Infrastructure issue may affect multiple teams and builds";
            case TIMEOUT -> "Build timeout delays feedback loop for the team";
            default -> "Build failure requires investigation before the pipeline can continue";
        };

        if (severity == Severity.CRITICAL) {
            return baseImpact + ". Critical severity — immediate attention required.";
        }
        return baseImpact;
    }
}
