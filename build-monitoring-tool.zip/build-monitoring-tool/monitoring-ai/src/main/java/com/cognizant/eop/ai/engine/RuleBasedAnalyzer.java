package com.cognizant.eop.ai.engine;

import com.cognizant.eop.api.analyzer.AIAnalyzer;
import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.parser.BuildLogParser;
import com.cognizant.eop.parser.model.LogParseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Local rule-based AI analyzer using the knowledge base parser.
 * No external API calls. Fully offline.
 */
public class RuleBasedAnalyzer implements AIAnalyzer {

    private static final Logger log = LoggerFactory.getLogger(RuleBasedAnalyzer.class);

    private final BuildLogParser buildLogParser;
    private final DeveloperImpactAssessor developerImpactAssessor;

    public RuleBasedAnalyzer(BuildLogParser buildLogParser, DeveloperImpactAssessor developerImpactAssessor) {
        this.buildLogParser = buildLogParser;
        this.developerImpactAssessor = developerImpactAssessor;
    }

    @Override
    public AIAnalysis analyze(BuildLog buildLog) {
        LogParseResult parseResult = buildLogParser.parse(buildLog);

        log.debug("Analysis complete: buildId={}, category={}, confidence={}",
                buildLog.buildId(),
                parseResult.primaryCategory(),
                parseResult.confidenceScore());

        String developerImpact = developerImpactAssessor.assess(
                parseResult.primaryCategory(),
                parseResult.severity()
        );

        return AnalysisResultMapper.toAIAnalysis(parseResult, null, developerImpact);
    }
}
