package com.cognizant.eop.ai.engine;

import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.parser.model.LogParseResult;

/**
 * Maps parser output to the {@link AIAnalysis} domain model.
 */
public final class AnalysisResultMapper {

    private AnalysisResultMapper() {
    }

    public static AIAnalysis toAIAnalysis(LogParseResult parseResult, String possibleOwner, String developerImpact) {
        return new AIAnalysis(
                parseResult.primaryCategory(),
                parseResult.confidenceScore(),
                parseResult.rootCause(),
                parseResult.suggestedFix(),
                parseResult.affectedModule(),
                possibleOwner,
                parseResult.relevantClasses(),
                parseResult.sqlObjects(),
                parseResult.logSnippet(),
                parseResult.recommendation(),
                developerImpact,
                parseResult.severity()
        );
    }
}
