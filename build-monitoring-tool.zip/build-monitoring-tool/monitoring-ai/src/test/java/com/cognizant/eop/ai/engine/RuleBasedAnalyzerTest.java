package com.cognizant.eop.ai.engine;

import com.cognizant.eop.api.model.AIAnalysis;
import com.cognizant.eop.api.model.BuildLog;
import com.cognizant.eop.api.model.FailureCategory;
import com.cognizant.eop.parser.BuildLogParser;
import com.cognizant.eop.parser.DefaultBuildLogParser;
import com.cognizant.eop.parser.extractor.FailureSnippetExtractor;
import com.cognizant.eop.parser.knowledge.KnowledgeBaseLoader;
import com.cognizant.eop.parser.matcher.PatternMatcher;
import com.cognizant.eop.parser.preprocessor.LogPreprocessor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RuleBasedAnalyzerTest {

    private static RuleBasedAnalyzer analyzer;

    @BeforeAll
    static void setUp() {
        KnowledgeBaseLoader loader = new KnowledgeBaseLoader();
        loader.load();
        BuildLogParser parser = new DefaultBuildLogParser(
                loader,
                new LogPreprocessor(),
                new PatternMatcher(loader),
                new FailureSnippetExtractor()
        );
        analyzer = new RuleBasedAnalyzer(parser, new DeveloperImpactAssessor());
    }

    @ParameterizedTest
    @CsvSource({
            "compilation-failure.log, COMPILATION_ERROR",
            "junit-failure.log, JUNIT_FAILURE",
            "merge-conflict.log, MERGE_CONFLICT",
            "sql-failure.log, ORACLE_SQL_FAILURE"
    })
    void analyze_mockLogs_classifiesCorrectly(String logFile, FailureCategory expectedCategory) throws IOException {
        AIAnalysis analysis = analyzer.analyze(new BuildLog("test-build", loadLog(logFile)));

        assertEquals(expectedCategory, analysis.failureType());
        assertTrue(analysis.confidenceScore().doubleValue() >= 50);
        assertNotNull(analysis.developerImpact());
        assertNotNull(analysis.rootCause());
        assertNotNull(analysis.suggestedFix());
    }

    @Test
    void analyze_compilationFailure_includesDeveloperImpact() throws IOException {
        AIAnalysis analysis = analyzer.analyze(new BuildLog("build-1001", loadLog("compilation-failure.log")));

        assertEquals(FailureCategory.COMPILATION_ERROR, analysis.failureType());
        assertTrue(analysis.developerImpact().contains("compilation"));
    }

    private String loadLog(String fileName) throws IOException {
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("mock-logs/" + fileName)) {
            if (is == null) {
                throw new IllegalStateException("Log file not found: " + fileName);
            }
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
