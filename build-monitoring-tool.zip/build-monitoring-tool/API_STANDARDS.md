# API Standards

## REST Conventions

### Base URL

```
/api/v1/
```

### Resource Naming

- Plural nouns: `/api/v1/jobs`, `/api/v1/builds`, `/api/v1/teams`
- Nested resources: `/api/v1/teams/{teamId}/jobs`
- Actions as sub-resources: `/api/v1/builds/{buildId}/analysis`

### HTTP Methods

| Method | Usage |
|---|---|
| GET | Retrieve resources (supports pagination, sorting, filtering) |
| POST | Create resources |
| PUT | Full update |
| PATCH | Partial update |
| DELETE | Remove resources |

### Response Format

All responses use DTOs. Entities are never exposed directly.

```json
{
  "id": 1,
  "name": "Titan-FrontOffice-Instream-Build",
  "teamId": 3,
  "teamName": "Alpha Team",
  "branch": "instream",
  "enabled": true,
  "latestBuild": {
    "id": 42,
    "buildNumber": 1523,
    "status": "FAILURE",
    "startedAt": "2026-06-29T08:15:00Z",
    "durationMs": 342000
  }
}
```

### Pagination

```
GET /api/v1/builds?page=0&size=20&sort=startedAt,desc
```

Response wrapper:

```json
{
  "content": [...],
  "page": {
    "number": 0,
    "size": 20,
    "totalElements": 1523,
    "totalPages": 77
  }
}
```

### Filtering

Query parameters for common filters:

```
GET /api/v1/builds?status=FAILURE&teamId=3&from=2026-06-01&to=2026-06-29
GET /api/v1/failures?category=COMPILATION_ERROR&resolved=false
```

### Sorting

```
GET /api/v1/builds?sort=startedAt,desc&sort=buildNumber,asc
```

---

## Error Handling

### RFC 9457 Problem Details

All errors return `application/problem+json`:

```json
{
  "type": "https://eop.internal/errors/resource-not-found",
  "title": "Resource Not Found",
  "status": 404,
  "detail": "Job with id 999 does not exist",
  "instance": "/api/v1/jobs/999"
}
```

### Standard Error Types

| Status | Type URI | Usage |
|---|---|---|
| 400 | `/errors/validation-failed` | Request validation errors |
| 401 | `/errors/unauthorized` | Missing or invalid authentication |
| 403 | `/errors/forbidden` | Insufficient permissions |
| 404 | `/errors/resource-not-found` | Entity not found |
| 409 | `/errors/conflict` | Duplicate or conflicting state |
| 500 | `/errors/internal-server-error` | Unexpected server error |

### Validation Errors

```json
{
  "type": "https://eop.internal/errors/validation-failed",
  "title": "Validation Failed",
  "status": 400,
  "detail": "One or more fields failed validation",
  "errors": [
    {
      "field": "name",
      "message": "must not be blank"
    }
  ]
}
```

---

## API Endpoints (Planned)

### Jobs

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/jobs` | List all jobs (paginated, filterable) |
| GET | `/api/v1/jobs/{id}` | Get job details |
| POST | `/api/v1/jobs` | Create job |
| PUT | `/api/v1/jobs/{id}` | Update job |
| PATCH | `/api/v1/jobs/{id}/enabled` | Enable/disable job |

### Builds

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/builds` | List builds (paginated, filterable) |
| GET | `/api/v1/builds/{id}` | Get build details |
| GET | `/api/v1/builds/running` | List currently running builds |
| GET | `/api/v1/builds/{id}/log` | Get build log |
| GET | `/api/v1/builds/{id}/analysis` | Get AI analysis |

### Teams & Groups

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/groups` | List groups |
| GET | `/api/v1/teams` | List teams |
| GET | `/api/v1/teams/{id}/dashboard` | Team dashboard data |

### Failures

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/failures` | List failures (paginated, filterable) |
| GET | `/api/v1/failures/{id}` | Get failure details with analysis |

### Dashboards

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/dashboard/global` | Global dashboard summary |
| GET | `/api/v1/dashboard/group/{groupId}` | Group dashboard |
| GET | `/api/v1/dashboard/release-readiness` | Release readiness score |

### Analytics

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/analytics/summary` | Engineering metrics summary |
| GET | `/api/v1/analytics/trends` | Build trends over time |
| GET | `/api/v1/analytics/top-failures` | Top failing jobs/teams/categories |

### Configuration (Admin)

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/admin/config` | List configuration |
| PUT | `/api/v1/admin/config/{key}` | Update configuration |
| GET | `/api/v1/admin/notification-rules` | List notification rules |
| POST | `/api/v1/admin/notification-rules` | Create notification rule |

---

## OpenAPI Documentation

- SpringDoc OpenAPI 3 auto-generated from controller annotations
- Available at `/swagger-ui.html` in dev profile
- Disabled in production profile

---

## Versioning

- URL path versioning: `/api/v1/`
- Breaking changes require a new version (`/api/v2/`)
- Non-breaking additions (new fields, new endpoints) stay in current version
