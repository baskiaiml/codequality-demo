# Enterprise Engineering Operations Platform (EOP)

## Project Constitution

This document is the authoritative source of truth for the EOP project. Every implementation decision must align with the principles defined here.

---

## Role

The EOP is a production-ready Enterprise Engineering Operations Platform designed for use by **500+ developers** across **30+ teams** in a large enterprise environment.

This is **NOT** a demo application.

---

## Business Context

### Organization Structure

- **30 development teams** organized into four groups:
  - Front Office
  - Middle Office
  - Back Office
  - Framework

- All teams work on a single enterprise application: **Titan**
- Source code resides in a single GitLab repository
- Each team owns branches: Instream, Staging, Master, Production Release

### Development Flow

```
Developer Branch → Team Instream → Instream Testing → Cherry Pick
  → Team Staging → Automatic Merge → Master
```

### Infrastructure

- **60+ environments** (Dev, SIT, Perf, UFT, UAT, Prod Copy, Production)
- **TeamCity** for CI/CD with hundreds of build configurations
- Real TeamCity is hosted inside the client network and **cannot be accessed during development**

---

## Problem Statement

Engineers manually inspect TeamCity every morning. Problems include:

- Hundreds of TeamCity jobs with no centralized dashboard
- Difficult to identify team ownership and responsible developer
- Difficult to determine root cause
- Delayed recovery of broken builds
- Noisy email notifications that are ignored
- Poor manager visibility into engineering health

---

## Objectives

The platform must:

1. Continuously monitor CI/CD builds (via abstraction, not direct TeamCity coupling)
2. Detect failures, recoveries, and running builds
3. Identify failure ownership and responsible developer
4. Parse build logs and classify failures
5. Generate root cause summaries and recommend fixes
6. Notify only relevant people
7. Provide dashboards and engineering metrics
8. Provide historical analytics
9. Be extensible to multiple CI/CD systems

---

## Critical Constraint: Build Provider Abstraction

The application **MUST NOT** directly depend on TeamCity. All CI/CD integration flows through the `BuildProvider` interface.

```java
public interface BuildProvider {
    List<Job> getConfiguredJobs();
    Build getLatestBuild(String jobId);
    List<Build> getBuildHistory(String jobId);
    BuildLog getBuildLog(String buildId);
    List<Commit> getChanges(String buildId);
    List<Build> getRunningBuilds();
}
```

**Implementations:**

| Implementation | Purpose | Status |
|---|---|---|
| `MockBuildProvider` | Local JSON files for development | Active during dev |
| `TeamCityBuildProvider` | TeamCity REST API | Production only |

Everything else depends **only** on `BuildProvider`.

---

## Technology Stack

| Layer | Technology |
|---|---|
| Backend | Java 21, Spring Boot 3.x, Spring Scheduling, Spring Data JPA, Spring Validation, Spring Cache |
| Build | Maven, MapStruct, Lombok, Flyway |
| Frontend | React, TypeScript, Material UI, AG Grid Community, React Query |
| Database | PostgreSQL |
| Testing | JUnit 5, Mockito, Testcontainers, Docker Compose |

**Explicitly excluded:** Kafka, RabbitMQ, event-driven architecture. Use Spring Scheduler only.

---

## Architecture: Modular Monolith

```
monitoring-api          → Shared domain models, interfaces, DTOs
monitoring-core         → Application entry point, scheduler, orchestration
monitoring-provider     → BuildProvider implementations (Mock, TeamCity)
monitoring-parser       → Log parsing, pattern matching
monitoring-ai           → AI analysis engine (rule-based, local only)
monitoring-notification → Notification engine (email, future Slack/Teams)
monitoring-analytics    → Metrics, reports, trends
monitoring-security     → Spring Security, RBAC
monitoring-audit        → Audit trail
monitoring-ui           → React frontend
```

**Rules:**

- No circular dependencies between modules
- Each module has a single, clear responsibility
- Dependencies flow inward: core → api, provider → api, etc.

---

## Scheduler Workflow

Runs every **5 minutes** via Spring Scheduler:

```
Load configured jobs
  → Fetch latest build
  → Compare with database
  → If unchanged: ignore
  → If changed:
      Store build
      → Download build log
      → Run AI analysis
      → Store analysis
      → Update dashboard
      → Send notification
```

Must handle: running, cancelled, queued, successful, failed builds; multiple new builds between cycles; recoveries; repeated failures.

---

## AI Module

**Initial implementation: completely local. No external API dependency.**

Uses: Rule Engine, Regex Matching, Pattern Matching, Confidence Scoring, Knowledge Base, Decision Tree, Recommendation Engine, Log Summarization.

```java
public interface AIAnalyzer {
    AIAnalysis analyze(BuildLog buildLog);
}
```

Switch implementation via Spring Profiles: `RuleBasedAnalyzer` (default), future `ClaudeAnalyzer`, `OpenAIAnalyzer`, `GeminiAnalyzer`.

**Knowledge base patterns stored as JSON/YAML — never hardcoded.** Adding new failure types must not require code changes.

---

## Failure Classification Categories

Compilation Error, Merge Conflict, JUnit Failure, Integration Test Failure, Liquibase Failure, Oracle SQL Failure, Gradle Failure, Maven Failure, Docker Failure, Deployment Failure, Git Failure, Infrastructure Failure, Environment Failure, Network Failure, Timeout, Unknown Failure.

Architecture must support unlimited future classifiers.

---

## Notification Rules

- Notify on first failure
- Notify when root cause changes
- Notify on recovery
- **Never** repeatedly notify for the same failure
- Support notification templates
- Channels: Email (initial), Slack/Teams/Webhooks (future)

---

## Security Roles

| Role | Access |
|---|---|
| Administrator | Full configuration and management |
| Manager | Dashboards, analytics, team views |
| Developer | Own builds, failures, notifications |
| Viewer | Read-only dashboards |

---

## Development Workflow

Implement **incrementally**. For every iteration:

1. Explain architectural decisions
2. Explain design patterns used
3. Explain folder structure
4. Generate production-ready code
5. Generate unit tests
6. Generate integration tests where appropriate
7. Explain how to run locally
8. **Wait for confirmation before proceeding**

Never leave TODOs for core functionality. Never generate toy implementations.

---

## Code Standards

SOLID, DRY, KISS, Clean Code, Clean Architecture, Hexagonal principles where practical.

- Constructor injection only (no field injection)
- Java Records where appropriate
- No static utility abuse
- Meaningful package names
- High test coverage
- Comprehensive JavaDoc for public APIs

---

## Related Documents

| Document | Purpose |
|---|---|
| [SYSTEM_ARCHITECTURE.md](SYSTEM_ARCHITECTURE.md) | Diagrams, module interactions, deployment |
| [DATABASE_DESIGN.md](DATABASE_DESIGN.md) | ER diagrams, schema, indexing |
| [API_STANDARDS.md](API_STANDARDS.md) | REST conventions, error handling |
| [UI_UX_GUIDELINES.md](UI_UX_GUIDELINES.md) | Dashboard layouts, design system |
| [AI_ENGINE_SPEC.md](AI_ENGINE_SPEC.md) | Parser, knowledge base, confidence scoring |
| [CODING_STANDARDS.md](CODING_STANDARDS.md) | Naming, packages, testing, review checklist |
