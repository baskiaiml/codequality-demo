# Coding Standards

## Package Structure

Base package: `com.cognizant.eop`

```
com.cognizant.eop
├── .api                          # monitoring-api
│   ├── model                     # Domain records and enums
│   ├── provider                  # BuildProvider interface
│   ├── analyzer                  # AIAnalyzer interface
│   └── dto                       # Shared DTOs
├── .core                         # monitoring-core
│   ├── EopApplication.java
│   ├── config
│   ├── scheduler
│   ├── orchestrator
│   ├── controller
│   ├── service
│   ├── entity
│   ├── repository
│   └── mapper
├── .provider                     # monitoring-provider
│   ├── mock
│   └── teamcity
├── .parser                       # monitoring-parser
├── .ai                           # monitoring-ai
│   ├── engine
│   ├── knowledge
│   └── recommendation
├── .notification                 # monitoring-notification
├── .analytics                    # monitoring-analytics
├── .security                     # monitoring-security
└── .audit                        # monitoring-audit
```

---

## Naming Conventions

| Element | Convention | Example |
|---|---|---|
| Classes | PascalCase | `BuildMonitoringScheduler` |
| Interfaces | PascalCase, no "I" prefix | `BuildProvider` |
| Methods | camelCase | `getLatestBuild()` |
| Constants | UPPER_SNAKE_CASE | `DEFAULT_POLLING_INTERVAL` |
| Packages | lowercase | `com.cognizant.eop.core.scheduler` |
| Database tables | snake_case | `build_commit` |
| Database columns | snake_case | `started_at` |
| REST paths | kebab-case | `/api/v1/build-history` |
| Enums | UPPER_SNAKE_CASE values | `COMPILATION_ERROR` |
| DTOs | suffix with `Dto` or `Request`/`Response` | `JobResponse`, `CreateJobRequest` |
| Entities | no suffix | `Job`, `Build`, `Failure` |
| Records | no suffix | `BuildLog`, `Commit`, `AIAnalysis` |

---

## Java Standards

### Dependency Injection

```java
// CORRECT: Constructor injection
@Service
public class BuildMonitoringService {
    private final BuildProvider buildProvider;
    private final BuildRepository buildRepository;

    public BuildMonitoringService(BuildProvider buildProvider,
                                  BuildRepository buildRepository) {
        this.buildProvider = buildProvider;
        this.buildRepository = buildRepository;
    }
}

// WRONG: Field injection
@Autowired
private BuildProvider buildProvider;
```

### Records for Value Objects

```java
public record Build(
    String id,
    String jobId,
    int buildNumber,
    BuildStatus status,
    Instant startedAt,
    Instant finishedAt,
    long durationMs,
    String triggeredBy,
    String branch,
    String buildUrl
) {}
```

### Immutability

- Domain models in `monitoring-api` are immutable records
- JPA entities in `monitoring-core` are mutable (JPA requirement)
- DTOs are immutable records

### Exception Handling

- Custom exceptions extend `EopException` base class
- Global handler returns RFC 9457 Problem Details
- Never catch generic `Exception` unless re-throwing as domain exception
- Never swallow exceptions silently

---

## Testing Requirements

### Unit Tests

- Every public service method must have unit tests
- Use Mockito for dependency mocking
- Test naming: `{methodName}_{scenario}_{expectedResult}`
- Example: `analyze_compilationError_returnsHighConfidenceAnalysis`

### Integration Tests

- Use Testcontainers for PostgreSQL
- Test REST endpoints with `@SpringBootTest` + `MockMvc`
- Test Flyway migrations apply cleanly
- Test scheduler orchestration with MockBuildProvider

### Test Structure

```
src/test/java/com/cognizant/eop/
├── unit/           # Pure unit tests (no Spring context)
├── integration/    # Spring Boot tests with Testcontainers
└── fixtures/       # Test data builders and helpers
```

### Coverage Targets

- Service layer: 90%+
- Controller layer: 80%+
- Provider/Parser/AI: 85%+
- Overall: 80%+

---

## Code Review Checklist

- [ ] No direct TeamCity dependencies outside `monitoring-provider`
- [ ] Constructor injection used (no `@Autowired` on fields)
- [ ] DTOs used in REST layer (no entity exposure)
- [ ] Proper exception handling with Problem Details
- [ ] Unit tests for new service methods
- [ ] Integration tests for new REST endpoints
- [ ] Flyway migration for schema changes (never modify existing)
- [ ] Knowledge base patterns in YAML (not hardcoded in Java)
- [ ] Structured logging with appropriate levels
- [ ] JavaDoc on all public API interfaces and classes
- [ ] No TODO comments for core functionality
- [ ] Immutable records for domain value objects
- [ ] MapStruct mappers for entity ↔ DTO conversion

---

## Logging Standards

Use SLF4J with structured key-value pairs:

```java
log.info("Scheduler cycle completed",
    kv("jobsChecked", count),
    kv("newBuilds", newBuilds),
    kv("failures", failures),
    kv("recoveries", recoveries),
    kv("durationMs", duration));
```

| Level | Usage |
|---|---|
| ERROR | Unrecoverable failures, exceptions |
| WARN | Recoverable issues, degraded operation |
| INFO | Scheduler cycles, significant state changes |
| DEBUG | Detailed processing steps (dev/test only) |

Never log sensitive data (passwords, tokens, full build logs at INFO level).

---

## Git Conventions

### Branch Naming

```
feature/EOP-{ticket}-short-description
bugfix/EOP-{ticket}-short-description
```

### Commit Messages

```
type(scope): concise description

feat(core): add build monitoring scheduler
fix(ai): correct confidence scoring for partial matches
test(provider): add MockBuildProvider integration tests
docs: add database design document
```

Types: `feat`, `fix`, `test`, `docs`, `refactor`, `chore`
