package com.cognizant.eop.security.auth;

import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.security.model.AuthenticatedUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.List;

/**
 * Spring Security authentication token wrapping {@link AuthenticatedUser}.
 */
public class EopAuthenticationToken implements Authentication {

    private final AuthenticatedUser user;
    private boolean authenticated = true;

    public EopAuthenticationToken(AuthenticatedUser user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + user.role().name()));
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public AuthenticatedUser getDetails() {
        return user;
    }

    @Override
    public Object getPrincipal() {
        return user.username();
    }

    @Override
    public boolean isAuthenticated() {
        return authenticated;
    }

    @Override
    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        this.authenticated = isAuthenticated;
    }

    @Override
    public String getName() {
        return user.username();
    }

    public UserRole getRole() {
        return user.role();
    }
}
