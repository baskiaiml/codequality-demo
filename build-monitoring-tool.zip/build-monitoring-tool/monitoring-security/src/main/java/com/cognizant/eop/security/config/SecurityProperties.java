package com.cognizant.eop.security.config;

/**
 * JWT and security configuration properties.
 *
 * @param enabled         whether HTTP security is enforced
 * @param jwtSecret       HMAC secret for signing tokens (min 32 chars recommended)
 * @param jwtExpirationMs token lifetime in milliseconds
 */
public record SecurityProperties(
        boolean enabled,
        String jwtSecret,
        long jwtExpirationMs
) {
    public SecurityProperties {
        if (jwtExpirationMs <= 0) {
            jwtExpirationMs = 86_400_000L;
        }
    }
}
