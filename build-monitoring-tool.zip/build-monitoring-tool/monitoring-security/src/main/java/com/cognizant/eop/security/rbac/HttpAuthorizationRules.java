package com.cognizant.eop.security.rbac;

import org.springframework.http.HttpMethod;

/**
 * Centralized HTTP authorization rules for role-based access control.
 */
public final class HttpAuthorizationRules {

    private HttpAuthorizationRules() {
    }

    public static final String[] PUBLIC_PATHS = {
            "/api/v1/health",
            "/api/v1/auth/login",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/api-docs/**",
            "/v3/api-docs/**"
    };

    public static final String ADMIN_CONFIG = "/api/v1/admin/config/**";
    public static final String ADMIN_TEAMS = "/api/v1/admin/teams/**";
    public static final String ADMIN_JOBS = "/api/v1/admin/jobs/**";
    public static final String ADMIN_SCHEDULER = "/api/v1/admin/scheduler/**";
    public static final String ADMIN_AUDIT = "/api/v1/admin/audit-events/**";
    public static final String ADMIN_NOTIFICATION_RULES = "/api/v1/admin/notification-rules/**";
    public static final String ANALYTICS = "/api/v1/analytics/**";
    public static final String DASHBOARD = "/api/v1/dashboard/**";
    public static final String JOBS_PROCESS = "/api/v1/jobs/*/process-builds";
    public static final String BUILDS_PROCESS_FAILURE = "/api/v1/builds/*/process-failure";

    public static HttpMethod jobsProcessMethod() {
        return HttpMethod.POST;
    }

    public static HttpMethod buildsProcessFailureMethod() {
        return HttpMethod.POST;
    }
}
