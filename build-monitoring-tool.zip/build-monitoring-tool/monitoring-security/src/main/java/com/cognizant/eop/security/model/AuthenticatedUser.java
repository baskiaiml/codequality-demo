package com.cognizant.eop.security.model;

import com.cognizant.eop.api.security.UserRole;

/**
 * Authenticated platform user claims embedded in JWT tokens.
 */
public record AuthenticatedUser(
        String username,
        UserRole role,
        Long teamId,
        String displayName,
        String email
) {
}
