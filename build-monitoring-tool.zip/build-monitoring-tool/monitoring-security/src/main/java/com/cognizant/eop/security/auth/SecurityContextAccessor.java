package com.cognizant.eop.security.auth;

import com.cognizant.eop.security.model.AuthenticatedUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Resolves the currently authenticated user from the security context.
 */
public final class SecurityContextAccessor {

    private SecurityContextAccessor() {
    }

    public static String currentUsernameOrSystem() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof EopAuthenticationToken token) {
            return token.getName();
        }
        if (authentication != null && authentication.isAuthenticated()
                && !"anonymousUser".equals(authentication.getPrincipal())) {
            return authentication.getName();
        }
        return "system";
    }

    public static AuthenticatedUser currentUserOrNull() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof EopAuthenticationToken token) {
            return token.getDetails();
        }
        return null;
    }
}
