package com.cognizant.eop.security.jwt;

import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.model.AuthenticatedUser;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;

/**
 * Creates and validates JWT access tokens for API authentication.
 */
@Component
public class JwtTokenService {

    private static final String CLAIM_ROLE = "role";
    private static final String CLAIM_TEAM_ID = "teamId";
    private static final String CLAIM_DISPLAY_NAME = "displayName";
    private static final String CLAIM_EMAIL = "email";

    private final SecurityProperties securityProperties;
    private final SecretKey signingKey;

    public JwtTokenService(SecurityProperties securityProperties) {
        this.securityProperties = securityProperties;
        this.signingKey = Keys.hmacShaKeyFor(securityProperties.jwtSecret().getBytes(StandardCharsets.UTF_8));
    }

    public String generateToken(AuthenticatedUser user) {
        Instant now = Instant.now();
        Instant expiry = now.plusMillis(securityProperties.jwtExpirationMs());

        return Jwts.builder()
                .subject(user.username())
                .claim(CLAIM_ROLE, user.role().name())
                .claim(CLAIM_TEAM_ID, user.teamId())
                .claim(CLAIM_DISPLAY_NAME, user.displayName())
                .claim(CLAIM_EMAIL, user.email())
                .issuedAt(Date.from(now))
                .expiration(Date.from(expiry))
                .signWith(signingKey)
                .compact();
    }

    public AuthenticatedUser parseToken(String token) {
        Claims claims = Jwts.parser()
                .verifyWith(signingKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();

        return new AuthenticatedUser(
                claims.getSubject(),
                UserRole.valueOf(claims.get(CLAIM_ROLE, String.class)),
                claims.get(CLAIM_TEAM_ID, Long.class),
                claims.get(CLAIM_DISPLAY_NAME, String.class),
                claims.get(CLAIM_EMAIL, String.class)
        );
    }

    public long getExpirationMs() {
        return securityProperties.jwtExpirationMs();
    }
}
