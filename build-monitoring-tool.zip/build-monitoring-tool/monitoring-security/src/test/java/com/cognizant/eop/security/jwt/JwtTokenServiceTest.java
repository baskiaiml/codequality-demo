package com.cognizant.eop.security.jwt;

import com.cognizant.eop.api.security.UserRole;
import com.cognizant.eop.security.config.SecurityProperties;
import com.cognizant.eop.security.model.AuthenticatedUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class JwtTokenServiceTest {

    private JwtTokenService jwtTokenService;

    @BeforeEach
    void setUp() {
        jwtTokenService = new JwtTokenService(new SecurityProperties(
                true,
                "test-secret-key-at-least-32-characters-long",
                3_600_000L
        ));
    }

    @Test
    void generateAndParseToken_roundTripsUserClaims() {
        AuthenticatedUser user = new AuthenticatedUser(
                "jsmith",
                UserRole.DEVELOPER,
                1L,
                "John Smith",
                "jsmith@titan.internal"
        );

        String token = jwtTokenService.generateToken(user);
        AuthenticatedUser parsed = jwtTokenService.parseToken(token);

        assertEquals(user.username(), parsed.username());
        assertEquals(user.role(), parsed.role());
        assertEquals(user.teamId(), parsed.teamId());
        assertEquals(user.displayName(), parsed.displayName());
        assertEquals(user.email(), parsed.email());
    }
}
