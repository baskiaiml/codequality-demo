# System Architecture

## Overview

EOP follows a **Modular Monolith** architecture deployed as a single Spring Boot application with a React frontend. The design applies Hexagonal (Ports & Adapters) principles: domain logic is isolated from infrastructure concerns via interfaces.

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        monitoring-ui (React)                    │
│              Material UI │ AG Grid │ React Query                │
└──────────────────────────────┬──────────────────────────────────┘
                               │ REST API (JSON)
┌──────────────────────────────▼──────────────────────────────────┐
│                     monitoring-core (Spring Boot)               │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────────────┐  │
│  │  Scheduler   │  │  REST API    │  │  Configuration Mgmt   │  │
│  │  (5 min)     │  │  Controllers │  │  Service              │  │
│  └──────┬───────┘  └──────────────┘  └───────────────────────┘  │
│         │                                                        │
│  ┌──────▼───────────────────────────────────────────────────┐   │
│  │              Build Monitoring Orchestrator                │   │
│  └──────┬──────────┬──────────┬──────────┬─────────────────┘   │
│         │          │          │          │                        │
│  ┌──────▼───┐ ┌───▼────┐ ┌──▼─────┐ ┌──▼──────────┐           │
│  │ Provider │ │ Parser │ │   AI   │ │ Notification│           │
│  │  Module  │ │ Module │ │ Module │ │   Module    │           │
│  └──────────┘ └────────┘ └────────┘ └─────────────┘           │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  Analytics   │  │   Security   │  │       Audit          │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└──────────────────────────────┬──────────────────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │     PostgreSQL       │
                    └─────────────────────┘
```

---

## Module Dependency Graph

```
monitoring-ui (standalone React app)

monitoring-core
  ├── monitoring-api
  ├── monitoring-provider
  ├── monitoring-parser
  ├── monitoring-ai
  ├── monitoring-notification
  ├── monitoring-analytics
  ├── monitoring-security
  └── monitoring-audit

monitoring-provider → monitoring-api
monitoring-parser   → monitoring-api
monitoring-ai       → monitoring-api, monitoring-parser
monitoring-notification → monitoring-api
monitoring-analytics    → monitoring-api
monitoring-security     → monitoring-api
monitoring-audit        → monitoring-api
```

**No circular dependencies.** `monitoring-api` has zero internal module dependencies.

---

## Module Responsibilities

### monitoring-api

Shared domain models, interfaces (ports), and DTOs. The contract layer that all modules depend on.

- `BuildProvider` interface
- `AIAnalyzer` interface
- Domain records: `Job`, `Build`, `BuildLog`, `Commit`, `AIAnalysis`
- Enums: `BuildStatus`, `FailureCategory`, `NotificationChannel`

### monitoring-core

Application entry point and orchestration layer.

- Spring Boot `@SpringBootApplication`
- Scheduler (`BuildMonitoringScheduler`)
- Build monitoring orchestrator (coordinates provider → parser → AI → notification)
- REST API controllers
- JPA entities and repositories
- Flyway migrations
- Application configuration

### monitoring-provider

BuildProvider implementations (adapters).

- `MockBuildProvider` — reads local JSON files
- `TeamCityBuildProvider` — TeamCity REST API (production profile)

### monitoring-parser

Build log parsing and pattern extraction.

- Log line tokenizer
- Pattern matcher (loads from knowledge base YAML/JSON)
- Failure snippet extractor

### monitoring-ai

Local AI analysis engine.

- `RuleBasedAnalyzer` — rule engine, decision tree, confidence scoring
- Knowledge base loader
- Recommendation engine

### monitoring-notification

Notification dispatch and rule evaluation.

- Email sender (Spring Mail)
- Notification rule engine
- Template rendering
- Deduplication logic

### monitoring-analytics

Metrics calculation and reporting.

- Success/failure rates, MTTR, MTBF
- Trend analysis
- Weekly/monthly report generation

### monitoring-security

Authentication and authorization.

- Spring Security configuration
- JWT or session-based auth
- Role-based access control

### monitoring-audit

Audit trail for configuration and user actions.

- Audit event capture
- Audit query API

### monitoring-ui

React SPA with Material UI dashboards.

---

## Scheduler Sequence

```mermaid
sequenceDiagram
    participant S as Scheduler
    participant O as Orchestrator
    participant P as BuildProvider
    participant DB as PostgreSQL
    participant AI as AIAnalyzer
    participant N as NotificationEngine

    S->>O: executeMonitoringCycle()
    O->>DB: loadConfiguredJobs()
    loop For each enabled job
        O->>P: getLatestBuild(jobId)
        P-->>O: Build
        O->>DB: findLastKnownBuild(jobId)
        alt Build unchanged
            O->>O: skip
        else Build changed
            O->>DB: persistBuild(build)
            O->>P: getBuildLog(buildId)
            P-->>O: BuildLog
            alt Build failed
                O->>AI: analyze(buildLog)
                AI-->>O: AIAnalysis
                O->>DB: persistAnalysis(analysis)
                O->>N: evaluateAndNotify(build, analysis)
            else Build recovered
                O->>N: notifyRecovery(build)
            end
        end
    end
    O->>O: logExecutionSummary()
```

---

## Deployment Architecture

```
┌─────────────────────────────────────────┐
│              Docker Host                 │
│                                          │
│  ┌──────────────┐  ┌─────────────────┐  │
│  │  EOP App     │  │   PostgreSQL    │  │
│  │  (Spring +   │  │   (Database)    │  │
│  │   React)     │  │                 │  │
│  │  Port 8080   │  │   Port 5432     │  │
│  └──────────────┘  └─────────────────┘  │
│                                          │
│  ┌──────────────┐                        │
│  │  Mock Data   │  (dev profile only)   │
│  │  (JSON files)│                        │
│  └──────────────┘                        │
└─────────────────────────────────────────┘
```

Production deployment adds TeamCity connectivity via `TeamCityBuildProvider` activated by the `production` Spring profile.

---

## Design Patterns

| Pattern | Usage |
|---|---|
| **Hexagonal (Ports & Adapters)** | `BuildProvider`, `AIAnalyzer` as ports; Mock/TeamCity as adapters |
| **Strategy** | Switchable AI analyzers and build providers via Spring Profiles |
| **Template Method** | Notification template rendering |
| **Repository** | JPA repositories for data access |
| **Builder** | Complex domain object construction (MapStruct + Lombok) |
| **Observer (implicit)** | Scheduler polling model replaces event-driven |
| **Factory** | Provider and analyzer factory based on active profile |

---

## Spring Profiles

| Profile | Purpose |
|---|---|
| `dev` (default) | MockBuildProvider, H2 or local PostgreSQL, debug logging |
| `test` | Testcontainers PostgreSQL, MockBuildProvider |
| `production` | TeamCityBuildProvider, production PostgreSQL, structured logging |
